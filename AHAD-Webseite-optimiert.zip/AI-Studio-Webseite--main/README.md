# AHAD Cleaning — Unternehmens-Webseite

Webseite der AHAD Cleaning Company GmbH: Gebäudereinigung, Industriereinigung und
Unterhaltsreinigung für Unternehmen in Villingen-Schwenningen, Stuttgart, Konstanz
und Süddeutschland.

## Tech-Stack

- **React 19** + TypeScript + Vite
- **Tailwind CSS 4** (mit Typography-Plugin)
- **React Router 7** mit Lazy Loading (Code-Splitting pro Seite)
- **Firebase** (Firestore für Leads/Bewerbungen, Auth für Admin-Bereich)
- **Resend** für E-Mail-Benachrichtigungen (über Express-API in `api/`)
- Deployment: **Vercel** (siehe `vercel.json`)

## Lokal starten

1. Abhängigkeiten installieren: `npm install`
2. `.env` anlegen (siehe `.env.example`) und `RESEND_API_KEY` setzen.
   `GEMINI_API_KEY` ist nur für das interne Dev-Tool `/generate-images` nötig.
3. Starten: `npm run dev` → http://localhost:3000

## Wichtige Befehle

| Befehl | Zweck |
|---|---|
| `npm run dev` | Dev-Server (Express + Vite) |
| `npm run build` | Produktions-Build nach `dist/` |
| `npm run lint` | TypeScript-Prüfung ohne Build |
| `node scripts/optimize-images.mjs` | Bilder zu WebP konvertieren (benötigt `sharp`) |

## Projektstruktur

```
api/            Express-API (E-Mail-Versand mit Validierung & Rate-Limit)
public/         Statische Dateien (robots.txt, sitemap.xml, images/)
scripts/        Hilfsskripte (Bild-Optimierung; alte Einmal-Skripte in archive/)
src/
  components/   Header, Footer, Layout, SEO, ContactForm, …
  pages/        Eine Datei pro Route (lazy geladen)
  firebase.ts   Firebase-Initialisierung & Firestore-Helfer
firestore.rules Zugriffsregeln (Leads: nur Erstellen öffentlich, Lesen nur Admin)
```

## Sicherheit & SEO — bereits eingebaut

- API-Eingaben werden HTML-escaped, validiert und rate-limitiert (5 Anfragen/10 Min/IP)
- Honeypot-Felder gegen Spam-Bots in Formularen
- `GEMINI_API_KEY` landet **nie** im Produktions-Bundle
- `robots.txt` + `sitemap.xml`, LocalBusiness-Schema, kanonische URLs, Open Graph
- `/admin` und 404 sind `noindex`

## Vor dem Livegang prüfen

- [ ] Bilder mit `scripts/optimize-images.mjs` zu WebP konvertieren
- [ ] `og-image.jpg` (1200×630) und `logo.png` in `public/` ablegen
- [ ] Eigene verifizierte Resend-Absenderdomain statt `onboarding@resend.dev` eintragen (`api/index.ts`)
- [ ] Inhalte in Impressum & Datenschutz juristisch prüfen lassen
- [ ] Zahlen/Aussagen auf der Startseite verifizieren (z. B. "über 80 Objekte", "24h Reaktionszeit")
