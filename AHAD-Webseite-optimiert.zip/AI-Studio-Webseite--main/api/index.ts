import express from "express";
import { Resend } from "resend";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json({ limit: "50kb" }));

let resendClient: Resend | null = null;

function getResend() {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    throw new Error("RESEND_API_KEY is not set.");
  }
  if (!resendClient) {
    resendClient = new Resend(apiKey);
  }
  return resendClient;
}

// ---------------------------------------------------------------------------
// Sicherheit
// ---------------------------------------------------------------------------

/** Wandelt Nutzereingaben in sicheren Text um, bevor sie in E-Mail-HTML landen.
 *  Verhindert HTML-/Script-Injection über Formularfelder. */
function esc(value: unknown): string {
  return String(value ?? "")
    .slice(0, 500)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** Einfaches In-Memory-Rate-Limit: max. 5 Anfragen pro IP innerhalb von 10 Minuten.
 *  Schützt das E-Mail-Postfach vor Spam-Fluten ohne externe Abhängigkeit. */
const rateWindow = 10 * 60 * 1000;
const rateMax = 5;
const hits = new Map<string, number[]>();

function rateLimited(ip: string): boolean {
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < rateWindow);
  recent.push(now);
  hits.set(ip, recent);
  // Speicher sauber halten
  if (hits.size > 5000) {
    for (const [key, times] of hits) {
      if (times.every((t) => now - t >= rateWindow)) hits.delete(key);
    }
  }
  return recent.length > rateMax;
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

// ---------------------------------------------------------------------------
// Routen
// ---------------------------------------------------------------------------

// Health check
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    resendConfigured: !!process.env.RESEND_API_KEY,
    nodeEnv: process.env.NODE_ENV,
  });
});

// API Route for sending emails
app.post("/api/send-email", async (req, res) => {
  const ip =
    (req.headers["x-forwarded-for"] as string)?.split(",")[0]?.trim() ||
    req.socket.remoteAddress ||
    "unknown";

  if (rateLimited(ip)) {
    return res.status(429).json({ error: "Zu viele Anfragen. Bitte später erneut versuchen." });
  }

  const { type, data, website } = req.body ?? {};

  // Honeypot: Das Feld "website" ist im Formular unsichtbar.
  // Füllt es ein Bot aus, tun wir so, als wäre alles ok — senden aber nichts.
  if (website) {
    return res.json({ success: true });
  }

  if (!data || typeof data !== "object") {
    return res.status(400).json({ error: "Ungültige Anfrage." });
  }

  try {
    const resend = getResend();
    let subject = "";
    let html = "";

    if (type === "job_application") {
      if (!data.name || !data.phone) {
        return res.status(400).json({ error: "Name und Telefon sind erforderlich." });
      }
      subject = `Neue Bewerbung: ${esc(data.name).slice(0, 80)} (${esc(data.jobType).slice(0, 60)})`;
      html = `
        <div style="font-family: sans-serif; padding: 20px; color: #333;">
          <h2 style="color: #005332;">Neue Bewerbung eingegangen</h2>
          <p><strong>Name:</strong> ${esc(data.name)}</p>
          <p><strong>Telefon:</strong> ${esc(data.phone)}</p>
          <p><strong>Stelle:</strong> ${esc(data.jobType)}</p>
          <p><strong>Bereich:</strong> ${esc(data.department)}</p>
          <p><strong>Erfahrung:</strong> ${esc(data.experience)}</p>
          <p><strong>Startdatum:</strong> ${esc(data.startDate)}</p>
          <p><strong>Mobilität:</strong> ${esc(data.mobility)}</p>
          <p><strong>Standort:</strong> ${esc(data.location)}</p>
          <p><strong>WhatsApp erlaubt:</strong> ${data.whatsappOptIn ? "Ja" : "Nein"}</p>
          <hr style="border: 1px solid #eee; margin: 20px 0;" />
          <p style="font-size: 12px; color: #888;">Gesendet von AHAD Cleaning Web-Funnel</p>
        </div>
      `;
    } else if (type === "offer_lead") {
      if (!data.companyName || !data.email || !EMAIL_RE.test(String(data.email))) {
        return res.status(400).json({ error: "Firma und gültige E-Mail sind erforderlich." });
      }
      const services = Array.isArray(data.services)
        ? data.services.slice(0, 20).map(esc).join(", ")
        : esc(data.services);
      subject = `Neue Angebotsanfrage: ${esc(data.companyName).slice(0, 80)}`;
      html = `
        <div style="font-family: sans-serif; padding: 20px; color: #333;">
          <h2 style="color: #004888;">Neue Angebotsanfrage eingegangen</h2>
          <p><strong>Firma:</strong> ${esc(data.companyName)}</p>
          <p><strong>Ansprechpartner:</strong> ${esc(data.contactPerson)}</p>
          <p><strong>E-Mail:</strong> ${esc(data.email)}</p>
          <p><strong>Telefon:</strong> ${esc(data.phone)}</p>
          <p><strong>Standort:</strong> ${esc(data.location)}</p>
          <p><strong>Objektart:</strong> ${esc(data.objectType)}</p>
          <p><strong>Leistungen:</strong> ${services}</p>
          <p><strong>Fläche:</strong> ${esc(data.areaSize)}</p>
          <p><strong>Intervall:</strong> ${esc(data.frequency)}</p>
          <hr style="border: 1px solid #eee; margin: 20px 0;" />
          <p style="font-size: 12px; color: #888;">Gesendet von AHAD Cleaning Web-Funnel</p>
        </div>
      `;
    } else {
      return res.status(400).json({ error: "Unbekannter Anfragetyp." });
    }

    const { data: resData, error } = await resend.emails.send({
      from: "AHAD Funnel <onboarding@resend.dev>",
      to: ["info@ahad-cleaning.de"],
      subject: subject,
      html: html,
    });

    if (error) {
      console.error("Resend API error:", JSON.stringify(error, null, 2));
      return res.status(400).json({
        error:
          typeof error === "object" && error !== null && "message" in error
            ? (error as any).message
            : JSON.stringify(error),
      });
    }

    res.json({ success: true, id: resData?.id });
  } catch (err) {
    console.error("Server error sending email:", err);
    res.status(500).json({ error: "Interner Serverfehler." });
  }
});

export default app;
