import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { FileText, Phone, Mail, MapPin, ChevronRight, MessageSquare } from 'lucide-react';
import SEO from '@/components/SEO';
import ContactForm from '@/components/ContactForm';

export default function Kontakt() {
  return (
    <div className="min-h-screen bg-[#f7f9fb]">
      <SEO 
        title="Kontakt & Angebot" 
        description="Kontaktieren Sie AHAD Cleaning für ein unverbindliches Angebot oder eine Objektbesichtigung. Wir freuen uns auf Ihre Anfrage."
        keywords="Kontakt Gebäudereinigung, Angebot anfordern Reinigung, AHAD Cleaning Kontakt"
      />
      <section className="bg-[#004888] text-white pt-32 pb-20 lg:pt-48 lg:pb-32 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight">Kontaktieren Sie uns</h1>
            <p className="text-lg md:text-xl text-blue-100 leading-relaxed">
              Wir sind für Sie da. Ob für ein unverbindliches Angebot, Fragen zu unseren Leistungen oder eine persönliche Beratung – 
              wir freuen uns auf Ihre Nachricht.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="pt-20 pb-32 lg:pt-32 lg:pb-48 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
            
            {/* Linke Seite: Formular */}
            <div className="lg:col-span-7">
              <div className="mb-12">
                <h2 className="text-3xl font-black text-[#001c3b] mb-4 flex items-center gap-3">
                  <MessageSquare className="text-[#004888]" /> Nachricht schreiben
                </h2>
                <p className="text-[#424751] text-lg">
                  Füllen Sie das Formular aus und wir melden uns innerhalb von 24 Stunden bei Ihnen.
                </p>
              </div>
              <ContactForm />
            </div>

            {/* Rechte Seite: Infos & Funnel */}
            <div className="lg:col-span-5 space-y-12">
              {/* Express Angebot Box */}
              <div className="bg-[#004888] text-white p-8 md:p-12 rounded-[2rem] shadow-xl relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
                  <FileText size={120} />
                </div>
                <h3 className="text-2xl font-bold mb-4 relative z-10">Express-Angebot</h3>
                <p className="text-blue-100 mb-8 relative z-10 leading-relaxed">
                  Nutzen Sie unseren digitalen Assistenten für eine schnellere Bearbeitung Ihrer Anfrage. In nur 60 Sekunden zum passenden Angebot.
                </p>
                <Link 
                  to="/angebot" 
                  className="inline-flex items-center gap-2 bg-[#2ca06a] text-white px-6 py-3 rounded-xl font-bold hover:bg-[#238054] transition-all relative z-10 shadow-sm hover:shadow-md hover:-translate-y-[1px] focus:outline-none focus:ring-4 focus:ring-[#2ca06a]/50"
                >
                  Zum Express-Funnel <ChevronRight size={20} />
                </Link>
              </div>

              {/* Direkter Kontakt */}
              <div className="space-y-6">
                <h3 className="text-2xl font-black text-[#001c3b]">Direkter Kontakt</h3>
                
                <div className="space-y-4">
                  <div className="bg-gray-50 p-6 rounded-2xl flex items-start gap-4 border border-gray-100">
                    <div className="w-12 h-12 bg-blue-50 text-[#004888] rounded-xl flex items-center justify-center shrink-0">
                      <Phone size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">Telefon</h4>
                      <a href="tel:+4977219447915" className="text-[#004888] hover:underline font-bold text-lg">+49 7721 944 79 15</a>
                      <p className="text-xs text-gray-500 mt-1">Mo-Fr, 08:00 - 17:00 Uhr</p>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-2xl flex items-start gap-4 border border-gray-100">
                    <div className="w-12 h-12 bg-blue-50 text-[#004888] rounded-xl flex items-center justify-center shrink-0">
                      <Mail size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">E-Mail</h4>
                      <a href="mailto:info@ahad-cleaning.de" className="text-[#004888] hover:underline font-bold break-all">info@ahad-cleaning.de</a>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-2xl flex items-start gap-4 border border-gray-100">
                    <div className="w-12 h-12 bg-blue-50 text-[#004888] rounded-xl flex items-center justify-center shrink-0">
                      <MapPin size={24} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 mb-1">Zentrale</h4>
                      <p className="text-gray-600">Max-Planck-Straße 11<br />78052 Villingen-Schwenningen</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
