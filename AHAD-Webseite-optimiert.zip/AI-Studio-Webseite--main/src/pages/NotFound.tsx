import { Link } from 'react-router-dom';
import { ArrowRight, Home, Phone } from 'lucide-react';
import SEO from '@/components/SEO';

const quickLinks = [
  { name: 'Unsere Leistungen', href: '/leistungen' },
  { name: 'Angebot anfordern', href: '/angebot' },
  { name: 'Karriere bei AHAD', href: '/karriere' },
  { name: 'Kontakt', href: '/kontakt' },
];

export default function NotFound() {
  return (
    <div className="min-h-[70vh] flex items-center bg-[#f7f9fb]">
      <SEO
        title="Seite nicht gefunden"
        description="Die angeforderte Seite existiert nicht. Hier finden Sie den Weg zurück zu AHAD Cleaning."
        noindex
      />
      <div className="max-w-3xl mx-auto px-4 sm:px-8 py-24 text-center">
        <p className="font-headline text-[clamp(5rem,15vw,9rem)] font-black leading-none text-[#001c3b]/10 select-none" aria-hidden="true">
          404
        </p>
        <h1 className="text-3xl sm:text-4xl font-black text-[#001c3b] mt-2 mb-4">
          Diese Seite gibt es nicht.
        </h1>
        <p className="text-[#424751] text-lg mb-10 max-w-xl mx-auto">
          Die Adresse wurde möglicherweise geändert oder falsch eingegeben.
          Kein Problem — hier geht es weiter:
        </p>

        <div className="flex flex-wrap justify-center gap-3 mb-10">
          {quickLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className="inline-flex items-center gap-2 bg-white border border-gray-200 px-5 py-3 rounded-xl font-semibold text-[#001c3b] hover:border-[#004888] hover:text-[#004888] transition-colors"
            >
              {link.name}
              <ArrowRight size={16} />
            </Link>
          ))}
        </div>

        <div className="flex flex-wrap justify-center items-center gap-6">
          <Link
            to="/"
            className="inline-flex items-center gap-2 bg-[#004888] text-white px-6 py-3.5 rounded-xl font-bold hover:bg-[#003a6e] transition-colors"
          >
            <Home size={18} />
            Zur Startseite
          </Link>
          <a
            href="tel:+4977219447915"
            className="inline-flex items-center gap-2 font-bold text-[#001c3b] hover:text-[#004888] transition-colors"
          >
            <Phone size={18} />
            +49 7721 9447915
          </a>
        </div>
      </div>
    </div>
  );
}
