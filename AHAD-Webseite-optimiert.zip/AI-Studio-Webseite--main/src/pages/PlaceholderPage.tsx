import { motion } from 'motion/react';
import { useLocation, Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from 'lucide-react';

export default function PlaceholderPage() {
  const location = useLocation();
  const path = location.pathname.split('/').pop()?.replace(/-/g, ' ') || 'Seite';
  const title = path.charAt(0).toUpperCase() + path.slice(1);

  return (
    <div className="pt-32 pb-20 lg:pt-40 lg:pb-32 min-h-[80vh] flex items-center">
      <div className="max-w-7xl mx-auto px-4 w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-3xl"
        >
          <Link to="/" className="inline-flex items-center text-[#004888] font-bold mb-8 hover:underline">
            <ArrowLeft className="mr-2 w-4 h-4" />
            Zurück zur Startseite
          </Link>
          <h1 className="text-6xl font-bold text-gray-900 mb-6">{title}</h1>
          <p className="text-2xl text-gray-600 leading-relaxed mb-12">
            Diese Seite wird derzeit im Rahmen unserer neuen Website-Struktur für Sie aufbereitet. 
            Wir präsentieren Ihnen hier in Kürze detaillierte Informationen zu diesem Bereich.
          </p>
          <div className="flex flex-wrap gap-4">
            <Link
              to="/kontakt"
              className="inline-flex items-center px-8 py-4 bg-[#004888] text-white font-bold rounded-xl hover:bg-blue-900 transition-all"
            >
              Direkt anfragen
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
            <Link
              to="/leistungen"
              className="inline-flex items-center px-8 py-4 bg-gray-100 text-gray-900 font-bold rounded-xl hover:bg-gray-200 transition-all"
            >
              Alle Leistungen ansehen
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
