import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Building, 
  Factory, 
  Stethoscope, 
  Truck, 
  Check, 
  ChevronRight, 
  ChevronLeft, 
  Calendar, 
  Clock, 
  ShieldCheck,
  Loader2,
  ArrowRight
} from 'lucide-react';
import { db, collection, addDoc, serverTimestamp, handleFirestoreError, OperationType } from '@/firebase';
import { cn } from '@/lib/utils';
import { Link } from 'react-router-dom';

type Step = 1 | 2 | 3 | 4;

interface FormData {
  objectType: string;
  services: string[];
  areaSize: string;
  frequency: string;
  companyName: string;
  contactPerson: string;
  email: string;
  phone: string;
  location: string;
}

const OBJECT_TYPES = [
  { id: 'buero', title: 'Büro & Verwaltung', icon: Building, desc: 'Klassische Büroflächen und Verwaltungsgebäude.' },
  { id: 'industrie', title: 'Industrie & Produktion', icon: Factory, desc: 'Produktionshallen und technische Anlagen.' },
  { id: 'medizin', title: 'Medizintechnik & Sensible Bereiche', icon: Stethoscope, desc: 'Reinräume und medizinische Einrichtungen.' },
  { id: 'logistik', title: 'Gewerbe & Logistik', icon: Truck, desc: 'Lagerhallen und großflächige Verkaufsräume.' },
];

const SERVICES = [
  { id: 'unterhalt', title: 'Unterhaltsreinigung', subtitle: 'Laufender Betrieb' },
  { id: 'glas', title: 'Glas- & Fassadenreinigung', subtitle: 'Fenster & Außenhüllen' },
  { id: 'industrie_service', title: 'Industriereinigung / Anlagenpflege', subtitle: 'Maschinen & Hallen' },
  { id: 'sonder', title: 'Sonder- / Grundreinigung', subtitle: 'Einmalig oder intensiv' },
];

const AREA_SIZES = [
  { id: 'small', title: 'Unter 500 m²' },
  { id: 'medium', title: '500 - 2.000 m²' },
  { id: 'large', title: 'Über 2.000 m²' },
];

const FREQUENCIES = [
  { id: 'daily', title: 'Täglich' },
  { id: 'weekly', title: 'Mehrmals wöchentlich' },
  { id: 'need', title: 'Nach Bedarf' },
];

export default function AngebotsFunnel() {
  const [step, setStep] = useState<Step>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    objectType: '',
    services: [],
    areaSize: '',
    frequency: '',
    companyName: '',
    contactPerson: '',
    email: '',
    phone: '',
    location: '',
  });

  const progress = (step / 4) * 100;

  const handleNext = () => {
    if (step < 4) setStep((s) => (s + 1) as Step);
  };

  const handleBack = () => {
    if (step > 1) setStep((s) => (s - 1) as Step);
  };

  const toggleService = (serviceId: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(serviceId)
        ? prev.services.filter(id => id !== serviceId)
        : [...prev.services, serviceId]
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await addDoc(collection(db, 'offer_leads'), {
        ...formData,
        status: 'new',
        createdAt: serverTimestamp(),
      });

      // Send email notification
      try {
        await fetch('/api/send-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ type: 'offer_lead', data: formData })
        });
      } catch (emailError) {
        console.error('Error sending email notification:', emailError);
      }

      setIsSuccess(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      console.error('Error submitting lead:', error);
      handleFirestoreError(error, OperationType.WRITE, 'offer_leads');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 pt-32 pb-20 lg:pt-40 lg:pb-32 px-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-2xl mx-auto bg-white rounded-3xl shadow-xl p-8 md:p-12 text-center"
        >
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-[#005332]" />
          </div>
          <h1 className="text-3xl font-black text-gray-900 mb-4 tracking-tight">Anfrage erfolgreich!</h1>
          <p className="text-lg text-gray-600 mb-8 leading-relaxed">
            Vielen Dank für Ihr Vertrauen. Wir haben Ihre Anfrage erhalten und prüfen diese umgehend. 
            Ein AHAD-Experte wird sich innerhalb der nächsten **24 Stunden** bei Ihnen melden, 
            um einen Termin für die unverbindliche Objektbesichtigung zu vereinbaren.
          </p>
          <Link 
            to="/" 
            className="inline-flex items-center justify-center bg-[#005332] text-white px-8 py-4 rounded-xl font-bold hover:bg-[#004228] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]"
          >
            Zurück zur Startseite
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12 lg:pt-28 lg:pb-16 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-end mb-2">
            <span className="text-sm font-bold text-[#005332] uppercase tracking-wider">
              {step === 4 ? 'Fast geschafft' : `Schritt ${step} von 4`}
            </span>
            <span className="text-sm font-bold text-gray-400">{Math.round(progress)}%</span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-[#005332]"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.5, ease: "easeOut" }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="text-center md:text-left">
                <h1 className="text-2xl md:text-3xl font-black text-gray-900 mb-2 tracking-tight">
                  Für welches Objekt suchen Sie eine Lösung?
                </h1>
                <p className="text-base text-gray-600">
                  Wir bieten spezialisierte Reinigungskonzepte für jede Branche in Süddeutschland.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {OBJECT_TYPES.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => {
                      setFormData({ ...formData, objectType: type.title });
                      handleNext();
                    }}
                    className={cn(
                      "flex flex-col items-start p-4 rounded-xl border-2 text-left transition-all group",
                      formData.objectType === type.title
                        ? "border-[#005332] bg-green-50/50 shadow-md"
                        : "border-gray-100 bg-white hover:border-gray-300 hover:shadow-lg"
                    )}
                  >
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center mb-3 transition-colors",
                      formData.objectType === type.title
                        ? "bg-[#005332] text-white"
                        : "bg-gray-100 text-gray-500 group-hover:bg-gray-200"
                    )}>
                      <type.icon size={20} />
                    </div>
                    <span className="text-base font-bold text-gray-900 mb-1">{type.title}</span>
                    <span className="text-xs text-gray-500 leading-snug">{type.desc}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="text-center md:text-left">
                <h1 className="text-2xl md:text-3xl font-black text-gray-900 mb-2 tracking-tight">
                  Welche Leistungen benötigen Sie?
                </h1>
                <p className="text-base text-gray-600">
                  Mehrfachauswahl möglich.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {SERVICES.map((service) => (
                  <button
                    key={service.id}
                    onClick={() => toggleService(service.title)}
                    className={cn(
                      "flex items-center gap-3 p-4 rounded-xl border-2 text-left transition-all",
                      formData.services.includes(service.title)
                        ? "border-[#005332] bg-green-50/50 shadow-md"
                        : "border-gray-100 bg-white hover:border-gray-300 hover:shadow-lg"
                    )}
                  >
                    <div className={cn(
                      "w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-colors",
                      formData.services.includes(service.title)
                        ? "bg-[#005332] border-[#005332]"
                        : "border-gray-300"
                    )}>
                      {formData.services.includes(service.title) && <Check size={14} className="text-white" />}
                    </div>
                    <div>
                      <span className="block text-base font-bold text-gray-900">{service.title}</span>
                      <span className="text-xs text-gray-500">{service.subtitle}</span>
                    </div>
                  </button>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={handleBack}
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-gray-600 border-2 border-gray-200 hover:bg-gray-50 transition-all"
                >
                  <ChevronLeft size={18} /> Zurück
                </button>
                <button
                  onClick={handleNext}
                  disabled={formData.services.length === 0}
                  className="flex-[2] flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#005332] hover:bg-[#004228] disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]"
                >
                  Weiter <ChevronRight size={18} />
                </button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="text-center md:text-left">
                <h1 className="text-2xl md:text-3xl font-black text-gray-900 mb-2 tracking-tight">
                  Wie groß ist die zu reinigende Fläche?
                </h1>
                <p className="text-base text-gray-600">
                  Eine grobe Schätzung reicht für den ersten Eindruck.
                </p>
              </div>

              <div className="space-y-6">
                {/* Area Size */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {AREA_SIZES.map((size) => (
                    <button
                      key={size.id}
                      onClick={() => setFormData({ ...formData, areaSize: size.title })}
                      className={cn(
                        "p-3 rounded-xl border-2 font-bold transition-all text-sm",
                        formData.areaSize === size.title
                          ? "border-[#005332] bg-green-50 text-[#005332]"
                          : "border-gray-100 bg-white text-gray-600 hover:border-gray-300"
                      )}
                    >
                      {size.title}
                    </button>
                  ))}
                </div>

                {/* Frequency */}
                <div className="space-y-3">
                  <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
                    <Clock className="text-[#005332]" size={18} />
                    Gewünschter Turnus
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {FREQUENCIES.map((freq) => (
                      <button
                        key={freq.id}
                        onClick={() => setFormData({ ...formData, frequency: freq.title })}
                        className={cn(
                          "p-3 rounded-xl border-2 font-bold transition-all text-sm",
                          formData.frequency === freq.title
                            ? "border-[#005332] bg-green-50 text-[#005332]"
                            : "border-gray-100 bg-white text-gray-600 hover:border-gray-300"
                        )}
                      >
                        {freq.title}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={handleBack}
                  className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-gray-600 border-2 border-gray-200 hover:bg-gray-50 transition-all"
                >
                  <ChevronLeft size={18} /> Zurück
                </button>
                <button
                  onClick={handleNext}
                  disabled={!formData.areaSize || !formData.frequency}
                  className="flex-[2] flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#005332] hover:bg-[#004228] disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]"
                >
                  Weiter <ChevronRight size={18} />
                </button>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="text-center md:text-left">
                <h1 className="text-2xl md:text-3xl font-black text-gray-900 mb-2 tracking-tight">
                  Lassen Sie uns Ihr Objekt ansehen.
                </h1>
                <p className="text-base text-gray-600">
                  Um Ihnen ein belastbares Angebot zu machen, besichtigen wir Ihr Objekt kurz vor Ort. Völlig unverbindlich.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-3">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-700 ml-1">Firmenname</label>
                    <input
                      required
                      type="text"
                      placeholder="Muster GmbH"
                      value={formData.companyName}
                      onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-100 focus:border-[#005332] focus:ring-0 transition-all outline-none text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-700 ml-1">Ansprechpartner</label>
                    <input
                      required
                      type="text"
                      placeholder="Vorname Nachname"
                      value={formData.contactPerson}
                      onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-100 focus:border-[#2ca06a] focus:ring-0 transition-all outline-none text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-700 ml-1">E-Mail-Adresse</label>
                    <input
                      required
                      type="email"
                      placeholder="name@firma.de"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-100 focus:border-[#2ca06a] focus:ring-0 transition-all outline-none text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-gray-700 ml-1">Telefonnummer</label>
                    <input
                      required
                      type="tel"
                      placeholder="+49 123 456789"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-gray-100 focus:border-[#2ca06a] focus:ring-0 transition-all outline-none text-sm"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-gray-700 ml-1">PLZ / Ort (für regionale Zuordnung)</label>
                  <input
                    required
                    type="text"
                    placeholder="78050 Villingen-Schwenningen"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-gray-100 focus:border-[#2ca06a] focus:ring-0 transition-all outline-none text-sm"
                  />
                </div>

                <div className="bg-blue-50/50 border border-blue-100 rounded-xl p-3 flex items-center gap-3">
                  <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center flex-shrink-0 shadow-sm">
                    <Clock className="text-[#1e60a9]" size={16} />
                  </div>
                  <p className="text-xs text-gray-600 font-medium">
                    Wir melden uns innerhalb von **24 Stunden** bei Ihnen.
                  </p>
                </div>

                <p className="text-[10px] text-gray-400 text-center px-2">
                  Ihre Daten werden DSGVO-konform verarbeitet. Mit dem Absenden erklären Sie sich mit unserer Datenschutzerklärung einverstanden.
                </p>

                <div className="flex flex-col sm:flex-row gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleBack}
                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-gray-600 border-2 border-gray-200 hover:bg-gray-50 transition-all text-sm"
                  >
                    <ChevronLeft size={18} /> Zurück
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-[2] flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-bold text-white bg-[#2ca06a] hover:bg-[#238054] disabled:opacity-50 transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px] focus:outline-none focus:ring-4 focus:ring-[#2ca06a]/50 text-sm"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="animate-spin" size={18} /> Wird gesendet...
                      </>
                    ) : (
                      <>
                        Kostenlose Besichtigung anfragen <ArrowRight size={18} />
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Trust Section */}
        <div className="mt-12 pt-6 border-t border-gray-200 grid grid-cols-2 md:grid-cols-3 gap-6 items-center opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
          <div className="flex flex-col items-center gap-1">
            <ShieldCheck size={20} className="text-gray-400" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-center">ISO 9001 Zertifiziert</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <Calendar size={20} className="text-gray-400" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-center">Seit 2004 am Markt</span>
          </div>
          <div className="hidden md:flex flex-col items-center gap-1">
            <Building size={20} className="text-gray-400" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-center">Regionaler Fokus BW</span>
          </div>
        </div>
      </div>
    </div>
  );
}
