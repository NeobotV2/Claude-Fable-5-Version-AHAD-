import { motion } from 'motion/react';
import { Shield, CheckCircle2, ArrowRight, Building2, Sparkles, Droplets, ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function GlasFassadenreinigung() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Wie oft sollte eine Glas- und Fassadenreinigung durchgeführt werden?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Für Bürogebäude empfehlen wir eine Glasreinigung (innen und außen) mindestens 2- bis 4-mal jährlich. Die Fassadenreinigung hängt stark vom Material und der Umweltbelastung ab, ist aber meist alle 1 bis 3 Jahre sinnvoll, um den Werterhalt zu sichern."
        }
      },
      {
        "@type": "Question",
        "name": "Was ist das Osmose-Verfahren bei der Glasreinigung?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Beim Osmose-Verfahren verwenden wir entmineralisiertes Wasser. Dieses Wasser besitzt eine hohe Reinigungskraft und trocknet völlig streifenfrei ab – ganz ohne den Einsatz von chemischen Reinigungsmitteln. Es ist besonders umweltschonend und effizient."
        }
      },
      {
        "@type": "Question",
        "name": "Können Sie auch schwer zugängliche Fenster und Fassaden reinigen?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja. Wir verfügen über modernste Höhenzugangstechnik wie Hubsteiger und arbeiten bei Bedarf mit zertifizierten Industriekletterern zusammen, um auch schwer erreichbare Glasfronten und Fassadenteile sicher und professionell zu reinigen."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Glasreinigung & Fassadenreinigung für Gewerbe | AHAD Cleaning" 
        description="Professionelle Glas- und Fassadenreinigung für Gewerbeobjekte in Süddeutschland. Streifenfreie Sauberkeit, Osmose-Technik und Werterhalt. Jetzt anfragen!"
        keywords="Glasreinigung Unternehmen, Fassadenreinigung Gewerbe, Fensterreinigung Büro, Osmose Reinigung, AHAD Cleaning"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/glasreinigung-hero.jpg" 
            alt="Professionelle Glasreinigung eines modernen Bürogebäudes" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Building2 className="w-4 h-4 text-[#8bf8ba]" />
              Sichtbarer Mehrwert
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Glas- und Fassadenreinigung für Gewerbeobjekte
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              Die Gebäudehülle ist die Visitenkarte Ihres Unternehmens. Wir sorgen in ganz Süddeutschland für 
              einen glänzenden ersten Eindruck und den langfristigen Werterhalt Ihrer Fassade.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/kontakt" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Kostenloses Angebot anfordern
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Glas- & Fassadenreinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Sparkles className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Streifenfreie Sicht</h3>
              <p className="text-[#424751] text-sm">Professionelle Reinigung von Glasfronten, Fenstern, Rahmen und Einfassungen für maximale Lichtausbeute und Repräsentativität.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Droplets className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Osmose-Technologie</h3>
              <p className="text-[#424751] text-sm">Umweltschonende Reinigung mit entmineralisiertem Wasser. Trocknet rückstandslos ab und verzögert die Wiederverschmutzung.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Shield className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Sichere Höhenzugänge</h3>
              <p className="text-[#424751] text-sm">Einsatz von Hubsteigern, Gerüsten oder Industriekletterern durch zertifiziertes Personal unter Einhaltung aller UVV.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="prose prose-lg prose-blue">
              <h2 className="text-3xl font-black mb-6 text-[#001c3b]">Präzision in der Höhe und Werterhalt</h2>
              <p className="text-[#424751] mb-6 leading-relaxed">
                Ob moderne Glasarchitektur, Metallfassaden, Eloxal oder historische Bausubstanz – 
                wir wählen das exakt passende Reinigungsverfahren für jedes Material. Umwelteinflüsse, Abgase und Witterung setzen Ihrer Gebäudehülle zu. Eine fachgerechte Reinigung schützt vor dauerhaften Schäden und Korrosion.
              </p>
              <h3 className="text-2xl font-bold text-[#001c3b] mt-8 mb-4">Unser Leistungsspektrum:</h3>
              <ul className="space-y-3 mb-8 text-[#424751] list-none pl-0">
                {[
                  'Reinigung von Glasfronten, Fenstern & Glasdächern',
                  'Fassadenreinigung (Metall, Stein, Putz, Eloxal)',
                  'Reinigung von Jalousien, Lamellen & Sonnenschutzsystemen',
                  'Einsatz von Hubsteigern & zertifizierten Industriekletterern',
                  'Umweltschonende Reinigungsmittel & Osmose-Verfahren',
                  'Regelmäßige Reinigungsintervalle oder Einzelprojekte'
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="text-[#2ca06a] w-6 h-6 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-[#424751]">
                Wir sind Ihr zuverlässiger Partner in der Region. Von der <Link to="/standorte/stuttgart" className="text-[#004888] font-bold hover:underline">Fassadenreinigung in Stuttgart</Link> bis zur <Link to="/standorte/konstanz" className="text-[#004888] font-bold hover:underline">Glasreinigung in Konstanz</Link> – AHAD Cleaning sorgt für den perfekten Durchblick.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-md">
                  <img src="/images/glasreinigung-fassade.jpg" alt="Fassadenreinigung" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8 bg-[#f7f9fb] rounded-3xl border border-gray-100">
                  <Droplets className="w-10 h-10 text-[#004888] mb-4" />
                  <h4 className="font-bold text-[#001c3b]">Osmose-Technik</h4>
                  <p className="text-sm text-[#424751] mt-2">Streifenfreie Trocknung ohne Chemie, ideal für große Glasflächen.</p>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="p-8 bg-[#001c3b] text-white rounded-3xl shadow-lg">
                  <Shield className="w-10 h-10 text-[#8bf8ba] mb-4" />
                  <h4 className="font-bold">Sicherheit</h4>
                  <p className="text-sm text-blue-100 mt-2">Zertifiziertes Personal für Höhenarbeiten und Hubsteiger-Bedienung.</p>
                </div>
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-md">
                  <img src="/images/glasreinigung-fenster.jpg" alt="Fensterreinigung" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Glas- & Fassadenreinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Glänzende Aussichten für Ihr Gebäude</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Kontaktieren Sie uns für eine Objektbesichtigung und ein individuelles Angebot zur Glas- und Fassadenreinigung.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Angebot anfordern
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
