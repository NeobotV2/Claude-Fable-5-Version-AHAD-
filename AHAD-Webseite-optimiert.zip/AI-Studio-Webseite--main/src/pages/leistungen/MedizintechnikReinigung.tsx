import { motion } from 'motion/react';
import { Microscope, CheckCircle2, ArrowRight, Shield, ClipboardCheck, Sparkles, ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function MedizintechnikReinigung() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Welche Qualifikationen haben Ihre Reinigungskräfte für die Medizintechnik?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Unser Personal für die Medizintechnik- und Reinraumreinigung durchläuft spezielle Schulungen. Sie werden intensiv in Hygienevorschriften, Reinraumverhalten, dem Umgang mit speziellen Reinigungsmitteln und der lückenlosen Dokumentation nach ISO-Vorgaben ausgebildet."
        }
      },
      {
        "@type": "Question",
        "name": "Reinigen Sie auch ISO-zertifizierte Reinräume?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja, wir bieten professionelle Reinraumreinigung gemäß den gängigen ISO-Klassen an. Wir verwenden dafür spezielles, partikelarmes Equipment und validierte Reinigungsmittel, um die strengen Grenzwerte für luftgetragene Partikel und Keime strikt einzuhalten."
        }
      },
      {
        "@type": "Question",
        "name": "Wie wird die Reinigung in sensiblen Bereichen dokumentiert?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Wir arbeiten mit digitalen, audit-sicheren Checklisten und Protokollen. Jeder Reinigungsschritt, die verwendeten Mittel und die ausführende Person werden lückenlos dokumentiert, um Ihnen maximale Transparenz für Ihre eigenen Qualitätsaudits zu bieten."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Reinigung für Medizintechnik & Reinräume | AHAD Cleaning" 
        description="Spezialisierte Reinigung für Medizintechnik und sensible Produktionsbereiche in Süddeutschland. Validierte Prozesse, ISO-konform und audit-sicher."
        keywords="Medizintechnik Reinigung, Reinraumreinigung, ISO-Klassen, Reinraum, Laborreinigung Süddeutschland, AHAD Cleaning"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/medizintechnik-hero.jpg" 
            alt="Hochpräzise Reinigung in der Medizintechnik Produktion" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Microscope className="w-4 h-4 text-[#8bf8ba]" />
              Höchste Disziplin & Hygiene
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Reinigung für Medizintechnik und sensible Produktion
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              In der Medizintechnik und sensiblen Produktionsbereichen ist 
              Sauberkeit kein Standard, sondern eine absolute Voraussetzung für 
              Qualität, Patientensicherheit und Zertifizierungen.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/kontakt" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Fachgespräch vereinbaren
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Medizintechnik-Reinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Shield className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">ISO-Konformität</h3>
              <p className="text-[#424751] text-sm">Reinigungsprozesse, die strikt nach den Vorgaben relevanter ISO-Normen für Reinräume und medizinische Umgebungen durchgeführt werden.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <ClipboardCheck className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Audit-Sicherheit</h3>
              <p className="text-[#424751] text-sm">Lückenlose, digitale Dokumentation aller Reinigungsschritte und eingesetzten Mittel zur Vorlage bei internen und externen Audits.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Sparkles className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Spezial-Equipment</h3>
              <p className="text-[#424751] text-sm">Ausschließliche Verwendung von partikelarmem Equipment, speziellen Wischbezügen und validierten Desinfektionsmitteln.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="prose prose-lg prose-blue">
              <h2 className="text-3xl font-black mb-6 text-[#001c3b]">Validierte Prozesse für sensible Zonen</h2>
              <p className="text-[#424751] mb-6 leading-relaxed">
                Wir verstehen die strengen Anforderungen an die Partikelkonzentration 
                und Keimfreiheit in der Medizintechnik-Branche, insbesondere in Zentren wie <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Tuttlingen</Link> (dem "Weltzentrum der Medizintechnik"). Unsere Teams sind speziell geschult für den Einsatz in Reinräumen, Laboren und hochsensiblen Produktionsbereichen.
              </p>
              <h3 className="text-2xl font-bold text-[#001c3b] mt-8 mb-4">Unsere Kernkompetenzen:</h3>
              <ul className="space-y-3 mb-8 text-[#424751] list-none pl-0">
                {[
                  'Reinraumreinigung nach spezifischen ISO-Klassen',
                  'Lückenlose, digitale Dokumentation der Reinigungsschritte',
                  'Einsatz von spezialisiertem, partikelarmem Equipment',
                  'Intensive Schulung des Personals für korrektes Reinraum-Verhalten',
                  'Validierte Desinfektionsmaßnahmen nach Hygieneplan',
                  'Aktive Unterstützung bei Qualitäts-Audits'
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="text-[#2ca06a] w-6 h-6 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-[#424751]">
                Vertrauen Sie auf einen Partner, der die hohen Standards Ihrer Branche nicht nur kennt, sondern lebt. Wir betreuen Medizintechnik-Unternehmen im gesamten süddeutschen Raum, von <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Villingen-Schwenningen</Link> bis <Link to="/standorte/stuttgart" className="text-[#004888] font-bold hover:underline">Stuttgart</Link>.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-md">
                  <img src="/images/medizintechnik-labor.jpg" alt="Reinraum Medizintechnik" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8 bg-[#f7f9fb] rounded-3xl border border-gray-100">
                  <ClipboardCheck className="w-10 h-10 text-[#004888] mb-4" />
                  <h4 className="font-bold text-[#001c3b]">Dokumentation</h4>
                  <p className="text-sm text-[#424751] mt-2">Audit-sichere, digitale Berichterstattung aller Prozesse.</p>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="p-8 bg-[#001c3b] text-white rounded-3xl shadow-lg">
                  <Shield className="w-10 h-10 text-[#8bf8ba] mb-4" />
                  <h4 className="font-bold">Sicherheit</h4>
                  <p className="text-sm text-blue-100 mt-2">Maximale Prozesssicherheit durch geschultes Fachpersonal.</p>
                </div>
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-md">
                  <img src="/images/medizintechnik-reinraum.jpg" alt="Laborreinigung" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Medizintechnik-Reinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Höchste Standards für Ihre Produktion</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Lassen Sie uns über Ihre spezifischen Anforderungen an die Reinraum- und Medizintechnik-Reinigung sprechen.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Fachgespräch vereinbaren
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
