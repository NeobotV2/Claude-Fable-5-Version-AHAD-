import { motion } from 'motion/react';
import { Factory, CheckCircle2, ArrowRight, ShieldAlert, Settings, Clock, ChevronDown, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';
import ServiceAreas from '@/components/ServiceAreas';

export default function Industriereinigung() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Was ist der Unterschied zwischen Unterhaltsreinigung und Industriereinigung?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Während die Unterhaltsreinigung primär Büros und Verwaltungsflächen umfasst, konzentriert sich die Industriereinigung auf Produktionsanlagen, Maschinenumfelder und Werkshallen. Sie erfordert spezielles Equipment, geschultes Personal und die Einhaltung strenger Sicherheits- und Umweltauflagen."
        }
      },
      {
        "@type": "Question",
        "name": "Stört die Industriereinigung unsere Produktionsabläufe?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Nein. Wir passen unsere Reinigungsintervalle exakt an Ihre Schichtpläne und Wartungsfenster an. Unsere Teams arbeiten so, dass Ihre Produktionsprozesse reibungslos und ohne Unterbrechungen weiterlaufen können."
        }
      },
      {
        "@type": "Question",
        "name": "Welche Sicherheitsstandards werden bei der Industriereinigung eingehalten?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Sicherheit hat höchste Priorität. Unser Personal ist speziell für Industrieumgebungen geschult und hält sich strikt an Ihre internen Sicherheitsvorgaben, Unfallverhütungsvorschriften (UVV) sowie den fachgerechten Umgang mit Gefahrstoffen und Spezialmaschinen."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Industriereinigung & Produktionsreinigung | AHAD Cleaning" 
        description="Professionelle Industriereinigung in Süddeutschland. Wir reinigen Produktionshallen und Maschinenumfelder sicher und ohne Prozessstörung. Jetzt anfragen!"
        keywords="Industriereinigung, Produktionsreinigung, Maschinenreinigung, Hallenreinigung, Industriereinigung Süddeutschland, AHAD Cleaning"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/industrie-hero.jpg" 
            alt="Professionelle Industriereinigung in einer Produktionshalle" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Factory className="w-4 h-4 text-[#8bf8ba]" />
              Industrie- und Produktionsreinigung
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Technische Reinigung ohne Prozessstörung
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              Wir verstehen Ihre Schichtlogik und integrieren uns nahtlos in Ihre Produktionsabläufe. 
              Spezialisierte Reinigung für technische Umfelder in Süddeutschland unter Einhaltung aller Sicherheitsstandards.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/angebot" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Lösung anfragen
              </Link>
              <Link to="/kontakt" className="px-8 py-4 bg-white/10 text-white font-bold rounded-xl hover:bg-white/20 transition-all border border-white/20">
                Beratungsgespräch
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Industriereinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <ShieldAlert className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Höchste Arbeitssicherheit</h3>
              <p className="text-[#424751] text-sm">Strikte Einhaltung von UVV, Gefahrstoffverordnungen und Ihren internen Sicherheitsrichtlinien durch geschultes Personal.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Clock className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Schichtbegleitend</h3>
              <p className="text-[#424751] text-sm">Wir reinigen dann, wenn es Ihr Produktionsplan zulässt – auch nachts, an Wochenenden oder während geplanter Stillstände.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Settings className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Spezial-Equipment</h3>
              <p className="text-[#424751] text-sm">Einsatz von Industriesaugern, Hochdruckreinigern und speziellen Reinigungsmitteln für hartnäckige industrielle Verschmutzungen.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-4xl mx-auto px-4 prose prose-lg prose-blue">
          <h2 className="text-3xl font-black text-[#001c3b] mb-6">Was umfasst die professionelle Industriereinigung?</h2>
          <p className="text-[#424751] mb-6">
            Die Industriereinigung stellt höchste Anforderungen an Mensch und Material. Es geht nicht nur um optische Sauberkeit, sondern um den Erhalt der Funktionsfähigkeit von Maschinen, die Vermeidung von Produktionsausfällen und die Gewährleistung der Arbeitssicherheit für Ihre Mitarbeiter.
          </p>
          
          <h3 className="text-2xl font-bold text-[#001c3b] mt-10 mb-4">Unsere Leistungen in der Industriereinigung:</h3>
          <ul className="space-y-3 mb-8 text-[#424751]">
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2ca06a] flex-shrink-0 mt-0.5" />
              <span><strong>Hallenreinigung:</strong> Fachgerechte Reinigung von Produktions- und Lagerhallen, inklusive Industrieböden, Wänden und Deckenkonstruktionen.</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2ca06a] flex-shrink-0 mt-0.5" />
              <span><strong>Maschinenumfeldreinigung:</strong> Beseitigung von Spänen, Ölen, Schmierstoffen und Produktionsrückständen rund um Ihre Anlagen.</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2ca06a] flex-shrink-0 mt-0.5" />
              <span><strong>Verkehrswege:</strong> Reinigung und Pflege von Fahrwegen und Logistikflächen zur Vermeidung von Unfällen.</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2ca06a] flex-shrink-0 mt-0.5" />
              <span><strong>Sozialräume:</strong> Hygienische Reinigung von Waschräumen, Umkleiden und Pausenbereichen im industriellen Umfeld.</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2ca06a] flex-shrink-0 mt-0.5" />
              <span><strong>Sonderreinigungen:</strong> Entfernung von hartnäckigen Verschmutzungen nach Umbauten oder Revisionen.</span>
            </li>
          </ul>

          <h2 className="text-3xl font-black text-[#001c3b] mt-12 mb-6">Warum AHAD Cleaning für Ihre Produktion?</h2>
          <p className="text-[#424751] mb-6">
            In der Industrie ist Zeit Geld. Ein Stillstand durch verschmutzte Anlagen oder Unfälle aufgrund rutschiger Böden muss zwingend vermieden werden. Mit AHAD Cleaning haben Sie einen Partner, der die Sprache der Industrie spricht.
          </p>
          <p className="text-[#424751] mb-6">
            Wir betreuen Industrieunternehmen im gesamten süddeutschen Raum. Ob Sie eine <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Industriereinigung in Villingen-Schwenningen</Link>, <Link to="/standorte/stuttgart" className="text-[#004888] font-bold hover:underline">Stuttgart</Link>, <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Tuttlingen</Link> oder <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Rottweil</Link> benötigen – unsere spezialisierten Teams sorgen für Sicherheit und Sauberkeit in Ihrer Produktion.
          </p>

          <div className="bg-[#f7f9fb] p-10 rounded-3xl border border-gray-100 shadow-sm mt-12">
            <h3 className="text-2xl font-black text-[#001c3b] mb-8 flex items-center gap-3">
              <Zap className="text-[#004888] w-8 h-8" />
              Ergänzende Leistungen
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { title: 'Unterhaltsreinigung', path: '/leistungen/unterhaltsreinigung' },
                { title: 'Glas- & Fassadenreinigung', path: '/leistungen/glas-fassadenreinigung' },
                { title: 'Sonderreinigung', path: '/leistungen/sonderreinigung' },
                { title: 'Winterdienst', path: '/leistungen/winterdienst' }
              ].map((service, i) => (
                <Link 
                  key={i} 
                  to={service.path}
                  className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-100 hover:border-[#004888] hover:shadow-md transition-all group no-underline"
                >
                  <span className="font-bold text-[#424751] group-hover:text-[#004888] transition-colors">{service.title}</span>
                  <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-[#004888] transition-all group-hover:translate-x-1" />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      <ServiceAreas />

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Industriereinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Sichern Sie Ihre Produktionsprozesse</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Kontaktieren Sie uns für ein maßgeschneidertes Reinigungskonzept, das sich nahtlos in Ihre Industrieabläufe einfügt.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Industrie-Lösung anfragen
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
