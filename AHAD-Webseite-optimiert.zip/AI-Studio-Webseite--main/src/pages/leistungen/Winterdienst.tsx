import { motion } from 'motion/react';
import { CloudSnow, CheckCircle2, ArrowRight, Clock, Shield, MapPin, ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function Winterdienst() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Übernehmen Sie die volle Verkehrssicherungspflicht beim Winterdienst?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja, mit Abschluss eines Winterdienst-Vertrages übertragen Sie die Verkehrssicherungspflicht für die vereinbarten Flächen auf uns. Wir haften im Rahmen unserer Betriebshaftpflichtversicherung für eventuelle Schäden, die durch unzureichende Räum- oder Streuarbeiten entstehen könnten."
        }
      },
      {
        "@type": "Question",
        "name": "Wann räumen Sie bei Schneefall?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Wir richten uns strikt nach den gesetzlichen Vorgaben und Ortssatzungen der jeweiligen Kommunen (wie Villingen-Schwenningen, Rottweil, etc.). In der Regel bedeutet das: Räumung und Streuung vor Beginn des Hauptverkehrs am Morgen und fortlaufende Betreuung bei anhaltendem Schneefall bis in die Abendstunden."
        }
      },
      {
        "@type": "Question",
        "name": "Was beinhaltet Ihr Hausmeisterservice?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Unser Hausmeisterservice umfasst die regelmäßige Kontrolle der Haustechnik, die Pflege der Außenanlagen (Grünschnitt, Laubentfernung), das Abfallmanagement (Bereitstellung der Mülltonnen) sowie die Durchführung kleinerer Reparaturen und Instandsetzungsarbeiten."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Winterdienst & Hausmeisterservice | AHAD Cleaning" 
        description="Zuverlässiger Winterdienst und Hausmeisterservice für Gewerbe & Immobilien in Süddeutschland. Haftungsübernahme, Schneeräumen & Objektbetreuung."
        keywords="Winterdienst, Hausmeisterservice, Schneeräumen, Streudienst, Objektbetreuung, Verkehrssicherungspflicht, AHAD Cleaning"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/winterdienst-hero.jpg" 
            alt="Winterdienst Schneeräumfahrzeug" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Shield className="w-4 h-4 text-[#8bf8ba]" />
              Sicherheit bei jedem Wetter
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Winterdienst und Hausmeisterservice
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              Wir sorgen für geräumte Wege, gestreute Flächen und die allgemeine 
              Ordnung in Ihrem Außenbereich in ganz Süddeutschland – zuverlässig und haftungssicher.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/kontakt" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Angebot anfordern
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Objektbetreuung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <CloudSnow className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Zuverlässiger Winterdienst</h3>
              <p className="text-[#424751] text-sm">Pünktliches Schneeräumen und Streuen von Gehwegen, Zufahrten und Parkplätzen gemäß den lokalen gesetzlichen Vorgaben.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Shield className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Haftungsübernahme</h3>
              <p className="text-[#424751] text-sm">Mit unserem Service übertragen Sie die Verkehrssicherungspflicht auf uns. Wir haften für eine ordnungsgemäße Ausführung.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <MapPin className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Hausmeisterservice</h3>
              <p className="text-[#424751] text-sm">Ganzjährige Objektbetreuung inklusive Grünanlagenpflege, Müllmanagement und Durchführung kleinerer Reparaturen.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="prose prose-lg prose-blue">
              <h2 className="text-3xl font-black mb-6 text-[#001c3b]">Rundum-Betreuung für Ihr Objekt</h2>
              <p className="text-[#424751] mb-6 leading-relaxed">
                Ein gepflegter Außenbereich ist nicht nur eine Frage der Optik, 
                sondern auch der Sicherheit. Wir übernehmen die Verkehrssicherungspflicht 
                im Winter und sorgen das ganze Jahr über für Ordnung und Werterhalt Ihrer Immobilie.
              </p>
              <h3 className="text-2xl font-bold text-[#001c3b] mt-8 mb-4">Unsere Leistungen im Überblick:</h3>
              <ul className="space-y-3 mb-8 text-[#424751] list-none pl-0">
                {[
                  'Zuverlässiger Winterdienst (Schneeräumen & Streuen)',
                  'Haftungsübernahme gemäß lokaler Ortssatzung',
                  'Regelmäßige Kontrolle der Außenanlagen & Haustechnik',
                  'Müllplatzreinigung & Abfallmanagement',
                  'Kleinere Instandsetzungen & Reparaturen',
                  'Grünflächenpflege, Heckenschnitt & Laubentfernung'
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="text-[#2ca06a] w-6 h-6 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-[#424751]">
                Wir betreuen Objekte in der gesamten Region. Ob <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Winterdienst in Villingen-Schwenningen</Link> oder <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Hausmeisterservice in Donaueschingen</Link> – auf AHAD Cleaning können Sie sich verlassen.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-md">
                  <img src="/images/winterdienst-gehweg.jpg" alt="Verschneiter Gehweg Räumung" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8 bg-[#f7f9fb] rounded-3xl border border-gray-100">
                  <Shield className="w-10 h-10 text-[#004888] mb-4" />
                  <h4 className="font-bold text-[#001c3b]">Haftungssicher</h4>
                  <p className="text-sm text-[#424751] mt-2">Rechtssichere Durchführung und Übernahme der Verkehrssicherungspflicht.</p>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="p-8 bg-[#001c3b] text-white rounded-3xl shadow-lg">
                  <CloudSnow className="w-10 h-10 text-[#8bf8ba] mb-4" />
                  <h4 className="font-bold">Winterdienst</h4>
                  <p className="text-sm text-blue-100 mt-2">Einsatzbereitschaft rund um die Uhr bei Schnee und Eisglätte.</p>
                </div>
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-md">
                  <img src="/images/winterdienst-instandhaltung.jpg" alt="Hausmeisterservice Instandhaltung" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zu Winterdienst & Hausmeisterservice</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Objektbetreuung gesucht?</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Wir sorgen für den Werterhalt und die Sicherheit Ihrer Außenanlagen. Kontaktieren Sie uns für ein individuelles Angebot.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Kontakt aufnehmen
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
