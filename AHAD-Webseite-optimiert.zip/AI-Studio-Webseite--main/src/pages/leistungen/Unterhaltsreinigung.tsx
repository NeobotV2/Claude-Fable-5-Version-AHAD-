import { motion } from 'motion/react';
import { LayoutDashboard, CheckCircle2, ArrowRight, Clock, ShieldCheck, Leaf, ChevronDown, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';
import ServiceAreas from '@/components/ServiceAreas';

export default function Unterhaltsreinigung() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Was gehört zur Unterhaltsreinigung?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Zur Unterhaltsreinigung gehören regelmäßige Reinigungsarbeiten wie das Staubsaugen und Wischen von Böden, die Oberflächenreinigung von Schreibtischen und Regalen, die hygienische Reinigung von Sanitäranlagen, das Leeren von Mülleimern sowie die Reinigung von Teeküchen und Aufenthaltsräumen."
        }
      },
      {
        "@type": "Question",
        "name": "Wie oft sollte eine Unterhaltsreinigung durchgeführt werden?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Die Häufigkeit hängt von der Nutzung und Art des Gebäudes ab. In stark frequentierten Büros oder medizinischen Einrichtungen ist eine tägliche Reinigung empfehlenswert. Bei geringerer Nutzung kann eine Reinigung 1-3 Mal pro Woche ausreichend sein. Wir beraten Sie gerne zu einem passenden Reinigungsintervall."
        }
      },
      {
        "@type": "Question",
        "name": "Bieten Sie die Unterhaltsreinigung auch außerhalb der Geschäftszeiten an?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja, wir passen uns flexibel an Ihre Betriebszeiten an. Unsere Reinigungsteams können früh morgens, abends oder am Wochenende eingesetzt werden, um Ihren Arbeitsablauf nicht zu stören."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Unterhaltsreinigung für Unternehmen | AHAD Cleaning" 
        description="Professionelle Unterhaltsreinigung für Büros, Gewerbe und Industrie in Süddeutschland. Zuverlässig, hygienisch und werterhaltend. Jetzt Angebot anfordern!"
        keywords="Unterhaltsreinigung Unternehmen, Büroreinigung, regelmäßige Reinigung, Gebäudereinigung Süddeutschland, AHAD Cleaning"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/unterhaltsreinigung-hero.jpg" 
            alt="Professionelle Büroreinigung und Unterhaltsreinigung" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <LayoutDashboard className="w-4 h-4 text-[#8bf8ba]" />
              Unterhaltsreinigung
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Professionelle Unterhaltsreinigung für Ihr Unternehmen
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              Für Büros, Verwaltung und laufend genutzte Flächen in Süddeutschland. Wir sichern die sichtbare Grundordnung 
              und hygienische Sauberkeit durch klare Intervalle und feste Zuständigkeiten.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/angebot" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Angebot anfordern
              </Link>
              <Link to="/kontakt" className="px-8 py-4 bg-white/10 text-white font-bold rounded-xl hover:bg-white/20 transition-all border border-white/20">
                Beratungsgespräch
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Unterhaltsreinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Clock className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Flexible Zeiten</h3>
              <p className="text-[#424751] text-sm">Reinigung außerhalb Ihrer Geschäftszeiten, um den Betriebsablauf nicht zu stören. Täglich, wöchentlich oder nach Bedarf.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <ShieldCheck className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Geprüfte Qualität</h3>
              <p className="text-[#424751] text-sm">Regelmäßige Qualitätskontrollen durch unsere Objektleiter und Einsatz von fest angestelltem Fachpersonal.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Leaf className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Nachhaltigkeit</h3>
              <p className="text-[#424751] text-sm">Verwendung von umweltschonenden Reinigungsmitteln und ressourceneffizienten Verfahren für eine grüne Zukunft.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-4xl mx-auto px-4 prose prose-lg prose-blue">
          <h2 className="text-3xl font-black text-[#001c3b] mb-6">Was umfasst die professionelle Unterhaltsreinigung?</h2>
          <p className="text-[#424751] mb-6">
            Die Unterhaltsreinigung ist das Fundament für ein gepflegtes Erscheinungsbild Ihres Unternehmens. Sie umfasst alle sich wiederholenden Reinigungsarbeiten, die in festgelegten Zeitabständen durchgeführt werden. Ziel ist es, den gewünschten Zustand des Gebäudes zu erhalten, die Hygiene zu sichern und den Werterhalt der Immobilie zu fördern.
          </p>
          
          <h3 className="text-2xl font-bold text-[#001c3b] mt-10 mb-4">Typische Leistungen der Unterhaltsreinigung:</h3>
          <ul className="space-y-3 mb-8 text-[#424751]">
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2ca06a] flex-shrink-0 mt-0.5" />
              <span><strong>Bodenreinigung:</strong> Staubsaugen von textilen Belägen, Feucht- oder Nasswischen von Hartböden.</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2ca06a] flex-shrink-0 mt-0.5" />
              <span><strong>Oberflächenreinigung:</strong> Abstauben und feuchtes Abwischen von Schreibtischen, Regalen, Fensterbänken und Türen.</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2ca06a] flex-shrink-0 mt-0.5" />
              <span><strong>Sanitärreinigung:</strong> Hygienische Reinigung und Desinfektion von WCs, Waschbecken und Spiegeln inkl. Auffüllen von Verbrauchsmaterialien.</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2ca06a] flex-shrink-0 mt-0.5" />
              <span><strong>Küchenreinigung:</strong> Reinigung von Teeküchen, Aufenthaltsräumen, Spülen und Arbeitsflächen.</span>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="w-6 h-6 text-[#2ca06a] flex-shrink-0 mt-0.5" />
              <span><strong>Abfallentsorgung:</strong> Leeren von Papierkörben und Mülleimern sowie fachgerechte Mülltrennung.</span>
            </li>
          </ul>

          <h2 className="text-3xl font-black text-[#001c3b] mt-12 mb-6">Warum AHAD Cleaning für Ihre Büroreinigung?</h2>
          <p className="text-[#424751] mb-6">
            Als erfahrener Dienstleister in Süddeutschland verstehen wir, dass jedes Unternehmen individuelle Anforderungen hat. Ein sauberes Arbeitsumfeld motiviert nicht nur Ihre Mitarbeiter, sondern hinterlässt auch bei Kunden und Partnern einen professionellen Eindruck.
          </p>
          <p className="text-[#424751] mb-6">
            Wir bieten unsere Dienstleistungen flächendeckend an. Egal ob Sie eine <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Gebäudereinigung in Villingen-Schwenningen</Link>, <Link to="/standorte/stuttgart" className="text-[#004888] font-bold hover:underline">Stuttgart</Link>, <Link to="/standorte/konstanz" className="text-[#004888] font-bold hover:underline">Konstanz</Link> oder <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Rottweil</Link> suchen – unsere regionalen Teams sind schnell vor Ort und garantieren höchste Qualitätsstandards nach dem AHAD System.
          </p>

          <div className="bg-[#f7f9fb] p-10 rounded-3xl border border-gray-100 shadow-sm mt-12">
            <h3 className="text-2xl font-black text-[#001c3b] mb-8 flex items-center gap-3">
              <Zap className="text-[#004888] w-8 h-8" />
              Ergänzende Leistungen
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { title: 'Glas- & Fassadenreinigung', path: '/leistungen/glas-fassadenreinigung' },
                { title: 'Sonderreinigung', path: '/leistungen/sonderreinigung' },
                { title: 'Industriereinigung', path: '/leistungen/industrie-produktionsreinigung' },
                { title: 'Winterdienst', path: '/leistungen/winterdienst' }
              ].map((service, i) => (
                <Link 
                  key={i} 
                  to={service.path}
                  className="flex items-center justify-between p-4 bg-white rounded-xl border border-gray-100 hover:border-[#004888] hover:shadow-md transition-all group no-underline"
                >
                  <span className="font-bold text-[#424751] group-hover:text-[#004888] transition-colors">{service.title}</span>
                  <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-[#004888] transition-all group-hover:translate-x-1" />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      <ServiceAreas />

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Unterhaltsreinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Bereit für ein sauberes Arbeitsumfeld?</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Lassen Sie uns gemeinsam ein Reinigungskonzept entwickeln, das perfekt zu Ihrem Unternehmen passt.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt unverbindlich anfragen
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
