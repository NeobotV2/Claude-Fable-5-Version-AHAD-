import { motion } from 'motion/react';
import { Clock, CheckCircle2, ArrowRight, Building2, Hammer, Sparkles, ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function Baureinigung() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Was ist der Unterschied zwischen Baugrobreinigung und Baufeinreinigung?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Die Baugrobreinigung (auch Zwischenreinigung) findet während der Bauphase statt. Hierbei entfernen wir Bauschutt, Verpackungsmaterial und groben Schmutz, um sichere Arbeitsbedingungen für die Handwerker zu gewährleisten. Die Baufeinreinigung (Bauendreinigung) erfolgt nach Abschluss aller Bauarbeiten und bereitet das Gebäude schlüsselfertig für den Bezug vor."
        }
      },
      {
        "@type": "Question",
        "name": "Wann ist der beste Zeitpunkt für die Bauendreinigung?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Die Bauendreinigung sollte idealerweise nach Abschluss aller handwerklichen Tätigkeiten und kurz vor der Bauabnahme oder dem Einzug stattfinden. Wir stimmen uns eng mit Ihrer Bauleitung ab, um den perfekten Zeitpunkt im Bauzeitenplan zu finden."
        }
      },
      {
        "@type": "Question",
        "name": "Entsorgen Sie auch den anfallenden Bauschutt?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja, im Rahmen der Baugrobreinigung kümmern wir uns um die fachgerechte Sammlung und Sortierung von Bauschutt, Verpackungsmaterialien und Reststoffen. Die genauen Entsorgungswege stimmen wir im Vorfeld mit Ihnen ab."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Baureinigung & Bauendreinigung | AHAD Cleaning" 
        description="Professionelle Baureinigung für Gewerbe und Industrie in Süddeutschland. Baugrobreinigung, Baufeinreinigung und termingerechte Bauendreinigung. Jetzt anfragen!"
        keywords="Baureinigung, Bauendreinigung, Baugrobreinigung, Baufeinreinigung, Baustellenreinigung, AHAD Cleaning"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/baureinigung-hero.jpg" 
            alt="Professionelle Baureinigung auf einer Großbaustelle" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Clock className="w-4 h-4 text-[#8bf8ba]" />
              Terminfeste Übergabe
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Baureinigung für Gewerbe und Industrie
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              Wir begleiten Ihr Bauprojekt in Süddeutschland von der Grobreinigung während der Bauphase 
              bis zur schlüsselfertigen Bauendreinigung für eine reibungslose Inbetriebnahme.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/kontakt" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Projektanfrage stellen
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Baureinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Hammer className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Baugrobreinigung</h3>
              <p className="text-[#424751] text-sm">Entfernung von Bauschutt, Verpackungsmaterial und grobem Schmutz während der Bauphase für sichere Arbeitsbedingungen.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Sparkles className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Baufeinreinigung</h3>
              <p className="text-[#424751] text-sm">Die schlüsselfertige Bauendreinigung vor der Übergabe. Entfernung von Handwerkerschmutz, Bohrstaub und Farbspritzern.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Clock className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Termintreue</h3>
              <p className="text-[#424751] text-sm">Nahtlose Integration in Ihren Bauzeitenplan. Wir garantieren eine pünktliche Fertigstellung für Ihre Bauabnahme.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="prose prose-lg prose-blue">
              <h2 className="text-3xl font-black mb-6 text-[#001c3b]">Vom Rohbau zum bezugsfertigen Objekt</h2>
              <p className="text-[#424751] mb-6 leading-relaxed">
                Bauprojekte sind zeitkritisch und erfordern höchste Flexibilität. Wir integrieren uns nahtlos in Ihren 
                Bauzeitenplan und sorgen dafür, dass Staub, Bauschutt und 
                Verschmutzungen termingerecht verschwinden. Eine professionelle Baureinigung ist die Voraussetzung für eine erfolgreiche Bauabnahme und deckt oft verdeckte Baumängel rechtzeitig auf.
              </p>
              <h3 className="text-2xl font-bold text-[#001c3b] mt-8 mb-4">Unsere Leistungen im Detail:</h3>
              <ul className="space-y-3 mb-8 text-[#424751] list-none pl-0">
                {[
                  'Baugrobreinigung (baubegleitende Reinigung)',
                  'Baufeinreinigung / Bauendreinigung vor der Abnahme',
                  'Fachgerechte Entfernung von Bauschutt & Verpackungsmaterial',
                  'Erstreinigung von Glasfronten, Rahmen & Fenstern',
                  'Einpflege und Spezialreinigung von Bodenbelägen',
                  'Reinigung von Sanitäranlagen und Fliesen'
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="text-[#2ca06a] w-6 h-6 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-[#424751]">
                Wir unterstützen Bauherren, Architekten und Bauunternehmen in der gesamten Region. Ob <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Baureinigung in Villingen-Schwenningen</Link> oder <Link to="/standorte/stuttgart" className="text-[#004888] font-bold hover:underline">Bauendreinigung in Stuttgart</Link> – AHAD Cleaning ist Ihr zuverlässiger Partner am Bau.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-md">
                  <img src="/images/baureinigung-baustelle.jpg" alt="Baustelle" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8 bg-[#f7f9fb] rounded-3xl border border-gray-100">
                  <Clock className="w-10 h-10 text-[#004888] mb-4" />
                  <h4 className="font-bold text-[#001c3b]">Termintreue</h4>
                  <p className="text-sm text-[#424751] mt-2">Pünktliche Fertigstellung garantiert, auch bei engen Zeitplänen.</p>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="p-8 bg-[#001c3b] text-white rounded-3xl shadow-lg">
                  <Hammer className="w-10 h-10 text-[#8bf8ba] mb-4" />
                  <h4 className="font-bold">Grobreinigung</h4>
                  <p className="text-sm text-blue-100 mt-2">Effiziente Bauschuttbeseitigung und Freiräumen der Arbeitsflächen.</p>
                </div>
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-md">
                  <img src="/images/baureinigung-endreinigung.jpg" alt="Bauendreinigung" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Baureinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Bereit für die Bauabnahme?</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Kontaktieren Sie uns für eine Objektbesichtigung und ein individuelles Angebot für Ihr Bauprojekt.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Angebot anfordern
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
