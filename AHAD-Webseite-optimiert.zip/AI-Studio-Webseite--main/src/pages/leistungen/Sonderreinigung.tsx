import { motion } from 'motion/react';
import { Sparkles, CheckCircle2, ArrowRight, Clock, Settings2, Shield, ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function Sonderreinigung() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Was fällt unter den Begriff Sonderreinigung?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Die Sonderreinigung umfasst alle Reinigungsarbeiten, die über die regelmäßige Unterhaltsreinigung hinausgehen. Dazu gehören beispielsweise intensive Grundreinigungen von Bodenbelägen, die Reinigung nach Wasserschäden, Bauarbeiten oder Events, sowie spezielle Desinfektionsmaßnahmen und die Reinigung schwer zugänglicher Bereiche."
        }
      },
      {
        "@type": "Question",
        "name": "Bieten Sie auch Reinigungen während Betriebsschließungen oder Stillständen an?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja, wir sind spezialisiert auf Stillstandsservices für die Industrie. Wir nutzen geplante Produktionspausen oder Betriebsferien, um Maschinen, Anlagen und Hallen intensiv zu reinigen, ohne Ihre laufenden Prozesse zu stören."
        }
      },
      {
        "@type": "Question",
        "name": "Wie schnell können Sie bei Notfällen (z.B. Wasserschaden) reagieren?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Bei unvorhergesehenen Ereignissen wie Wasserschäden oder starken Verschmutzungen nach Havarien bemühen wir uns um schnellstmögliche Reaktionszeiten. Bitte kontaktieren Sie uns direkt telefonisch, um die Dringlichkeit und unsere Kapazitäten in Ihrer Region abzustimmen."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Sonderreinigung & Stillstandsservice | AHAD Cleaning" 
        description="Spezialisierte Sonderreinigung und Stillstandsservice für Industrie und Gewerbe in Süddeutschland. Grundreinigung, Desinfektion & Spezialverfahren."
        keywords="Sonderreinigung, Stillstandsservice, Grundreinigung, Industriereinigung, Spezialreinigung, AHAD Cleaning"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/sonderreinigung-hero.jpg" 
            alt="Spezialisierte Sonderreinigung Oberflächen" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Shield className="w-4 h-4 text-[#8bf8ba]" />
              Sonderlagen abdecken
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Sonderreinigung und Stillstandsservice
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              Für außergewöhnliche Verschmutzungen, periodische Grundreinigungen 
              oder geplante Betriebsstillstände – wir sind Ihr Partner für 
              Spezialeinsätze in ganz Süddeutschland.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/kontakt" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Sonderanfrage stellen
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Sonderreinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Sparkles className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Intensive Grundreinigung</h3>
              <p className="text-[#424751] text-sm">Tiefgehende Reinigung und Pflege von stark beanspruchten Flächen, die über die tägliche Unterhaltsreinigung hinausgeht.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Settings2 className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Stillstandsservice</h3>
              <p className="text-[#424751] text-sm">Effiziente Reinigung von Produktionsanlagen und Hallen während geplanter Betriebsferien oder Wartungsstillstände.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Shield className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Spezialverfahren</h3>
              <p className="text-[#424751] text-sm">Einsatz von speziellen Reinigungsmitteln, Maschinen und Techniken für hartnäckige Verschmutzungen und besondere Anforderungen.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="prose prose-lg prose-blue">
              <h2 className="text-3xl font-black mb-6 text-[#001c3b]">Spezialeinsätze nach Maß</h2>
              <p className="text-[#424751] mb-6 leading-relaxed">
                Manche Aufgaben lassen sich nicht in den täglichen Reinigungsplan 
                integrieren. Ob Grundreinigung von stark frequentierten Bodenbelägen, Reinigung von 
                Lüftungsanlagen oder komplexe Stillstandsservices in der Industrie – 
                wir planen und führen diese Spezialeinsätze präzise aus.
              </p>
              <h3 className="text-2xl font-bold text-[#001c3b] mt-8 mb-4">Unser Leistungsspektrum:</h3>
              <ul className="space-y-3 mb-8 text-[#424751] list-none pl-0">
                {[
                  'Intensive Grundreinigung & Neubeschichtung von Bodenbelägen',
                  'Reinigung von Industrieanlagen & Maschinen bei Stillstand',
                  'Entfettung & Reinigung von Lüftungssystemen',
                  'Tiefenreinigung von Teppichen & Polstern im Gewerbe',
                  'Spezielle Desinfektionsmaßnahmen nach Bedarf',
                  'Reinigung nach Wasserschäden, Havarien oder Events'
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="text-[#2ca06a] w-6 h-6 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-[#424751]">
                Wir sind flexibel und einsatzbereit in der gesamten Region. Ob <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Sonderreinigung in Rottweil</Link> oder ein geplanter <Link to="/standorte/villingen-schwenningen" className="text-[#004888] font-bold hover:underline">Stillstandsservice in Tuttlingen</Link> – AHAD Cleaning löst Ihre Reinigungsherausforderungen.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-md">
                  <img src="/images/sonderreinigung-boden.jpg" alt="Sonderreinigung Bodenbeläge" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8 bg-[#f7f9fb] rounded-3xl border border-gray-100">
                  <Clock className="w-10 h-10 text-[#004888] mb-4" />
                  <h4 className="font-bold text-[#001c3b]">Planbarkeit</h4>
                  <p className="text-sm text-[#424751] mt-2">Termingerechte Ausführung, abgestimmt auf Ihre Betriebszeiten.</p>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="p-8 bg-[#001c3b] text-white rounded-3xl shadow-lg">
                  <Settings2 className="w-10 h-10 text-[#8bf8ba] mb-4" />
                  <h4 className="font-bold">Expertise</h4>
                  <p className="text-sm text-blue-100 mt-2">Spezialverfahren und geschultes Personal für jede Lage.</p>
                </div>
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-md">
                  <img src="/images/sonderreinigung-maschinen.jpg" alt="Industriereinigung Maschinen" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Sonderreinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Sonderaufgabe für uns?</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Wir finden für jede Herausforderung das richtige Reinigungsverfahren. Kontaktieren Sie uns für eine individuelle Beratung.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Sonderanfrage stellen
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
