import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2, Building2, Factory, Microscope, LayoutDashboard, Settings2, ClipboardCheck, Search, ChevronDown, FileText, ChevronRight, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import SEO from '@/components/SEO';

const services = [
  {
    title: 'Unterhaltsreinigung',
    benefits: ['Weniger Beschwerden', 'Stabile Abläufe'],
    proof: 'Garantierte SLAs',
    icon: <LayoutDashboard className="text-[#004888] w-8 h-8" />,
    tag: 'NULL BESCHWERDEN',
    path: '/leistungen/unterhaltsreinigung',
    image: '/images/unterhaltsreinigung-hero.jpg'
  },
  {
    title: 'Glas- & Fassadenreinigung',
    benefits: ['Langfristiger Werterhalt', 'Keine Materialschäden'],
    proof: 'Sichtbarer Standard',
    icon: <Building2 className="text-[#004888] w-8 h-8" />,
    tag: 'WERTERHALT GARANTIERT',
    path: '/leistungen/glas-fassadenreinigung',
    image: '/images/glasreinigung-hero.jpg'
  },
  {
    title: 'Spezial- & Industriereinigung',
    benefits: ['Keine Produktionsausfälle', 'Gesetzeskonform'],
    proof: '100% Auditfähig',
    icon: <Microscope className="text-[#004888] w-8 h-8" />,
    tag: 'PROZESSINTEGRIERT',
    path: '/leistungen/industrie-produktionsreinigung',
    image: '/images/sonderreinigung-hero.jpg'
  }
];

const entlastung = [
  {
    title: 'Produktion und Industrie',
    description: 'Reinigung im laufenden Betrieb mit klaren Zuständigkeiten, festen Abläufen und sauberer Abstimmung mit Ihren internen Prozessen.',
    proof: 'Fokus auf störungsarme Ausführung, feste Teams und klare Eskalationswege',
    icon: <Factory className="w-8 h-8" />,
    image: '/images/industrie-hero.jpg'
  },
  {
    title: 'Medizintechnik und sensible Bereiche',
    description: 'Für Bereiche, in denen dokumentierte Leistung, nachvollziehbare Abläufe und hohe Prozesssicherheit entscheidend sind.',
    proof: 'Fokus auf Nachweise, Kontrolle und auditnahe Standards',
    icon: <Microscope className="w-8 h-8" />,
    image: '/images/medizintechnik-hero.jpg'
  },
  {
    title: 'Verwaltung und Bürostandorte',
    description: 'Saubere Flächen, verlässliche Routinen und weniger interner Abstimmungsaufwand für Empfang, Büros, Besprechungsräume und Sanitärbereiche.',
    proof: 'Fokus auf Verlässlichkeit, Sichtqualität und planbare Betreuung',
    icon: <Building2 className="w-8 h-8" />,
    image: '/images/buero-hero.jpg'
  }
];

const systemSteps = [
  { 
    id: 'A',
    title: 'Analyse', 
    subtitle: 'Objektlogik sauber erfassen.',
    description: 'Wir erfassen Flächen, Nutzung, Risiken und Reinigungsbedarf als belastbare Grundlage für Planung und Ausführung.', 
    icon: <Search className="w-8 h-8" /> 
  },
  { 
    id: 'H',
    title: 'Handling', 
    subtitle: 'Feste Teams, klare Zuständigkeiten.',
    description: 'Eingespielte Teams, definierte Abläufe und eine feste Objektleitung sichern die operative Ausführung ohne ständiges Nachsteuern.', 
    icon: <Settings2 className="w-8 h-8" /> 
  },
  { 
    id: 'A',
    title: 'Audit', 
    subtitle: 'Qualität regelmäßig prüfen.',
    description: 'Regelmäßige Kontrollen machen Leistung messbar und Abweichungen sichtbar, bevor daraus Reklamationen oder Auditprobleme entstehen.', 
    icon: <ClipboardCheck className="w-8 h-8" /> 
  },
  { 
    id: 'D',
    title: 'Dokumentation', 
    subtitle: 'Nachweise klar dokumentieren.',
    description: 'Checklisten, Leistungen und Kontrollen werden nachvollziehbar dokumentiert. Das schafft Transparenz, Nachweissicherheit und bessere Auditfähigkeit.', 
    icon: <Shield className="w-8 h-8" />, 
    highlight: true 
  }
];

export default function Home() {
  const AHAD_CLIENT_REFERENCES = [
    { name: 'Aesthetify by Dr. Rick & Dr. Nick', domain: 'aesthetify.de' },
    { name: 'Allianz', domain: 'allianz.de' },
    { name: 'Bareiss', domain: 'bareiss.com' },
    { name: 'BDT', domain: 'bdt.de' },
    { name: 'Bundesagentur für Arbeit', domain: 'arbeitsagentur.de' },
    { name: 'GOLDBECK', domain: 'goldbeck.de' },
    { name: 'Käppelehof', domain: 'kaeppelehof.de' },
    { name: 'Köster', domain: 'koester-bau.de' },
    { name: 'Kur- und Bäder GmbH Bad Dürrheim', domain: 'badduerrheim.de' },
    { name: 'naturenergie netze', domain: 'naturenergie-netze.de', logoUrl: 'https://www.naturenergie-netze.de/typo3conf/ext/sitecore/Resources/Public/img/naturenergie_netze-logo.svg' },
    { name: 'Schwarzwald Baar Kreis', domain: 'schwarzwald-baar-kreis.de', logoUrl: 'https://www.lrasbk.de/media/custom/2944_1_1_m.png' },
    { name: 'Südwest Messe', domain: 'suedwest-messe.de', logoUrl: 'https://www.suedwest-messe.de/fileadmin/data/sites/suedwest-messe-vs.de/Logo/suedwestmessevs_logo.png' }
  ];

  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": ["Organization", "LocalBusiness"],
    "@id": "https://ahad-cleaning.de/#organization",
    "name": "AHAD Cleaning Company GmbH",
    "url": "https://ahad-cleaning.de",
    "logo": "https://ahad-cleaning.de/logo.png",
    "image": "https://ahad-cleaning.de/og-image.jpg",
    "description": "Gebäudereinigung, Industriereinigung und Unterhaltsreinigung für Unternehmen in Villingen-Schwenningen, Stuttgart, Konstanz und Süddeutschland.",
    "telephone": "+49-7721-9447915",
    "email": "info@ahad-cleaning.de",
    "priceRange": "€€",
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      "opens": "08:00",
      "closes": "17:00"
    },
    "areaServed": [
      { "@type": "City", "name": "Villingen-Schwenningen" },
      { "@type": "City", "name": "Stuttgart" },
      { "@type": "City", "name": "Konstanz" },
      { "@type": "AdministrativeArea", "name": "Schwarzwald-Baar-Kreis" },
      { "@type": "AdministrativeArea", "name": "Baden-Württemberg" }
    ],
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": 48.0626,
      "longitude": 8.4937
    },
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+49-7721-9447915",
      "contactType": "customer service",
      "areaServed": "DE",
      "availableLanguage": "German"
    },
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Max-Planck-Straße 11",
      "addressLocality": "Villingen-Schwenningen",
      "postalCode": "78052",
      "addressCountry": "DE"
    },
    "sameAs": [
      "https://www.facebook.com/ahadcleaning",
      "https://www.instagram.com/ahadcleaning",
      "https://www.linkedin.com/company/ahadcleaning"
    ]
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Wie setzen sich Ihre Preise zusammen?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Unsere Preise basieren auf einem transparenten Leistungsverzeichnis. Wir berechnen nach tatsächlichem Aufwand, Quadratmetern und Reinigungsintervallen – ohne versteckte Kosten. Sie erhalten ein verbindliches Festpreisangebot."
        }
      },
      {
        "@type": "Question",
        "name": "Wie läuft ein Anbieterwechsel ab?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Geräuschlos und ohne Betriebsunterbrechung. Wir übernehmen die komplette Transition: Von der Bestandsaufnahme über die Einarbeitung des Personals bis zur Implementierung unseres Qualitätsmanagements."
        }
      },
      {
        "@type": "Question",
        "name": "Gibt es lange Mindestlaufzeiten?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Wir binden Kunden durch Leistung, nicht durch Knebelverträge. Nach einer fairen Probezeit bieten wir flexible Laufzeiten, die sich an Ihren unternehmerischen Bedürfnissen orientieren."
        }
      },
      {
        "@type": "Question",
        "name": "Wie sind Haftung und Sicherheit geregelt?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Wir sind umfassend betriebshaftpflichtversichert. Alle Mitarbeiter sind fest angestellt, sozialversichert und sicherheitsüberprüft. Schlüssel und Zugangscodes werden nach strengsten Sicherheitsprotokollen verwaltet."
        }
      },
      {
        "@type": "Question",
        "name": "Wie schnell ist eine Objektbesichtigung möglich?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "In der Regel können wir innerhalb von 48 Stunden einen Vor-Ort-Termin vereinbaren, um Ihr Objekt zu besichtigen und ein maßgeschneidertes Angebot zu erstellen."
        }
      },
      {
        "@type": "Question",
        "name": "Arbeiten Sie mit festen Ansprechpartnern?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja. Jedes Objekt wird von einer festen Objektleitung betreut. Sie haben immer einen direkten, kompetenten Ansprechpartner für alle Anliegen."
        }
      },
      {
        "@type": "Question",
        "name": "Wie wird die Qualität dokumentiert?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Wir nutzen digitale Checklisten und regelmäßige Audits durch unsere Objektleiter. Sie erhalten auf Wunsch lückenlose Reports über alle erbrachten Leistungen."
        }
      },
      {
        "@type": "Question",
        "name": "Übernehmen Sie auch Objekte im laufenden Betrieb?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Absolut. Unsere Teams sind darauf geschult, sich geräuschlos in Ihre Schicht- und Betriebslogik einzufügen, ohne Ihre Abläufe zu stören."
        }
      }
    ]
  };

  return (
    <div className="overflow-hidden">
      <SEO 
        title="Gebäudereinigung & Industriereinigung Villingen-Schwenningen | AHAD Cleaning" 
        description="AHAD Cleaning ist Ihr Partner für professionelle Gebäudereinigung, Industriereinigung und Unterhaltsreinigung in Villingen-Schwenningen, Stuttgart und Süddeutschland."
        keywords="Gebäudereinigung Villingen-Schwenningen, Industriereinigung Stuttgart, Unterhaltsreinigung, Glasreinigung Konstanz, Gebäudedienstleistungen"
        schema={[organizationSchema, faqSchema]}
      />
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-start lg:items-center bg-[#f7f9fb] pt-28 pb-20 lg:pt-32 lg:pb-32 overflow-hidden">
        
        {/* Neuer atmosphärischer Hintergrund */}
        <div className="absolute inset-0 z-0">
          {/* Entsättigtes, subtiles Architektur-Bild */}
          <img 
            src="/images/buero-hero.jpg" 
            alt="Moderne, saubere Architektur" 
            className="w-full h-full object-cover grayscale opacity-[0.07] mix-blend-multiply"
            referrerPolicy="no-referrer"
          />
          {/* Gradient für perfekte Textlesbarkeit */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#f7f9fb]/40 via-transparent to-[#f7f9fb] pointer-events-none" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-8 flex flex-col lg:grid lg:grid-cols-12 gap-8 relative z-10 w-full min-w-0">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="col-span-12 lg:col-span-8 min-w-0"
          >
            <span className="inline-block max-w-full break-words whitespace-normal bg-[#001c3b]/5 border border-[#001c3b]/10 px-3 sm:px-4 py-1.5 text-[10px] sm:text-[11px] font-black uppercase tracking-[0.1em] sm:tracking-[0.2em] text-[#004888] mb-6 rounded-sm shadow-sm">
              Gebäudereinigung für Industrie, Verwaltung und Mittelstand
            </span>
            
            <h1 className="text-[clamp(2.5rem,7vw,5.5rem)] font-black leading-[1.05] tracking-[-0.03em] text-[#001c3b] mb-6 break-words hyphens-auto">
              Struktur.<br />Sauberkeit.<br />Sicherheit.
            </h1>

            {/* Trust-Badge: ehrliche, konkrete Aussage statt Dummy-Avatare */}
            <div className="flex items-center gap-3 mb-6 bg-white w-fit max-w-full px-4 py-2 rounded-full shadow-sm border border-gray-100">
              <div className="w-7 h-7 rounded-full bg-[#2ca06a]/10 flex items-center justify-center flex-shrink-0">
                <Shield className="w-4 h-4 text-[#2ca06a]" />
              </div>
              <p className="text-xs font-semibold text-[#424751]">
                Über 80 betreute Objekte im Schwarzwald-Baar-Kreis und in Süddeutschland — von Allianz bis GOLDBECK.
              </p>
            </div>

            <p className="text-lg sm:text-xl text-[#424751] max-w-2xl font-medium leading-relaxed mb-8">
              Beenden Sie ständige Reklamationen und den internen Aufwand rund um Ihre Reinigung. Wir steuern Ausführung, Qualität und Rückmeldung so, dass Ihr Betrieb sauber läuft und Sie nicht nachfassen müssen.
            </p>
            
            <ul className="flex flex-col gap-3 mb-10">
              <li className="flex items-start sm:items-center gap-3 text-[#001c3b] font-bold text-sm sm:text-lg break-words whitespace-normal"><CheckCircle2 className="text-[#2ca06a] w-5 h-5 sm:w-6 sm:h-6 flex-shrink-0 mt-0.5 sm:mt-0" /> <span className="flex-1">24h Reaktionszeit garantiert</span></li>
              <li className="flex items-start sm:items-center gap-3 text-[#001c3b] font-bold text-sm sm:text-lg break-words whitespace-normal"><CheckCircle2 className="text-[#2ca06a] w-5 h-5 sm:w-6 sm:h-6 flex-shrink-0 mt-0.5 sm:mt-0" /> <span className="flex-1">Feste Objektleitung & dokumentierte Kontrollen</span></li>
              <li className="flex items-start sm:items-center gap-3 text-[#001c3b] font-bold text-sm sm:text-lg break-words whitespace-normal"><CheckCircle2 className="text-[#2ca06a] w-5 h-5 sm:w-6 sm:h-6 flex-shrink-0 mt-0.5 sm:mt-0" /> <span className="flex-1">Transparente & digitale Qualitätssicherung</span></li>
            </ul>

            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
              <Link to="/angebot" className="w-full sm:w-auto min-w-0 flex justify-center items-center bg-[#2ca06a] text-white px-4 sm:px-8 py-4 font-black text-xs sm:text-sm uppercase tracking-wider hover:bg-[#238054] transition-all text-center rounded-lg shadow-sm hover:shadow-md hover:-translate-y-[1px] break-words whitespace-normal focus:outline-none focus:ring-4 focus:ring-[#2ca06a]/50">
                Kostenloses Angebot
              </Link>
              <Link to="/leistungen" className="w-full sm:w-auto min-w-0 flex justify-center items-center bg-white border-2 border-[#e0e3e5] text-[#004888] px-4 sm:px-8 py-4 font-black text-xs sm:text-sm uppercase tracking-wider hover:border-[#004888] hover:bg-gray-50 transition-all text-center rounded-lg break-words whitespace-normal focus:outline-none focus:ring-4 focus:ring-[#001c3b]/20">
                Unsere Leistungen
              </Link>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="col-span-12 lg:col-span-4 flex flex-col justify-center gap-4 mt-16 lg:mt-0 min-w-0"
          >
            <div className="bg-white p-6 sm:p-8 border-l-4 border-[#004888] shadow-md rounded-r-xl hover:shadow-lg transition-shadow">
              <div className="text-3xl sm:text-4xl font-black text-[#004888] mb-2">80+</div>
              <div className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-[#424751] break-words">Qualifizierte Mitarbeitende</div>
            </div>
            <div className="bg-white p-6 sm:p-8 border-l-4 border-[#2ca06a] shadow-md rounded-r-xl hover:shadow-lg transition-shadow">
              <div className="text-3xl sm:text-4xl font-black text-[#2ca06a] mb-2">3</div>
              <div className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-[#424751] break-words">Regionale Standorte</div>
            </div>
            <div className="bg-white p-6 sm:p-8 border-l-4 border-[#004888] shadow-md rounded-r-xl hover:shadow-lg transition-shadow">
              <div className="text-3xl sm:text-4xl font-black text-[#004888] mb-2">15+</div>
              <div className="text-[10px] sm:text-xs font-bold uppercase tracking-widest text-[#424751] break-words">Jahre Erfahrung</div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* References & Trust */}
      <section className="py-16 lg:py-24 bg-white border-b border-gray-100 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 mb-12 text-center">
          <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Vertrauen durch Leistung</span>
          <h2 className="text-3xl font-black tracking-tight text-[#001c3b]">Erfolgreiche Partnerschaften</h2>
        </div>
        
        {/* Marquee */}
        <div 
          className="flex overflow-hidden mb-16 marquee-container"
          style={{ maskImage: 'linear-gradient(to right, transparent, black 10%, black 90%, transparent)', WebkitMaskImage: 'linear-gradient(to right, transparent, black 10%, black 90%, transparent)' }}
        >
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex animate-marquee whitespace-nowrap shrink-0 gap-16 px-8 items-center py-4">
              {AHAD_CLIENT_REFERENCES.map((ref: any, index) => (
                <a 
                  key={`${i}-${index}`} 
                  href={`https://${ref.domain}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center justify-center cursor-pointer"
                  title={`Besuche ${ref.name}`}
                >
                  <img 
                    key={ref.logoUrl || ref.name}
                    src={ref.logoUrl || `https://logo.clearbit.com/${ref.domain}`} 
                    alt={`${ref.name} Logo`}
                    title={ref.logoUrl || ref.name}
                    className="h-10 w-auto object-contain max-w-[150px] reference-logo"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      if (!target.src.includes('google.com')) {
                        target.src = `https://www.google.com/s2/favicons?domain=${ref.domain}&sz=128`;
                      }
                    }}
                  />
                </a>
              ))}
            </div>
          ))}
        </div>
      </section>

      {/* System Section (Differenzierung) */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white overflow-hidden relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 relative z-10">
          <div className="text-center mb-20">
            <span className="text-[#8bf8ba] font-bold text-sm uppercase tracking-wider mb-4 block">Ihr Wettbewerbsvorteil</span>
            <h2 className="text-3xl lg:text-5xl font-black tracking-tight">Das <span className="font-logo text-[#8bf8ba] uppercase">AHAD</span> System</h2>
            <p className="mt-6 text-lg text-blue-100 max-w-2xl mx-auto">Vier systematische Schritte, die Zufall durch messbare Qualität ersetzen.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12 relative">
            <div className="hidden lg:block absolute top-12 left-[10%] w-[80%] h-0.5 bg-white/10 -z-10" />
            {systemSteps.map((step, index) => (
              <motion.div 
                key={step.title} 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="flex flex-col items-center text-center bg-white/5 backdrop-blur-sm p-8 rounded-2xl border border-white/10 relative group overflow-hidden hover:bg-white/10 transition-all duration-300"
              >
                <div className="text-5xl font-black text-white/5 absolute top-4 right-4 z-0 group-hover:text-white/10 transition-colors pointer-events-none">
                  {step.id}
                </div>

                <div className="absolute -top-4 -left-4 w-8 h-8 bg-[#004888] rounded-full flex items-center justify-center text-white font-bold text-sm border border-white/20 z-10">
                  {index + 1}
                </div>
                <div className={cn(
                  "w-20 h-20 flex items-center justify-center mb-6 rounded-2xl shadow-inner relative z-10 transition-colors duration-500",
                  step.highlight ? "bg-[#2ca06a] text-white" : "bg-white/10 text-[#8bf8ba]"
                )}>
                  {step.icon}
                </div>
                <h5 className="text-xl font-black mb-2 text-white relative z-10 break-words hyphens-auto">{step.title}</h5>
                <p className="text-[#8bf8ba] font-bold text-sm mb-4 relative z-10 break-words hyphens-auto">{step.subtitle}</p>
                <p className="text-blue-100 text-sm leading-relaxed relative z-10 break-words hyphens-auto">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section (Business Outcomes) */}
      <section className="py-20 lg:py-32 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="mb-16 lg:mb-24 flex flex-col md:flex-row md:items-end justify-between gap-8">
            <div>
              <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Ergebnisse statt Tätigkeiten</span>
              <h2 className="text-3xl lg:text-5xl font-black tracking-tight text-[#001c3b] mb-6">Unsere Leistungen</h2>
              <div className="w-24 h-1.5 bg-[#2ca06a] rounded-full" />
            </div>
            <p className="max-w-md text-[#424751] font-medium text-lg">
              Wir verkaufen keine Reinigungsstunden, sondern stabile Prozesse, Werterhalt und Rechtssicherheit für Ihr Gebäude.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <motion.div 
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="h-full"
              >
                <Link 
                  to={service.path}
                  className="bg-[#f7f9fb] p-10 group hover:bg-[#004888] transition-all duration-500 rounded-2xl border border-gray-100 flex flex-col h-full block relative overflow-hidden"
                >
                  {/* Background Image */}
                  <div className="absolute inset-0 z-0">
                    <img src={service.image} alt={service.title} className="w-full h-full object-cover opacity-50 group-hover:opacity-20 transition-opacity duration-500" />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#f7f9fb] via-[#f7f9fb]/90 to-white/30 group-hover:from-[#004888] group-hover:via-[#004888]/90 group-hover:to-[#004888]/40 transition-colors duration-500"></div>
                  </div>

                  <div className="absolute top-0 right-0 w-32 h-32 bg-white rounded-bl-full -mr-16 -mt-16 transition-transform duration-500 group-hover:scale-150 opacity-50 z-0"></div>
                  
                  <div className="mb-8 group-hover:text-white transition-colors duration-500 bg-white group-hover:bg-white/10 w-16 h-16 rounded-xl flex items-center justify-center shadow-sm relative z-10">
                    {service.icon}
                  </div>
                  <h3 className="text-2xl font-black mb-6 text-[#001c3b] group-hover:text-white transition-colors duration-500 relative z-10">{service.title}</h3>
                  
                  <ul className="mb-8 space-y-3 flex-grow relative z-10">
                    {service.benefits.map((benefit, i) => (
                      <li key={i} className="flex items-start text-[#424751] group-hover:text-blue-100 text-sm font-medium transition-colors duration-500">
                        <CheckCircle2 className="w-5 h-5 text-[#2ca06a] group-hover:text-[#8bf8ba] mr-3 flex-shrink-0 transition-colors duration-500" />
                        {benefit}
                      </li>
                    ))}
                    <li className="flex items-center text-[#001c3b] group-hover:text-white text-sm font-bold mt-6 pt-6 border-t border-gray-200 group-hover:border-blue-800 transition-colors duration-500">
                      <Shield className="w-5 h-5 text-[#004888] group-hover:text-[#8bf8ba] mr-3 flex-shrink-0 transition-colors duration-500" />
                      {service.proof}
                    </li>
                  </ul>

                  <div className="flex items-center justify-between mt-auto pt-6 border-t border-gray-200 group-hover:border-blue-800 transition-colors duration-500 relative z-10">
                    <span className="text-[11px] font-black tracking-widest text-[#2ca06a] group-hover:text-[#8bf8ba] uppercase">
                      {service.tag}
                    </span>
                    <ArrowRight className="text-[#004888] group-hover:text-white transition-colors duration-500" size={20} />
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Link to="/leistungen" className="inline-flex items-center gap-2 text-[#004888] font-bold hover:text-[#1e60a9] transition-colors">
              Alle Leistungen entdecken <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Wo AHAD im Alltag entlastet (Replaces Testimonials and Industries) */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb] border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="mb-16 text-center max-w-3xl mx-auto">
            <h2 className="text-3xl lg:text-5xl font-black tracking-tight text-[#001c3b] mb-6">Wo AHAD im Alltag entlastet</h2>
            <p className="text-lg text-[#424751] font-medium leading-relaxed">
              AHAD arbeitet dort, wo Ausfälle, Reklamationen und fehlende Nachweise schnell zum Problem werden. Entscheidend ist nicht nur Sauberkeit, sondern stabile Ausführung im laufenden Betrieb.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {entlastung.map((item, index) => (
              <motion.div 
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 flex flex-col h-full hover:shadow-md transition-all duration-300 relative overflow-hidden"
              >
                {/* Background Image */}
                <div className="absolute inset-0 z-0">
                  <img src={item.image} alt={item.title} className="w-full h-full object-cover opacity-50" />
                  <div className="absolute inset-0 bg-gradient-to-t from-white via-white/90 to-white/30"></div>
                </div>

                <div className="w-16 h-16 bg-[#f7f9fb] text-[#004888] rounded-2xl flex items-center justify-center mb-8 shadow-sm relative z-10">
                  {item.icon}
                </div>
                
                <h3 className="text-xl font-black text-[#001c3b] mb-4 break-words hyphens-auto relative z-10">{item.title}</h3>
                <p className="text-[#424751] font-medium text-sm leading-relaxed mb-8 flex-grow break-words hyphens-auto relative z-10">
                  {item.description}
                </p>
                
                <div className="pt-6 border-t border-gray-200 mt-auto relative z-10">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-[#2ca06a] flex-shrink-0 mt-0.5" />
                    <p className="text-sm font-bold text-[#004888] leading-snug break-words hyphens-auto">
                      {item.proof}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center bg-white p-10 rounded-2xl border border-gray-100 shadow-sm max-w-4xl mx-auto">
            <h3 className="text-2xl font-black text-[#001c3b] mb-4">Sie möchten wissen, wie das für Ihr Objekt aussieht?</h3>
            <p className="text-[#424751] font-medium mb-8">
              Unverbindliche Ersteinschätzung mit Blick auf Umfang, Risiken und sinnvolle Reinigungslogik.
            </p>
            <Link 
              to="/angebot" 
              className="inline-flex items-center justify-center bg-[#2ca06a] text-white px-8 py-4 font-black text-sm uppercase tracking-wider hover:bg-[#238054] transition-all rounded-lg shadow-sm hover:shadow-md hover:-translate-y-[1px]"
            >
              Objekt bewerten lassen
            </Link>
          </div>
        </div>
      </section>

      {/* Express-Angebot CTA */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#004888] text-white p-6 sm:p-8 md:p-12 lg:p-16 rounded-[2rem] shadow-xl relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">
              <FileText size={160} />
            </div>
            <div className="max-w-2xl relative z-10">
              <span className="text-[#8bf8ba] font-bold tracking-wider uppercase text-sm mb-4 block">Handeln Sie jetzt</span>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-black mb-8 tracking-tight">Express-Angebot anfordern</h2>
              
              <ul className="text-base sm:text-lg md:text-xl text-blue-100 mb-10 space-y-4 font-medium">
                <li className="flex items-start sm:items-center gap-3"><CheckCircle2 className="text-[#8bf8ba] w-6 h-6 flex-shrink-0" /> Schnelle Erstindikation innerhalb von 24h</li>
                <li className="flex items-start sm:items-center gap-3"><CheckCircle2 className="text-[#8bf8ba] w-6 h-6 flex-shrink-0" /> Vor-Ort-Besichtigung optional möglich</li>
                <li className="flex items-start sm:items-center gap-3"><CheckCircle2 className="text-[#8bf8ba] w-6 h-6 flex-shrink-0" /> 100% unverbindlich und kostenfrei</li>
              </ul>

              <Link 
                to="/angebot" 
                className="inline-flex flex-wrap justify-center items-center gap-2 bg-[#2ca06a] text-white px-6 sm:px-8 py-4 rounded-xl font-bold hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px] w-full sm:w-auto min-w-0 text-center"
              >
                Jetzt Angebot anfordern <ChevronRight size={20} className="flex-shrink-0" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="pt-20 pb-32 lg:pt-32 lg:pb-48 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4 sm:px-8">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Klartext</span>
            <h2 className="text-3xl lg:text-5xl font-black tracking-tight text-[#001c3b]">Häufige Fragen</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
