import { motion } from 'motion/react';
import { LayoutDashboard, Factory, Microscope, Building2, Sparkles, Clock, ArrowRight, ChevronRight, CheckCircle2, ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

const leistungen = [
  {
    title: 'Unterhaltsreinigung',
    description: 'Systematische und kontinuierliche Pflege Ihrer Räumlichkeiten. Wir definieren Intervalle und Standards exakt nach der Nutzung Ihrer Flächen, um ein stets repräsentatives und hygienisches Umfeld zu garantieren.',
    icon: <LayoutDashboard className="w-8 h-8" />,
    path: '/leistungen/unterhaltsreinigung',
    tag: 'BÜRO & VERWALTUNG',
    features: ['Individuelle Reinigungspläne', 'Feste Ansprechpartner', 'Qualitätssicherung']
  },
  {
    title: 'Industrie- & Produktionsreinigung',
    description: 'Technische Reinigung in anspruchsvollen, produktionsnahen Umfeldern. Wir integrieren unsere Prozesse nahtlos in Ihre Schichtlogik, um Stillstandzeiten zu minimieren und Arbeitssicherheit zu maximieren.',
    icon: <Factory className="w-8 h-8" />,
    path: '/leistungen/industrie-produktionsreinigung',
    tag: 'PROZESSINTEGRIERT',
    features: ['Maschinen- & Anlagenreinigung', 'Schichtbegleitende Reinigung', 'Arbeitssicherheit']
  },
  {
    title: 'Glas- & Fassadenreinigung',
    description: 'Professionelle Reinigung für den Werterhalt und die repräsentative Optik Ihrer Gebäudehülle. Wir nutzen modernste Technik für streifenfreie Ergebnisse, auch an schwer zugänglichen Stellen.',
    icon: <Building2 className="w-8 h-8" />,
    path: '/leistungen/glas-fassadenreinigung',
    tag: 'WERTERHALT',
    features: ['Osmose-Verfahren', 'Hubsteiger-Einsatz', 'Rahmenreinigung']
  },
  {
    title: 'Baureinigung',
    description: 'Termingerechte und gründliche Reinigung für Neubauten, Umbauten und Sanierungen. Von der Baugrobreinigung bis zur Baufeinreinigung sorgen wir für eine pünktliche und saubere Übergabe.',
    icon: <Clock className="w-8 h-8" />,
    path: '/leistungen/baureinigung',
    tag: 'TERMINFEST',
    features: ['Baugrobreinigung', 'Baufeinreinigung', 'Flexible Einsatzzeiten']
  },
  {
    title: 'Medizintechnik & Reinraum',
    description: 'Höchste Disziplin, spezielle Schulungen und lückenlose Dokumentation für sensible Produktions- und Forschungsbereiche. Wir erfüllen höchste Hygiene- und Qualitätsstandards.',
    icon: <Microscope className="w-8 h-8" />,
    path: '/leistungen/medizintechnik-reinigung',
    tag: 'DOKUMENTIERT',
    features: ['ISO-konforme Prozesse', 'Geschultes Fachpersonal', 'Lückenlose Dokumentation']
  },
  {
    title: 'Sonderreinigung',
    description: 'Spezialreinigungen für außergewöhnliche Verschmutzungen, besondere Materialien oder geplante Stillstandsservices. Wir bieten maßgeschneiderte Lösungen für komplexe Reinigungsherausforderungen.',
    icon: <Sparkles className="w-8 h-8" />,
    path: '/leistungen/sonderreinigung-stillstandsservice',
    tag: 'PLANBAR',
    features: ['Grundreinigung', 'Teppichreinigung', 'Stillstandsservice']
  },
  {
    title: 'Winterdienst & Hausmeister',
    description: 'Zuverlässige und ergänzende Objektbetreuung für Sicherheit und Ordnung im Außen- und Innenbereich. Wir kümmern uns um kleine Reparaturen, Kontrollgänge und die Verkehrssicherungspflicht im Winter.',
    icon: <Clock className="w-8 h-8" />,
    path: '/leistungen/winterdienst-hausmeisterservice',
    tag: 'OBJEKTBETREUUNG',
    features: ['24/7 Rufbereitschaft', 'Verkehrssicherung', 'Kleinreparaturen']
  }
];

export default function Leistungen() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Welche Reinigungsleistungen bietet AHAD Cleaning an?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "AHAD Cleaning bietet ein umfassendes Portfolio an Gebäudedienstleistungen: Unterhaltsreinigung für Büros, spezialisierte Industrie- und Produktionsreinigung, Glas- und Fassadenreinigung, Baureinigung, Medizintechnik- und Reinraumreinigung, Sonderreinigungen sowie Winterdienst und Hausmeisterservice."
        }
      },
      {
        "@type": "Question",
        "name": "Wie werden die Reinigungsintervalle festgelegt?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Wir setzen nicht auf starre Standardpakete. Die Reinigungsintervalle und Leistungsverzeichnisse werden individuell nach einer Vor-Ort-Analyse, der tatsächlichen Nutzung Ihrer Flächen und Ihrer spezifischen Betriebslogik (z.B. Schichtpläne) entwickelt."
        }
      },
      {
        "@type": "Question",
        "name": "Bieten Sie auch spezialisierte Reinigungen für die Industrie an?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja, wir sind Experten für Industriereinigung. Dies umfasst die Reinigung von Produktionshallen, die fachgerechte Maschinen- und Anlagenreinigung sowie die Entfettung von Industrieböden – alles unter strenger Einhaltung von Arbeitssicherheitsvorschriften (UVV)."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Gebäudereinigung Leistungen & Services | AHAD" 
        description="Entdecken Sie unser breites Spektrum an Gebäudedienstleistungen: Unterhaltsreinigung, Industriereinigung, Glasreinigung, Baureinigung und mehr."
        keywords="Gebäudereinigung Leistungen, Unterhaltsreinigung, Industrie-/Produktionsreinigung, Baureinigung, Medizintechnik Reinigung, Glasreinigung, Sonderreinigung"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/sonderreinigung-boden.jpg" 
            alt="Professionelle Gebäudereinigung" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white mb-6 tracking-tight">
              Unsere Leistungen im Überblick
            </h1>
            <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
              Wir setzen Leistungen nicht als Standardpaket auf, sondern entwickeln sie 
              präzise nach Objekt, Nutzung und Ihrer individuellen Betriebslogik. 
              Entdecken Sie unser umfassendes Portfolio für höchste Sauberkeit und Werterhalt.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-10">
            {leistungen.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="h-full"
              >
                <Link
                  to={service.path}
                  className="group p-8 sm:p-10 bg-white border border-gray-100 rounded-[2rem] hover:shadow-2xl transition-all duration-500 flex flex-col h-full relative overflow-hidden block"
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-[#f7f9fb] rounded-bl-full -mr-16 -mt-16 transition-transform duration-500 group-hover:scale-150 opacity-50"></div>
                  
                  <div className="mb-8 flex justify-between items-start relative z-10">
                    <div className="p-4 bg-[#f7f9fb] text-[#004888] rounded-2xl group-hover:bg-[#004888] group-hover:text-white transition-colors duration-500 shadow-sm border border-gray-100 group-hover:border-transparent">
                      {service.icon}
                    </div>
                    <span className="text-[10px] font-bold tracking-widest text-[#424751] uppercase bg-gray-100 px-3 py-1.5 rounded-full">
                      {service.tag}
                    </span>
                  </div>
                  
                  <h3 className="text-2xl font-bold mb-4 text-[#001c3b] group-hover:text-[#004888] transition-colors relative z-10">
                    {service.title}
                  </h3>
                  
                  <p className="text-[#424751] mb-8 flex-grow leading-relaxed relative z-10">
                    {service.description}
                  </p>

                  <ul className="mb-8 space-y-3 relative z-10">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-start text-sm text-[#424751] font-medium">
                        <CheckCircle2 className="w-5 h-5 text-[#2ca06a] mr-2 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="inline-flex items-center text-[#004888] font-bold mt-auto relative z-10 group-hover:text-[#2ca06a] transition-colors">
                    Details ansehen
                    <ChevronRight className="ml-1 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zu unseren Leistungen</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="pt-20 pb-32 lg:pt-32 lg:pb-48 bg-[#001c3b] text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-black mb-6">Individuelle Leistungsplanung gewünscht?</h2>
          <p className="text-lg md:text-xl text-blue-100 mb-10 max-w-2xl mx-auto leading-relaxed">
            Lassen Sie uns gemeinsam analysieren, welche Reinigungslogik für Ihr Objekt wirklich sinnvoll und wirtschaftlich ist.
          </p>
          <Link
            to="/angebot"
            className="inline-flex flex-wrap justify-center items-center px-6 sm:px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px] w-full sm:w-auto text-center"
          >
            Kostenloses Angebot anfordern
            <ArrowRight className="ml-2 w-5 h-5 flex-shrink-0" />
          </Link>
        </div>
      </section>
    </div>
  );
}
