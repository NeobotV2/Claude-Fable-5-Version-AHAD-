import { useState } from 'react';
import { GoogleGenAI } from '@google/genai';

const prompts = [
  {
    id: 'unterhaltsreinigung',
    title: 'Unterhaltsreinigung',
    prompt: 'Photorealistic image of a professional female cleaner in a modern, bright office. She is wearing a dark blue polo shirt. On the chest of the polo shirt is a prominent logo consisting of a rotated square (diamond shape) in green and blue gradients. She is smiling and wiping a desk. High quality, 8k, professional photography.'
  },
  {
    id: 'industriereinigung',
    title: 'Industriereinigung',
    prompt: 'Photorealistic image of a professional male industrial cleaner in a modern factory. He is wearing a dark blue polo shirt with a green and blue diamond-shaped logo on the back. He is operating a professional floor scrubber machine. High quality, 8k, professional photography.'
  },
  {
    id: 'glasreinigung',
    title: 'Glas- & Fassadenreinigung',
    prompt: 'Photorealistic image of a professional window cleaner cleaning a large glass facade of a modern office building. Wearing a dark blue polo shirt with a green and blue diamond-shaped logo on the back. Bright sunny day, clear reflections. High quality, 8k, professional photography.'
  },
  {
    id: 'baureinigung',
    title: 'Baureinigung',
    prompt: 'Photorealistic image of a professional cleaner at a bright, newly finished indoor construction site. Wearing a dark blue polo shirt with a green and blue diamond-shaped logo on the chest, and a yellow hard hat. Sweeping the floor. High quality, 8k, professional photography.'
  },
  {
    id: 'medizintechnik',
    title: 'Medizintechnik',
    prompt: 'Photorealistic image of a professional cleaner in a sterile medical technology environment. Wearing a dark blue polo shirt with a green and blue diamond-shaped logo on the chest, along with a hairnet and gloves. Carefully cleaning a stainless steel surface. High quality, 8k, professional photography.'
  }
];

export default function GenerateImages() {
  const [images, setImages] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const [error, setError] = useState<Record<string, string>>({});

  const generateImage = async (id: string, prompt: string) => {
    setLoading(prev => ({ ...prev, [id]: true }));
    setError(prev => ({ ...prev, [id]: '' }));
    
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        throw new Error("GEMINI_API_KEY is missing. Please set it in your environment variables.");
      }
      const ai = new GoogleGenAI({ apiKey });
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: prompt,
        config: {
          imageConfig: {
            aspectRatio: "16:9",
            imageSize: "1K"
          }
        }
      });

      let base64Data = '';
      if (response.candidates && response.candidates[0].content.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            base64Data = part.inlineData.data;
            break;
          }
        }
      }

      if (base64Data) {
        setImages(prev => ({ ...prev, [id]: `data:image/jpeg;base64,${base64Data}` }));
      } else {
        setError(prev => ({ ...prev, [id]: 'Kein Bild generiert.' }));
      }
    } catch (err: any) {
      console.error(err);
      setError(prev => ({ ...prev, [id]: err.message || 'Ein Fehler ist aufgetreten.' }));
    } finally {
      setLoading(prev => ({ ...prev, [id]: false }));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-20 px-4">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-[#1e60a9]">KI Bild-Generator (Nano Banana)</h1>
        <p className="mb-8 text-gray-600">
          Hier können Sie die gewünschten Bilder für die verschiedenen Bereiche generieren lassen. 
          Klicken Sie bei jedem Bereich auf "Bild generieren". Wenn Ihnen ein Bild gefällt, können Sie es per Rechtsklick speichern.
        </p>

        <div className="space-y-12">
          {prompts.map(item => (
            <div key={item.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h2 className="text-xl font-bold text-gray-900">{item.title}</h2>
                  <p className="text-sm text-gray-500 mt-1 max-w-2xl">{item.prompt}</p>
                </div>
                <button
                  onClick={() => generateImage(item.id, item.prompt)}
                  disabled={loading[item.id]}
                  className="bg-[#2ca06a] hover:bg-[#238054] text-white px-6 py-2 rounded-lg font-medium transition-colors disabled:opacity-50"
                >
                  {loading[item.id] ? 'Generiert...' : 'Bild generieren'}
                </button>
              </div>

              {error[item.id] && (
                <div className="text-red-500 text-sm mb-4">{error[item.id]}</div>
              )}

              <div className="mt-6 bg-gray-100 rounded-xl overflow-hidden aspect-video flex items-center justify-center border border-gray-200">
                {images[item.id] ? (
                  <img src={images[item.id]} alt={item.title} className="w-full h-full object-cover"  referrerPolicy="no-referrer" />
                ) : (
                  <span className="text-gray-400">
                    {loading[item.id] ? 'Bild wird von der KI erstellt...' : 'Noch kein Bild generiert'}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
