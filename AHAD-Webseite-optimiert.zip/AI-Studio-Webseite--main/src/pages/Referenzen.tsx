import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Building2, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

function ReferenceLogo({ name, domain, logoUrl }: { name: string; domain: string; logoUrl?: string }) {
  const [errorCount, setErrorCount] = useState(0);

  const getLogoUrl = () => {
    if (errorCount === 0) return logoUrl || `https://icon.horse/icon/${domain}`;
    return null;
  };

  const currentUrl = getLogoUrl();

  if (!currentUrl) {
    return <Building2 className="w-8 h-8 text-gray-400" />;
  }

  return (
    <img 
      key={currentUrl}
      src={currentUrl} 
      alt={`${name} Logo`}
      title={currentUrl || name}
      className="max-w-full max-h-full object-contain"
      referrerPolicy="no-referrer"
      onError={() => setErrorCount(prev => prev + 1)}
    />
  );
}

export default function Referenzen() {
  const AHAD_CLIENT_REFERENCES = [
    { name: 'Aesthetify by Dr. Rick & Dr. Nick', domain: 'aesthetify.de' },
    { name: 'Allianz', domain: 'allianz.de' },
    { name: 'Bareiss', domain: 'bareiss.com' },
    { name: 'BDT', domain: 'bdt.de' },
    { name: 'Bundesagentur für Arbeit', domain: 'arbeitsagentur.de' },
    { name: 'GOLDBECK', domain: 'goldbeck.de' },
    { name: 'Käppelehof', domain: 'kaeppelehof.de' },
    { name: 'Köster', domain: 'koester-bau.de' },
    { name: 'Kur- und Bäder GmbH Bad Dürrheim', domain: 'badduerrheim.de' },
    { name: 'naturenergie netze', domain: 'naturenergie-netze.de', logoUrl: 'https://www.naturenergie-netze.de/typo3conf/ext/sitecore/Resources/Public/img/naturenergie_netze-logo.svg' },
    { name: 'Schwarzwald Baar Kreis', domain: 'schwarzwald-baar-kreis.de', logoUrl: 'https://www.lrasbk.de/media/custom/2944_1_1_m.png' },
    { name: 'Südwest Messe', domain: 'suedwest-messe.de', logoUrl: 'https://www.suedwest-messe.de/fileadmin/data/sites/suedwest-messe-vs.de/Logo/suedwestmessevs_logo.png' }
  ];

  return (
    <div>
      <SEO 
        title="Unsere Referenzen | AHAD Cleaning"
        description="Entdecken Sie unsere zufriedenen Kunden aus verschiedenen Branchen. AHAD Cleaning steht für Qualität und Zuverlässigkeit in der Gebäudereinigung."
        keywords="Referenzen Gebäudereinigung, Kunden AHAD Cleaning, zufriedene Kunden Reinigung"
      />

      {/* Hero Section */}
      <section className="bg-[#005332] text-white pt-32 pb-20 lg:pt-48 lg:pb-32 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight">Unsere Referenzen</h1>
            <p className="text-lg md:text-xl text-green-100 leading-relaxed">
              Vertrauen ist die Basis unserer Arbeit. Wir sind stolz darauf, namhafte Unternehmen aus verschiedensten Branchen zu unseren zufriedenen Kunden zählen zu dürfen.
            </p>
          </motion.div>
        </div>
      </section>

      {/* References Grid */}
      <section className="py-20 lg:py-32 bg-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-[#001c3b] tracking-tight">Kunden, die uns vertrauen</h2>
            <p className="text-xl text-[#424751] max-w-3xl mx-auto">
              Von regionalen mittelständischen Unternehmen bis hin zu international agierenden Konzernen – wir bieten maßgeschneiderte Reinigungskonzepte für jeden Bedarf.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {AHAD_CLIENT_REFERENCES.map((ref, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                className="bg-gray-50 rounded-2xl p-8 flex flex-col items-center justify-center text-center border border-gray-100 hover:shadow-lg hover:border-gray-200 transition-all group aspect-square"
              >
                <a 
                  href={`https://${ref.domain}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-20 h-20 mb-4 bg-white rounded-full shadow-sm flex items-center justify-center p-4 group-hover:scale-110 transition-transform duration-300 overflow-hidden cursor-pointer"
                  title={`Besuche ${ref.name}`}
                >
                  <ReferenceLogo name={ref.name} domain={ref.domain} logoUrl={(ref as any).logoUrl} />
                </a>
                <h3 className="font-bold text-[#001c3b] text-sm md:text-base">{ref.name}</h3>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="pt-20 pb-32 lg:pt-32 lg:pb-48 bg-[#f2f4f6] relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="bg-[#004888] rounded-[2rem] p-12 lg:p-20 text-center text-white shadow-2xl relative overflow-hidden">
            <div className="absolute inset-0 opacity-10">
              <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
            </div>
            <div className="relative z-10 max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 tracking-tight">Werden auch Sie ein zufriedener Kunde</h2>
              <p className="text-xl text-blue-100 mb-10 leading-relaxed">
                Lassen Sie uns gemeinsam ein Reinigungskonzept entwickeln, das perfekt auf Ihre Bedürfnisse zugeschnitten ist.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link 
                  to="/kontakt" 
                  className="bg-white text-[#004888] px-8 py-4 font-bold rounded-xl hover:bg-gray-50 transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px] flex items-center justify-center gap-2"
                >
                  Angebot anfordern <ArrowRight size={20} />
                </Link>
                <a 
                  href="tel:+4977211234567" 
                  className="bg-transparent border-2 border-white/30 text-white px-8 py-4 font-bold rounded-xl hover:bg-white/10 transition-all flex items-center justify-center gap-2"
                >
                  Jetzt anrufen
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
