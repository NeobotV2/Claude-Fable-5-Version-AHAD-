import { motion } from 'motion/react';
import { LayoutDashboard, CheckCircle2, ArrowRight, Sparkles, Building2, Shield, ChevronDown, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function BueroVerwaltung() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Was beinhaltet die professionelle Büroreinigung?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Die professionelle Büroreinigung umfasst typischerweise die tägliche oder wöchentliche Unterhaltsreinigung. Dazu gehören das Leeren von Papierkörben, die Reinigung von Schreibtischen und Oberflächen, das Staubsaugen oder Wischen der Böden, die hygienische Reinigung der Sanitäranlagen sowie die Pflege von Teeküchen und Aufenthaltsräumen."
        }
      },
      {
        "@type": "Question",
        "name": "Wann wird die Reinigung in Büros und Verwaltungen durchgeführt?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Um den Arbeitsablauf nicht zu stören, führen wir die Büroreinigung meist in den Randzeiten durch – also früh morgens vor Arbeitsbeginn oder abends nach Büroschluss. Auf Wunsch ist auch eine diskrete Reinigung während der Geschäftszeiten (Day-Cleaning) möglich."
        }
      },
      {
        "@type": "Question",
        "name": "Wie wird Diskretion und Sicherheit in Verwaltungsgebäuden gewährleistet?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Unsere Reinigungskräfte sind fest angestellt, geschult und zur Verschwiegenheit verpflichtet. Wir arbeiten mit festen Revierplänen und klaren Schlüsselprotokollen. Sensible Bereiche (wie Serverräume oder Geschäftsführung) werden nur nach strengen Vorgaben gereinigt."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Büroreinigung & Unterhaltsreinigung für Verwaltungen | AHAD" 
        description="Zuverlässige Büroreinigung & Unterhaltsreinigung für Verwaltungen, Kanzleien & Praxen. AHAD Cleaning schafft ein sauberes & motivierendes Arbeitsumfeld."
        keywords="Büroreinigung, Unterhaltsreinigung, Kanzleireinigung, Praxisreinigung, Büroreinigung Villingen-Schwenningen, Gebäudereinigung Büro, Office Cleaning"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/buero-hero.jpg" 
            alt="Modernes, sauberes Bürogebäude" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Building2 className="w-4 h-4 text-[#8bf8ba]" />
              Branchenlösung: Büro & Verwaltung
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Repräsentative Sauberkeit für Ihr Arbeitsumfeld
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              Ein sauberes Büro ist die Basis für Produktivität, Mitarbeiterzufriedenheit und einen professionellen Eindruck bei Ihren Kunden. Wir sorgen für diskrete und gründliche Pflege Ihrer Verwaltungsflächen.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/kontakt" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Angebot anfordern
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Büroreinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Clock className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Flexible Zeiten</h3>
              <p className="text-[#424751] text-sm">Reinigung in den Randzeiten (früh morgens oder abends) oder als diskretes Day-Cleaning während der Betriebszeiten.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Shield className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Absolute Diskretion</h3>
              <p className="text-[#424751] text-sm">Geschultes, fest angestelltes Personal mit Verschwiegenheitsverpflichtung für sensible Verwaltungsbereiche.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Sparkles className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Werterhalt</h3>
              <p className="text-[#424751] text-sm">Schonende Pflege von hochwertigen Bodenbelägen, Möbeln und IT-Ausstattung durch professionelle Reinigungsmittel.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-black mb-8 text-[#001c3b]">Professionelle Büroreinigung für Ihr Unternehmen</h2>
              <p className="text-lg text-[#424751] mb-8 leading-relaxed">
                Wir verstehen die Dynamik moderner Bürowelten. Ob Open-Space-Büro, klassische Einzelbüros, Kanzleien oder Agenturen – unsere Büroreinigung erfolgt diskret, effizient und mit höchstem Anspruch an Hygiene und eine sichtbare Grundordnung.
              </p>
              
              <h3 className="text-xl font-bold mb-4 text-[#001c3b]">Unsere Leistungen im Detail:</h3>
              <ul className="space-y-4 mb-8">
                {[
                  'Tägliche Unterhaltsreinigung der Büro- und Verkehrsflächen',
                  'Reinigung und Pflege von Konferenz- & Besprechungsräumen',
                  'Hygienische und desinfizierende Reinigung von Sanitärbereichen',
                  'Pflege von Küchen, Teeküchen & Pausenzonen inkl. Geräteservice',
                  'Fachgerechte Mülltrennung und Entsorgung',
                  'Glas- & Fensterreinigung (auch Trennwände)',
                  'Einsatz umweltschonender und geruchsneutraler Reinigungsmittel'
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3 text-[#424751] font-medium">
                    <CheckCircle2 className="text-[#2ca06a] w-6 h-6 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              
              <p className="text-[#424751] leading-relaxed">
                Wir erstellen für Ihr Gebäude ein <Link to="/fachwissen/reinigungsintervalle" className="text-[#004888] font-bold hover:underline">individuelles Leistungsverzeichnis</Link>, das genau auf Ihre Anforderungen und die Nutzungshäufigkeit der Räume abgestimmt ist.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <img src="/images/unterhaltsreinigung-hero.jpg" alt="Helles, sauberes Büro" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8 bg-[#f7f9fb] rounded-3xl border border-gray-100">
                  <Sparkles className="w-10 h-10 text-[#004888] mb-4" />
                  <h4 className="font-bold text-[#001c3b]">Wohlfühlklima</h4>
                  <p className="text-sm text-[#424751] mt-2">Sauberkeit motiviert und reduziert krankheitsbedingte Ausfälle.</p>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="p-8 bg-[#001c3b] text-white rounded-3xl shadow-md">
                  <Shield className="w-10 h-10 text-[#8bf8ba] mb-4" />
                  <h4 className="font-bold">Zuverlässigkeit</h4>
                  <p className="text-sm text-blue-100 mt-2">Feste Ansprechpartner und konstante Reinigungsqualität.</p>
                </div>
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <img src="/images/buero-konferenz.jpg" alt="Sauberer Konferenzraum" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Büroreinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <LayoutDashboard className="w-16 h-16 text-[#8bf8ba] mx-auto mb-8" />
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Sie suchen einen zuverlässigen Partner für Ihr Büro?</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Wir sorgen für ein Arbeitsumfeld, in dem sich Ihre Mitarbeiter wohlfühlen und Ihre Kunden einen perfekten ersten Eindruck gewinnen.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Angebot anfordern
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
