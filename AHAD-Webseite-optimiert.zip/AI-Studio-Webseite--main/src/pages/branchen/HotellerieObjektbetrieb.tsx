import { motion } from 'motion/react';
import { Hotel, CheckCircle2, ArrowRight, Clock, Sparkles, Shield, ChevronDown, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function HotellerieObjektbetrieb() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Was zeichnet die professionelle Hotelreinigung aus?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Die Hotelreinigung erfordert höchste Standards an Hygiene, Detailgenauigkeit und Diskretion. Sie umfasst nicht nur das Housekeeping in den Zimmern, sondern auch die repräsentative Pflege von Lobbys, Restaurants, Wellnessbereichen und Konferenzräumen – oft unter hohem Zeitdruck und bei laufendem Gästebetrieb."
        }
      },
      {
        "@type": "Question",
        "name": "Wie gewährleisten Sie Diskretion bei der Reinigung im Hotel?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Unser Personal ist speziell für das Verhalten in Gäste- und Sensitivbereichen geschult. Wir arbeiten geräuscharm, passen unsere Reinigungszeiten an die Rhythmen des Hotels an und garantieren absolute Verschwiegenheit und Respekt vor der Privatsphäre der Gäste."
        }
      },
      {
        "@type": "Question",
        "name": "Bieten Sie auch Reinigung für Wellness- und Spa-Bereiche an?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja, die Reinigung von Wellness- und Spa-Zonen ist ein hochsensibler Bereich, den wir mit speziellen, desinfizierenden und gleichzeitig materialschonenden Verfahren betreuen, um höchste Hygienestandards (z.B. zur Vermeidung von Pilzbildung) zu gewährleisten."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Hotelreinigung & Housekeeping Service für Hotellerie | AHAD" 
        description="Professionelle Hotelreinigung & Housekeeping für erstklassige Gästeerlebnisse. Wir reinigen Lobbys, Spas & Zimmer mit höchster Diskretion & Qualität."
        keywords="Hotelreinigung, Housekeeping Service, Gebäudereinigung Hotellerie, Spa Reinigung, Lobby Reinigung, Objektbetrieb Reinigung, Hotelreinigung Baden-Württemberg"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/hotellerie-hero.jpg" 
            alt="Elegante Hotel Lobby" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Hotel className="w-4 h-4 text-[#8bf8ba]" />
              Branchenlösung: Hotellerie
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Fünf-Sterne-Sauberkeit für Ihre Gäste
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              Wir sorgen für erstklassige Sauberkeit in Gästebereichen und 
              Betreiberobjekten – mit hoher Taktung, maximaler Diskretion und einem Auge für Details.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/kontakt" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Anfrage stellen
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Hotelreinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Star className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Sichtbare Exzellenz</h3>
              <p className="text-[#424751] text-sm">Makellose Sauberkeit in Lobbys, Restaurants und Zimmern als Visitenkarte Ihres Hauses für höchste Gästezufriedenheit.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Shield className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Absolute Diskretion</h3>
              <p className="text-[#424751] text-sm">Unsere Teams arbeiten geräuscharm und rücksichtsvoll im Hintergrund, um die Privatsphäre Ihrer Gäste zu wahren.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Clock className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Hohe Taktung</h3>
              <p className="text-[#424751] text-sm">Präzise Zeitpläne und schnelle Reaktionszeiten, angepasst an Check-in/Check-out Zeiten und Event-Schedules.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-black mb-8 text-[#001c3b]">Exzellenz in der Hotelreinigung</h2>
              <p className="text-lg text-[#424751] mb-8 leading-relaxed">
                Wir verstehen den Serviceanspruch der Hotellerie. Unsere Hotelreinigung sorgt dafür, dass Sauberkeit der erste und wichtigste Eindruck ist, den ein Gast gewinnt. Unsere Teams arbeiten im Hintergrund für ein perfektes Wohlfühlerlebnis.
              </p>
              
              <h3 className="text-xl font-bold mb-4 text-[#001c3b]">Unsere Leistungen für die Hotellerie:</h3>
              <ul className="space-y-4 mb-8">
                {[
                  'Repräsentative Reinigung von Lobbys & Empfangsbereichen',
                  'Hygienische Pflege von Wellness-, Pool- & Spa-Zonen',
                  'Reinigung von Restaurants, Bars & Gastronomieflächen',
                  'Unterhaltsreinigung von Gästezimmern & Suiten (Housekeeping Support)',
                  'Pflege von Konferenz- und Veranstaltungsräumen',
                  'Glas- & Fassadenreinigung für eine perfekte Außenwirkung',
                  'Teppich- und Polsterreinigung'
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3 text-[#424751] font-medium">
                    <CheckCircle2 className="text-[#2ca06a] w-6 h-6 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              
              <p className="text-[#424751] leading-relaxed">
                Mit AHAD Cleaning als Partner können Sie sich voll und ganz auf Ihre Kernkompetenz konzentrieren: Die Betreuung Ihrer Gäste.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <img src="/images/hotellerie-zimmer.jpg" alt="Sauberes Hotelzimmer" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8 bg-[#f7f9fb] rounded-3xl border border-gray-100">
                  <Clock className="w-10 h-10 text-[#004888] mb-4" />
                  <h4 className="font-bold text-[#001c3b]">Taktung</h4>
                  <p className="text-sm text-[#424751] mt-2">Präzise Zeitpläne für Ihren reibungslosen Hotelbetrieb.</p>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="p-8 bg-[#001c3b] text-white rounded-3xl shadow-md">
                  <Sparkles className="w-10 h-10 text-[#8bf8ba] mb-4" />
                  <h4 className="font-bold">Sichtbarkeit</h4>
                  <p className="text-sm text-blue-100 mt-2">Ein makelloser Eindruck für höchste Gästezufriedenheit.</p>
                </div>
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <img src="/images/hotellerie-flur.jpg" alt="Hotel Flur" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Hotelreinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <Hotel className="w-16 h-16 text-[#8bf8ba] mx-auto mb-8" />
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Höchste Ansprüche an Sauberkeit?</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Wir sorgen für ein makelloses Ambiente, in dem sich Ihre Gäste vom ersten Moment an wohlfühlen.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Anfrage stellen
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
