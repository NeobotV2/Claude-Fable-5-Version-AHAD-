import { motion } from 'motion/react';
import { Microscope, CheckCircle2, ArrowRight, Shield, ClipboardCheck, Sparkles, ChevronDown, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function MedizintechnikBranche() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Welche Anforderungen stellt die Medizintechnik an die Gebäudereinigung?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Die Medizintechnik-Branche erfordert höchste Präzision, absolute Keimfreiheit in sensiblen Bereichen und eine lückenlose Dokumentation aller Reinigungsschritte. Dies ist essenziell für die Einhaltung von ISO-Normen und das Bestehen von Audits."
        }
      },
      {
        "@type": "Question",
        "name": "Bieten Sie Reinraumreinigung für Medizintechnik-Unternehmen an?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja, wir bieten spezialisierte Reinraumreinigung gemäß den geltenden ISO-Klassen an. Unser Personal ist speziell für das Verhalten und die Reinigungstechniken in Reinräumen geschult, um Partikel- und Keimbelastungen streng zu kontrollieren."
        }
      },
      {
        "@type": "Question",
        "name": "Wie unterstützen Sie uns bei Audits und Zertifizierungen?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Wir arbeiten mit digitalen, lückenlosen Dokumentationssystemen. Jeder Reinigungsschritt wird erfasst und ist jederzeit nachvollziehbar. So haben Sie für Audits (z.B. ISO 13485) stets alle relevanten Reinigungsnachweise griffbereit."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Reinraumreinigung & Medizintechnik Reinigung | AHAD Cleaning" 
        description="Spezialisierte Reinraumreinigung & Hygiene-Services für Medizintechnik & Pharma. GMP-konforme Reinigung für Labore & sensible Produktionsbereiche."
        keywords="Reinraumreinigung Medizintechnik, Medizintechnik Reinigung, Pharma Reinigung, Reinraumreinigung, GMP Reinigung, Laborreinigung, Hygiene Reinigung"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/medizintechnik-hero.jpg" 
            alt="Produktionsstätte in der Medizintechnik" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Microscope className="w-4 h-4 text-[#8bf8ba]" />
              Branchenlösung: Medizintechnik
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Höchste Präzision für sensible Umfelder
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              In der Medizintechnik-Region Süddeutschland sind wir Ihr Partner für 
              kompromisslose Hygienestandards, Reinraumreinigung und lückenlose Dokumentation.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/kontakt" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Fachgespräch vereinbaren
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Medizintechnik-Reinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Shield className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Kompromisslose Hygiene</h3>
              <p className="text-[#424751] text-sm">Strikte Einhaltung aller Hygienevorschriften zur Vermeidung von Kreuzkontaminationen in sensiblen Produktionsbereichen.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <ClipboardCheck className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Audit-Ready Dokumentation</h3>
              <p className="text-[#424751] text-sm">Lückenlose, digitale Erfassung aller Reinigungsprozesse als verlässlicher Nachweis für Ihre Zertifizierungen und Audits.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Sparkles className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Reinraum-Expertise</h3>
              <p className="text-[#424751] text-sm">Spezialisiertes Personal und Equipment für die fachgerechte Reinigung von Reinräumen nach ISO-Klassen.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-black mb-8 text-[#001c3b]">Sicherheit durch Reinraumreinigung und Dokumentation</h2>
              <p className="text-lg text-[#424751] mb-8 leading-relaxed">
                Wir verstehen die spezifischen und streng regulierten Anforderungen der Medizintechnik-Branche. Unsere Reinraumreinigung für Medizintechnik-Unternehmen liefert die notwendige 
                Disziplin in der Ausführung und die geforderten Nachweise für Ihre Qualitätssicherung.
              </p>
              
              <h3 className="text-xl font-bold mb-4 text-[#001c3b]">Unsere Leistungen für die Medizintechnik:</h3>
              <ul className="space-y-4 mb-8">
                {[
                  'Fachgerechte Reinraumreinigung nach ISO-Klassen',
                  'Lückenlose, digitale Dokumentation für Audits (z.B. ISO 13485)',
                  'Einsatz von speziell geschultem Personal für Medtech-Umfelder',
                  'Strikte Einhaltung von Hygiene- und Desinfektionsplänen',
                  'Kontinuierliches Monitoring & Qualitätskontrolle',
                  'Verwendung zertifizierter, spezialisierter Reinigungsmittel',
                  'Reinigung von Laboren, Produktionsstätten und Verwaltungsbereichen'
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3 text-[#424751] font-medium">
                    <CheckCircle2 className="text-[#2ca06a] w-6 h-6 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              
              <p className="text-[#424751] leading-relaxed">
                Mit AHAD Cleaning minimieren Sie Risiken und sichern die Qualität Ihrer Produktionsumgebung auf höchstem Niveau.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <img src="/images/medizintechnik-labor.jpg" alt="Medizintechnik Labor" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8 bg-[#f7f9fb] rounded-3xl border border-gray-100">
                  <ClipboardCheck className="w-10 h-10 text-[#004888] mb-4" />
                  <h4 className="font-bold text-[#001c3b]">Audit-Ready</h4>
                  <p className="text-sm text-[#424751] mt-2">Lückenlose Nachweise für Ihre Zertifizierungen garantiert.</p>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="p-8 bg-[#001c3b] text-white rounded-3xl shadow-md">
                  <Shield className="w-10 h-10 text-[#8bf8ba] mb-4" />
                  <h4 className="font-bold">Disziplin</h4>
                  <p className="text-sm text-blue-100 mt-2">Höchste Sorgfalt und Regelkonformität in jedem Schritt.</p>
                </div>
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <img src="/images/medizintechnik-labor2.jpg" alt="Reinraum" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Medizintechnik-Reinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <Microscope className="w-16 h-16 text-[#8bf8ba] mx-auto mb-8" />
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Medizintechnik-Unternehmen mit hohen Ansprüchen?</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Wir bieten Ihnen die Sicherheit und Qualität, die Ihre Branche erfordert.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Fachgespräch anfragen
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
