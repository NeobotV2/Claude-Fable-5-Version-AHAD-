import { motion } from 'motion/react';
import { Building2, CheckCircle2, ArrowRight, MapPin, Settings2, Shield, ChevronDown, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function Gewerbeobjekte() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Welche Bereiche umfasst die Reinigung von Gewerbeobjekten?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Die Reinigung von Gewerbeobjekten ist ganzheitlich und umfasst Büroflächen, Verkaufs- und Ausstellungsräume, Lager- und Logistikbereiche, Treppenhäuser, Flure, Sanitäranlagen sowie oft auch die Außenreinigung und den Winterdienst. Wir koordinieren alle Zonen aus einer Hand."
        }
      },
      {
        "@type": "Question",
        "name": "Wie wird die Reinigung in Objekten mit mehreren Mietern organisiert?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Für Multi-Tenant-Objekte entwickeln wir ein zentrales Reinigungskonzept. Ein fester Objektleiter koordiniert die Reinigung der Allgemeinflächen (Treppenhäuser, Eingangshallen) und stimmt sich bei Bedarf individuell mit den einzelnen Mietern für deren spezifische Flächen ab."
        }
      },
      {
        "@type": "Question",
        "name": "Bieten Sie auch Sonderreinigungen für Gewerbeimmobilien an?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ja, neben der regelmäßigen Unterhaltsreinigung bieten wir auch Glas- und Fassadenreinigung, Tiefgaragenreinigung, Grundreinigungen von Bodenbelägen sowie Bauendreinigungen bei Umbau- oder Renovierungsmaßnahmen im Gewerbeobjekt an."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Gewerbereinigung & Immobilienreinigung für Objekte | AHAD" 
        description="Ganzheitliche Gewerbereinigung & Immobilienreinigung für komplexe Objekte & Multi-Tenant-Gebäude. Professionelle Pflege & Werterhalt Ihrer Gewerbeflächen."
        keywords="Gewerbereinigung, Immobilienreinigung, Gebäudereinigung Gewerbeobjekte, Multi-Tenant Reinigung, Facility Management Reinigung, Objektpflege"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/gewerbe-hero.jpg" 
            alt="Modernes Gewerbeobjekt" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Building2 className="w-4 h-4 text-[#8bf8ba]" />
              Branchenlösung: Gewerbeobjekte
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Strukturierte Reinigung für komplexe Immobilien
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              Wir betreuen Gewerbeobjekte mit unterschiedlichen Nutzungszonen, mehreren Mietern 
              und hohen Besucherfrequenzen – zentral koordiniert und absolut zuverlässig.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/kontakt" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Konzept anfragen
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Gewerbereinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Settings2 className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Zentrale Steuerung</h3>
              <p className="text-[#424751] text-sm">Ein fester Objektleiter koordiniert alle Reinigungsleistungen für die gesamte Immobilie und dient als Ihr zentraler Ansprechpartner.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Building2 className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Multi-Tenant-Logik</h3>
              <p className="text-[#424751] text-sm">Maßgeschneiderte Konzepte für Immobilien mit mehreren Mietern, von Allgemeinflächen bis zu individuellen Mietbereichen.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Shield className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Werterhalt & Image</h3>
              <p className="text-[#424751] text-sm">Professionelle Pflege sichert den langfristigen Wert Ihrer Immobilie und sorgt für einen repräsentativen Eindruck bei Besuchern.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-black mb-8 text-[#001c3b]">Ganzheitliche Gewerbereinigung aus einer Hand</h2>
              <p className="text-lg text-[#424751] mb-8 leading-relaxed">
                Große Gewerbeobjekte, Fachmarktzentren oder Bürokomplexe erfordern eine flexible und durchdachte Reinigungslogik. Unsere Gewerbereinigung koordiniert die Pflege unterschiedlichster Nutzungszonen effizient und transparent.
              </p>
              
              <h3 className="text-xl font-bold mb-4 text-[#001c3b]">Unsere Leistungen für Gewerbeimmobilien:</h3>
              <ul className="space-y-4 mb-8">
                {[
                  'Reinigung von Allgemeinflächen (Treppenhäuser, Flure, Eingangshallen)',
                  'Individuelle Unterhaltsreinigung für einzelne Mieter/Büros',
                  'Pflege von Verkaufs-, Ausstellungs- und Showroom-Flächen',
                  'Reinigung von Lager-, Logistik- und Technikbereichen',
                  'Hygienische Reinigung zentraler Sanitäranlagen',
                  'Tiefgaragen- und Parkhausreinigung',
                  'Außenreinigung, Grünanlagenpflege & Winterdienst'
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3 text-[#424751] font-medium">
                    <CheckCircle2 className="text-[#2ca06a] w-6 h-6 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              
              <p className="text-[#424751] leading-relaxed">
                Durch die Bündelung dieser Services reduzieren wir Schnittstellen und optimieren die Bewirtschaftungskosten Ihrer Immobilie.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <img src="/images/buero-hero.jpg" alt="Gewerbeobjekt Eingangsbereich" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8 bg-[#f7f9fb] rounded-3xl border border-gray-100">
                  <Settings2 className="w-10 h-10 text-[#004888] mb-4" />
                  <h4 className="font-bold text-[#001c3b]">Betreiberlogik</h4>
                  <p className="text-sm text-[#424751] mt-2">Optimierte Abläufe und transparente Dokumentation für Facility Manager.</p>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="p-8 bg-[#001c3b] text-white rounded-3xl shadow-md">
                  <MapPin className="w-10 h-10 text-[#8bf8ba] mb-4" />
                  <h4 className="font-bold">Präsenz</h4>
                  <p className="text-sm text-blue-100 mt-2">Regionale Nähe in Baden-Württemberg für schnelle Reaktionszeiten.</p>
                </div>
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <img src="/images/buero-konferenz.jpg" alt="Gewerbeobjekt Flur" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Gewerbereinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <Building2 className="w-16 h-16 text-[#8bf8ba] mx-auto mb-8" />
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Größeres Gewerbeobjekt mit Mehrfachnutzung?</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Wir entwickeln ein integriertes, wirtschaftliches Reinigungskonzept für Ihre gesamte Immobilie.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Konzept anfragen
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
