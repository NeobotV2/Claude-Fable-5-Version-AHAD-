import { motion } from 'motion/react';
import { Factory, CheckCircle2, ArrowRight, Shield, Settings2, Sparkles, ChevronDown, HardHat } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function IndustrieProduktion() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Was beinhaltet die Industriereinigung?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Die Industriereinigung umfasst die Reinigung von Produktionshallen, Werkstätten, Maschinen und Anlagen. Dazu gehören auch die Entfettung von Böden, die Reinigung von Sozialräumen und die fachgerechte Entsorgung von Produktionsabfällen unter Einhaltung strenger Sicherheits- und Umweltauflagen."
        }
      },
      {
        "@type": "Question",
        "name": "Wie wird die Reinigung in laufende Produktionsprozesse integriert?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Wir passen unsere Reinigungsintervalle exakt an Ihre Schichtpläne und Produktionszyklen an. Durch flexible Einsatzzeiten (z.B. nachts oder an Wochenenden) stellen wir sicher, dass Ihre Betriebsabläufe nicht gestört werden und Stillstandzeiten minimiert werden."
        }
      },
      {
        "@type": "Question",
        "name": "Welche Sicherheitsstandards gelten bei der Produktionsreinigung?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Sicherheit hat höchste Priorität. Unser Personal ist speziell geschult im Umgang mit Gefahrstoffen, trägt entsprechende Schutzausrüstung (PSA) und arbeitet streng nach den geltenden Unfallverhütungsvorschriften (UVV) sowie Ihren internen Sicherheitsrichtlinien."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Industriereinigung & Produktionsanlagen Reinigung | AHAD Cleaning" 
        description="Professionelle Industriereinigung für Produktionsanlagen & Hallen. AHAD Cleaning sorgt für Prozesslogik, Maschinenreinigung & Werterhalt in der Industrie."
        keywords="Industriereinigung, Produktionsreinigung, Maschinenreinigung, Hallenreinigung, Industriereinigung Produktionsanlagen, Anlagenreinigung, Gebäudereinigung Industrie"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/industrie-hero.jpg" 
            alt="Moderne Industrieanlage" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl"
          >
            <span className="inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full text-sm font-bold mb-6 tracking-wider uppercase border border-white/20">
              <Factory className="w-4 h-4 text-[#8bf8ba]" />
              Branchenlösung: Industrie
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-8 leading-tight tracking-tight">
              Reibungslose Abläufe durch perfekte Sauberkeit
            </h1>
            <p className="text-xl text-blue-100 leading-relaxed mb-10 font-medium">
              Wir verstehen die Anforderungen technischer Umfelder. Unsere Reinigung 
              integriert sich nahtlos in Ihre Schichtpläne und sorgt für 
              störungsfreie Produktionsprozesse.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/kontakt" className="px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]">
                Besichtigung vereinbaren
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Auf einen Blick (At a glance) - Good for AEO/GEO */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-black text-[#001c3b] mb-8 text-center">Industriereinigung auf einen Blick</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Settings2 className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Prozessintegration</h3>
              <p className="text-[#424751] text-sm">Unsere Reinigungszyklen passen sich exakt Ihren Schichtplänen an, um Stillstandzeiten in der Produktion zu vermeiden.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <Shield className="w-8 h-8 text-[#2ca06a] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Höchste Arbeitssicherheit</h3>
              <p className="text-[#424751] text-sm">Strenge Einhaltung aller UVV-Vorschriften und Einsatz von geschultem Personal für gefährliche Arbeitsbereiche.</p>
            </motion.div>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              whileHover={{ y: -5, transition: { duration: 0.2 } }}
              className="bg-[#f7f9fb] p-6 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <HardHat className="w-8 h-8 text-[#004888] mb-4" />
              <h3 className="font-bold text-lg mb-2 text-[#001c3b]">Spezial-Know-how</h3>
              <p className="text-[#424751] text-sm">Fachgerechte Maschinenreinigung, Entfettung von Industrieböden und Umgang mit speziellen Reinigungschemikalien.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-black mb-8 text-[#001c3b]">Technische Kompetenz in der Industriereinigung</h2>
              <p className="text-lg text-[#424751] mb-8 leading-relaxed">
                In der Industrie geht es um mehr als nur optische Sauberkeit. Unsere spezialisierte Industriereinigung für Produktionsanlagen und Hallen sichert den Werterhalt Ihrer Anlagen, die Arbeitssicherheit Ihrer Mitarbeiter und 
                die strikte Einhaltung von Umwelt- und Sicherheitsvorschriften.
              </p>
              
              <h3 className="text-xl font-bold mb-4 text-[#001c3b]">Unsere Leistungen für die Industrie:</h3>
              <ul className="space-y-4 mb-8">
                {[
                  'Reinigung von Produktionshallen & Werkstätten',
                  'Fachgerechte Maschinenreinigung & Anlagenpflege',
                  'Spezial-Entfettung von Industrieböden & Oberflächen',
                  'Reinigung von Sozialräumen, Waschräumen & Umkleiden',
                  'Berücksichtigung von Schichtlogik & Sicherheitsfreigaben',
                  'Einsatz von spezialisierten, materialschonenden Reinigungsmitteln',
                  'Fachgerechte Entsorgung von Produktionsabfällen'
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3 text-[#424751] font-medium">
                    <CheckCircle2 className="text-[#2ca06a] w-6 h-6 flex-shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              
              <p className="text-[#424751] leading-relaxed">
                Wir entwickeln gemeinsam mit Ihnen ein Reinigungskonzept, das exakt auf die spezifischen Anforderungen und Gefährdungsklassen Ihres Betriebs abgestimmt ist.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <img src="/images/industrie-fertigung.jpg" alt="Industrielle Fertigung" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8 bg-[#f7f9fb] rounded-3xl border border-gray-100">
                  <Settings2 className="w-10 h-10 text-[#004888] mb-4" />
                  <h4 className="font-bold text-[#001c3b]">Prozesslogik</h4>
                  <p className="text-sm text-[#424751] mt-2">Nahtlose Integration in Ihre Produktionsabläufe.</p>
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="p-8 bg-[#001c3b] text-white rounded-3xl shadow-md">
                  <Shield className="w-10 h-10 text-[#8bf8ba] mb-4" />
                  <h4 className="font-bold">Sicherheit</h4>
                  <p className="text-sm text-blue-100 mt-2">Strikte Einhaltung aller UVV-Vorschriften.</p>
                </div>
                <div className="h-64 bg-gray-100 rounded-3xl overflow-hidden shadow-sm">
                  <img src="/images/industrie-halle.jpg" alt="Industriehalle" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zur Industriereinigung</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32 bg-[#001c3b] text-white text-center">
        <div className="max-w-3xl mx-auto px-4">
          <Factory className="w-16 h-16 text-[#8bf8ba] mx-auto mb-8" />
          <h2 className="text-3xl lg:text-4xl font-black mb-6">Produktionsumfeld mit speziellen Anforderungen?</h2>
          <p className="text-blue-100 mb-10 text-lg">
            Wir analysieren Ihre Prozesse und entwickeln ein passgenaues Reinigungskonzept für maximale Betriebssicherheit.
          </p>
          <Link
            to="/kontakt"
            className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-lg"
          >
            Jetzt Besichtigung anfragen
            <ArrowRight className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
