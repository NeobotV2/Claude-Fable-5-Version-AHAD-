import { motion } from 'motion/react';
import { Factory, Microscope, Building2, LayoutDashboard, Hotel, ArrowRight, ChevronRight, CheckCircle2, ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

const branchen = [
  {
    title: 'Industrie & Produktion',
    description: 'Robuste Reinigungskonzepte für technische und produktionsnahe Umfelder. Wir integrieren uns in Ihre Schichtlogik und gewährleisten höchste Arbeitssicherheit.',
    icon: <Factory className="w-8 h-8" />,
    path: '/branchen/industrie-produktion',
    tag: 'PROZESSLOGIK',
    features: ['Schichtbegleitende Reinigung', 'Maschinenreinigung', 'Arbeitssicherheit']
  },
  {
    title: 'Medizintechnik & Pharma',
    description: 'Spezialisierte Reinigung für hochsensible Produktions- und Entwicklungsumfelder. Wir arbeiten nach strengen ISO-Vorgaben mit lückenloser Dokumentation.',
    icon: <Microscope className="w-8 h-8" />,
    path: '/branchen/medizintechnik',
    tag: 'DOKUMENTATION',
    features: ['Reinraumreinigung', 'ISO-Konformität', 'Spezialgeschultes Personal']
  },
  {
    title: 'Büro & Verwaltung',
    description: 'Diskrete und effiziente Reinigung für repräsentative Arbeitsumfelder. Wir sorgen für ein hygienisches und motivierendes Umfeld für Ihre Mitarbeiter.',
    icon: <LayoutDashboard className="w-8 h-8" />,
    path: '/branchen/buero-verwaltung',
    tag: 'REPRÄSENTATIV',
    features: ['Flexible Reinigungszeiten', 'Tageskräfte', 'Konferenzraum-Service']
  },
  {
    title: 'Gewerbeobjekte & Logistik',
    description: 'Strukturierte Reinigungskonzepte für großflächige Immobilien, Logistikzentren und Objekte mit hoher Frequenz und unterschiedlichen Nutzungszonen.',
    icon: <Building2 className="w-8 h-8" />,
    path: '/branchen/gewerbeobjekte',
    tag: 'BETREIBERLOGIK',
    features: ['Hallenreinigung', 'Außenanlagen', 'Bodenbeschichtung']
  },
  {
    title: 'Hotellerie & Objektbetrieb',
    description: 'Höchster Serviceanspruch für Gästeflächen und Betreiberobjekte. Wir garantieren makellose Sauberkeit bei hoher Sichtbarkeit und enger Taktung.',
    icon: <Hotel className="w-8 h-8" />,
    path: '/branchen/hotellerie-objektbetrieb',
    tag: 'SERVICEANSPRUCH',
    features: ['Housekeeping', 'Public Area Cleaning', 'Qualitätskontrollen']
  }
];

export default function Branchen() {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "Für welche Branchen bietet AHAD Cleaning spezialisierte Reinigungsdienste an?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "AHAD Cleaning bietet branchenspezifische Reinigungslösungen für Industrie & Produktion, Medizintechnik & Pharma, Büro & Verwaltung, Gewerbeobjekte & Logistik sowie Hotellerie & Objektbetrieb."
        }
      },
      {
        "@type": "Question",
        "name": "Wie passt sich AHAD Cleaning an die Prozesse in der Industrie an?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "In der Industrie und Produktion integrieren wir unsere Reinigungskonzepte nahtlos in Ihre Schichtlogik. Wir bieten schichtbegleitende Reinigung und Maschinenreinigung an, um Stillstandzeiten zu minimieren und höchste Arbeitssicherheit zu gewährleisten."
        }
      },
      {
        "@type": "Question",
        "name": "Welche Standards gelten für die Reinigung in der Medizintechnik?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Für hochsensible Bereiche wie Medizintechnik und Pharma arbeiten wir nach strengen ISO-Vorgaben. Dies umfasst Reinraumreinigung durch spezialgeschultes Personal und eine lückenlose, audit-sichere Dokumentation aller Reinigungsprozesse."
        }
      }
    ]
  };

  return (
    <div>
      <SEO 
        title="Branchenlösungen Gebäudereinigung | AHAD" 
        description="Branchenspezifische Reinigungslösungen für Industrie, Medizintechnik, Büro, Gewerbeobjekte und Hotellerie. Wir verstehen Ihre Prozesslogik."
        keywords="Gebäudereinigung Industrie, Medizintechnik Reinigung, Büroreinigung, Gewerbeobjekte Reinigung, Hotellerie Reinigung, Branchenlösungen"
        schema={faqSchema}
      />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 bg-[#001c3b] text-white overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/gewerbe-hero.jpg" 
            alt="Moderne Architektur und Branchenvielfalt" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white mb-6 tracking-tight">
              Branchenspezifische Lösungen
            </h1>
            <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
              Wir strukturieren Leistungen nach Branchenrealität und arbeiten nicht mit Einheitsreinigung. 
              Jede Branche hat ihre eigene Logik, die wir verstehen und in unsere Prozesse integrieren.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Branchen Grid */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-10">
            {branchen.map((branch, index) => (
              <motion.div
                key={branch.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="group p-8 sm:p-10 bg-white border border-gray-100 rounded-[2rem] hover:shadow-2xl transition-all duration-500 flex flex-col h-full relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#f7f9fb] rounded-bl-full -mr-16 -mt-16 transition-transform duration-500 group-hover:scale-150 opacity-50"></div>
                
                <div className="mb-8 flex justify-between items-start relative z-10">
                  <div className="p-4 bg-[#f7f9fb] text-[#004888] rounded-2xl group-hover:bg-[#004888] group-hover:text-white transition-colors duration-500 shadow-sm border border-gray-100 group-hover:border-transparent">
                    {branch.icon}
                  </div>
                  <span className="text-[10px] font-bold tracking-widest text-[#424751] uppercase bg-gray-100 px-3 py-1.5 rounded-full">
                    {branch.tag}
                  </span>
                </div>
                
                <h3 className="text-2xl font-bold mb-4 text-[#001c3b] group-hover:text-[#004888] transition-colors relative z-10">
                  {branch.title}
                </h3>
                
                <p className="text-[#424751] mb-8 flex-grow leading-relaxed relative z-10">
                  {branch.description}
                </p>

                <ul className="mb-8 space-y-3 relative z-10">
                  {branch.features.map((feature, i) => (
                    <li key={i} className="flex items-start text-sm text-[#424751] font-medium">
                      <CheckCircle2 className="w-5 h-5 text-[#2ca06a] mr-2 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <Link
                  to={branch.path}
                  className="inline-flex items-center text-[#004888] font-bold group/link mt-auto relative z-10 hover:text-[#2ca06a] transition-colors"
                >
                  Branchenlösung ansehen
                  <ChevronRight className="ml-1 w-5 h-5 group-hover/link:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 lg:py-32 bg-[#f7f9fb]">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[#004888] font-bold tracking-wider uppercase text-sm mb-4 block">Häufige Fragen</span>
            <h2 className="text-3xl lg:text-4xl font-black tracking-tight text-[#001c3b]">FAQs zu unseren Branchenlösungen</h2>
          </div>
          <div className="space-y-4">
            {faqSchema.mainEntity.map((faq, i) => (
              <details key={i} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 [&_summary::-webkit-details-marker]:hidden shadow-sm">
                <summary className="w-full flex justify-between items-center p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors">
                  <span className="font-bold text-lg text-[#001c3b] pr-8">{faq.name}</span>
                  <span className="transition group-open:rotate-180 bg-[#f7f9fb] p-2 rounded-full text-[#004888]">
                    <ChevronDown size={20} />
                  </span>
                </summary>
                <div className="p-6 pt-0 text-[#424751] leading-relaxed border-t border-gray-100 mt-2">
                  <p className="pt-4">{faq.acceptedAnswer.text}</p>
                </div>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="pt-20 pb-32 lg:pt-32 lg:pb-48 bg-[#001c3b] text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-3xl md:text-4xl font-black mb-6">Spezifische Anforderungen in Ihrer Branche?</h2>
          <p className="text-lg md:text-xl text-blue-100 mb-10 max-w-2xl mx-auto leading-relaxed">
            Wir verstehen die Prozesslogik Ihrer Branche und integrieren uns nahtlos in Ihre Abläufe. Lassen Sie uns über Ihre Herausforderungen sprechen.
          </p>
          <Link
            to="/angebot"
            className="inline-flex flex-wrap justify-center items-center px-6 sm:px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px] w-full sm:w-auto text-center"
          >
            Kostenloses Angebot anfordern
            <ArrowRight className="ml-2 w-5 h-5 flex-shrink-0" />
          </Link>
        </div>
      </section>
    </div>
  );
}
