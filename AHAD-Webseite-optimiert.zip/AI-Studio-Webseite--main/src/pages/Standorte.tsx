import { motion } from 'motion/react';
import { MapPin, ArrowRight, ChevronRight, Building2, Phone, Mail } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

const standorte = [
  {
    name: 'Villingen-Schwenningen',
    type: 'Zentrale & Operatives Zentrum',
    focus: 'Donaueschingen, Rottweil, Tuttlingen, Bad Dürrheim, St. Georgen, Trossingen und der gesamte Schwarzwald-Baar-Kreis.',
    path: '/standorte/villingen-schwenningen',
    address: 'Max-Planck-Straße 11, 78052 Villingen-Schwenningen',
    phone: '+49 7721 9447915',
    email: 'info@ahad-cleaning.de'
  },
  {
    name: 'Stuttgart',
    type: 'Standort',
    focus: 'Ludwigsburg, Esslingen, Böblingen, Sindelfingen, Waiblingen, Leonberg und der Großraum Stuttgart.',
    path: '/standorte/stuttgart',
    address: 'Humboldtstraße 27, 70771 Echterdingen',
    phone: '+49 711 123456',
    email: 'stuttgart@ahad-cleaning.de'
  },
  {
    name: 'Konstanz',
    type: 'Standort',
    focus: 'Radolfzell, Singen, Kreuzlingen, Meersburg, Überlingen, Stockach und die gesamte Bodenseeregion.',
    path: '/standorte/konstanz',
    address: 'Brückengasse 1b, 78462 Konstanz',
    phone: '+49 7531 123456',
    email: 'konstanz@ahad-cleaning.de'
  }
];

export default function Standorte() {
  return (
    <div>
      <SEO 
        title="Unsere Standorte in Süddeutschland" 
        description="AHAD Cleaning ist an mehreren Standorten in Süddeutschland für Sie präsent: Villingen-Schwenningen, Stuttgart und Konstanz."
        keywords="Gebäudereinigung Villingen-Schwenningen, Stuttgart, Konstanz, Rottweil, Donaueschingen, Radolfzell, Ludwigsburg"
      />
      {/* Hero Section */}
      <section className="bg-[#001c3b] text-white pt-32 pb-20 lg:pt-48 lg:pb-32 relative overflow-hidden">
        <div className="absolute inset-0 flex opacity-25">
          <div className="w-1/3 h-full relative">
            <img src="/images/standort-vs-hero.jpg" alt="Schwarzwald (Villingen-Schwenningen)" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-[#001c3b]/40 mix-blend-multiply"></div>
          </div>
          <div className="w-1/3 h-full relative">
            <img src="/images/standort-stuttgart-hero.jpg" alt="Stuttgart" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-[#001c3b]/40 mix-blend-multiply"></div>
          </div>
          <div className="w-1/3 h-full relative">
            <img src="/images/standort-konstanz-hero.jpg" alt="Bodensee (Konstanz)" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            <div className="absolute inset-0 bg-[#001c3b]/40 mix-blend-multiply"></div>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-[#001c3b] via-[#001c3b]/80 to-transparent"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight">Unsere Standorte</h1>
            <p className="text-lg md:text-xl text-blue-100 leading-relaxed">
              Regionale Nähe sichert schnelle Reaktionszeiten und eine persönliche Betreuung vor Ort. 
              Wir sind in Süddeutschland stark aufgestellt und immer in Ihrer Nähe.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Locations */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-gray-900 tracking-tight">Zentrale Standorte</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-10">
            {standorte.map((location, index) => (
              <motion.div
                key={location.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="p-8 sm:p-10 border border-gray-100 rounded-[2rem] hover:shadow-2xl transition-all duration-500 group relative overflow-hidden flex flex-col h-full bg-white"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-bl-full -mr-16 -mt-16 transition-transform duration-500 group-hover:scale-150 opacity-50"></div>
                
                <div className="w-16 h-16 bg-blue-50 text-[#004888] rounded-2xl flex items-center justify-center mb-8 group-hover:bg-[#004888] group-hover:text-white transition-colors duration-500 shadow-sm relative z-10">
                  <MapPin className="w-8 h-8" />
                </div>
                
                <h3 className="text-2xl font-bold mb-2 text-gray-900 relative z-10">{location.name}</h3>
                <p className="text-[#004888] font-bold text-sm mb-6 uppercase tracking-wider relative z-10">{location.type}</p>
                
                <p className="text-gray-600 mb-8 flex-grow relative z-10 leading-relaxed">{location.focus}</p>
                
                <div className="space-y-3 mb-8 relative z-10">
                  <div className="flex items-center text-sm text-gray-600">
                    <MapPin className="w-4 h-4 mr-3 text-[#004888]" />
                    {location.address}
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Phone className="w-4 h-4 mr-3 text-[#004888]" />
                    {location.phone}
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Mail className="w-4 h-4 mr-3 text-[#004888]" />
                    {location.email}
                  </div>
                </div>

                <Link
                  to={location.path}
                  className="inline-flex items-center text-[#004888] font-bold group/link mt-auto relative z-10"
                >
                  Standortdetails
                  <ChevronRight className="ml-1 w-5 h-5 group-hover/link:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="pt-20 pb-32 lg:pt-32 lg:pb-48 bg-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900 tracking-tight">Ist Ihr Standort nicht dabei?</h2>
            <p className="text-lg md:text-xl text-gray-600 mb-10 leading-relaxed">
              Wir erweitern unser Einsatzgebiet kontinuierlich und sind flexibel. Kontaktieren Sie uns für eine individuelle Anfrage in Ihrer Region.
            </p>
            <Link
              to="/kontakt"
              className="inline-flex items-center px-8 py-4 bg-[#004888] text-white font-bold rounded-xl hover:bg-blue-900 transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]"
            >
              Anfrage für Ihren Standort
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
