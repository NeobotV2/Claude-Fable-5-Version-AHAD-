import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { db, collection, addDoc, serverTimestamp } from '@/firebase';
import { CheckCircle2, Loader2, Briefcase, User, GraduationCap, Calendar, Users, FileText, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

const positions = [
  'Reinigungskraft (m/w/d)',
  'Objektleiter (m/w/d)',
  'Glasreiniger (m/w/d)',
  'Auszubildende (m/w/d)'
];

export default function Karriere() {
  return (
    <div className="min-h-screen bg-[#f7f9fb]">
      <SEO 
        title="Karriere & Jobs" 
        description="Werden Sie Teil des AHAD-Teams. Wir suchen engagierte Mitarbeiter in der Gebäudereinigung in Süddeutschland. Jetzt online bewerben!"
        keywords="Jobs Gebäudereinigung, Karriere Reinigung Süddeutschland, AHAD Cleaning Jobs"
      />
      <section className="bg-[#001c3b] text-white pt-32 pb-20 lg:pt-48 lg:pb-32 relative overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/karriere-hero.jpg" 
            alt="Karriere bei AHAD Cleaning" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white mb-6 tracking-tight">Karriere bei <span className="font-logo">AHAD</span></h1>
            <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
              Werden Sie Teil eines dynamischen Teams, das Wert auf Qualität, Zuverlässigkeit und ein faires Miteinander legt. 
              Wir suchen engagierte Mitarbeiter, die mit uns wachsen wollen.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Warum bei AHAD arbeiten? */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900 tracking-tight">Warum bei <span className="font-logo">AHAD</span> arbeiten?</h2>
            <p className="text-xl text-gray-600">
              Wir schaffen ein Arbeitsumfeld, in dem Leistung geschätzt, gefördert und fair entlohnt wird.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: CheckCircle2, title: 'Faire Bezahlung', desc: 'Übertarifliche Entlohnung, pünktliche Zahlung und attraktive Zuschläge.' },
              { icon: Users, title: 'Starkes Team', desc: 'Ein familiäres Arbeitsklima, gegenseitige Unterstützung und flache Hierarchien.' },
              { icon: Briefcase, title: 'Sicherer Arbeitsplatz', desc: 'Unbefristete Verträge in einem krisensicheren und wachsenden Unternehmen.' },
              { icon: GraduationCap, title: 'Weiterbildung', desc: 'Regelmäßige Schulungen, Zertifizierungen und klare Aufstiegsmöglichkeiten.' },
              { icon: FileText, title: 'Moderne Ausrüstung', desc: 'Hochwertige Arbeitsmittel, moderne Maschinen und professionelle Schutzkleidung.' },
              { icon: Calendar, title: 'Gute Erreichbarkeit', desc: 'Standorte in Ihrer Nähe und flexible Arbeitszeitmodelle.' }
            ].map((benefit, index) => (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="bg-gray-50 p-8 rounded-3xl border border-gray-100 hover:shadow-lg transition-all duration-300 group hover:border-green-100"
              >
                <div className="w-14 h-14 bg-green-50 text-[#005332] rounded-2xl flex items-center justify-center mb-6 group-hover:bg-[#005332] group-hover:text-white transition-colors duration-300">
                  <benefit.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold mb-4 text-gray-900">{benefit.title}</h3>
                <p className="text-gray-600 leading-relaxed text-sm">
                  {benefit.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form Section */}
      <section className="pt-20 pb-32 lg:pt-32 lg:pb-48 bg-[#f2f4f6] relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900 tracking-tight">Einfach & Schnell bewerben</h2>
            <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
              Kein Anschreiben, kein Lebenslauf. In nur 60 Sekunden zum neuen Job.
            </p>
            
            <Link 
              to="/karriere/bewerbung" 
              className="inline-flex items-center gap-4 bg-[#005332] text-white px-12 py-6 rounded-2xl font-black text-xl uppercase tracking-wider hover:bg-green-900 transition-all shadow-2xl hover:scale-105 active:scale-95 group"
            >
              <Zap className="w-8 h-8 fill-yellow-400 text-yellow-400 group-hover:animate-pulse" />
              Express-Bewerbung starten
            </Link>
            
            <p className="mt-8 text-sm text-gray-500 font-medium">
              Kostenlos & unverbindlich • Rückmeldung innerhalb von 24h
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto bg-white rounded-[2rem] shadow-xl border border-gray-100 overflow-hidden relative">
            <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
            <div className="relative z-10">
              <div className="p-12 md:p-16 text-center">
                <h3 className="text-2xl font-bold mb-4 text-gray-900">Oder klassisch bewerben?</h3>
                <p className="text-gray-600 mb-8">
                  Du möchtest uns lieber direkt deine Unterlagen senden? Kein Problem.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <a href="mailto:karriere@ahad-cleaning.de" className="flex items-center justify-center gap-2 px-8 py-4 bg-gray-100 text-gray-700 rounded-xl font-bold hover:bg-gray-200 transition-all">
                    Per E-Mail senden
                  </a>
                  <a href="tel:+4977219447915" className="flex items-center justify-center gap-2 px-8 py-4 bg-gray-100 text-gray-700 rounded-xl font-bold hover:bg-gray-200 transition-all">
                    Anrufen & Fragen
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
