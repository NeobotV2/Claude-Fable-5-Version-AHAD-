import { motion } from 'motion/react';
import { Search, ArrowRight, BookOpen, Clock, Tag } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

const articles = [
  {
    category: 'Fachartikel',
    date: '12.04.2024',
    title: 'Reinigungsintervalle in Unternehmen',
    excerpt: 'Wie oft muss was gereinigt werden? Wir erklären die Logik hinter effizienten Reinigungsintervallen für moderne Büro- und Verwaltungsflächen. Eine detaillierte Analyse für Facility Manager.',
    image: '/images/fachwissen-iso.jpg',
    path: '/fachwissen/unterhaltsreinigung-unternehmen-reinigungsintervalle',
    readTime: '5 Min'
  },
  {
    category: 'Technik',
    date: '28.03.2024',
    title: 'Industriereinigung ohne Prozessstörung',
    excerpt: 'Wie wir Reinigung in hochsensible Produktionsumfelder integrieren, ohne den laufenden Betrieb zu stören. Einblicke in unsere Schichtlogik und Maschineneinsatzplanung.',
    image: '/images/industrie-hero.jpg',
    path: '/fachwissen/industrie-produktionsreinigung-ohne-prozessstoerung',
    readTime: '8 Min'
  },
  {
    category: 'Unternehmen',
    date: '15.03.2024',
    title: 'ISO 9001 & 14001 Zertifizierungen',
    excerpt: 'Warum Zertifizierungen mehr als nur Papier sind: Qualitätsmanagement und Umweltbewusstsein als Kern unserer Dienstleistung. Was das konkret für unsere Kunden bedeutet.',
    image: '/images/buero-hero.jpg',
    path: '/fachwissen/iso-9001-iso-14001-gebaeudereinigung-unternehmen',
    readTime: '4 Min'
  },
  {
    category: 'Strategie',
    date: '05.03.2024',
    title: 'Reinigungsfirma wechseln: Checkliste',
    excerpt: 'Wann ist der richtige Zeitpunkt für einen Wechsel? Unsere Checkliste hilft Ihnen bei der Kündigung, Neu-Ausschreibung und dem reibungslosen Übergang.',
    image: '/images/medizintechnik-hero.jpg',
    path: '/fachwissen/reinigungsfirma-wechseln-checkliste-tipps',
    readTime: '6 Min'
  }
];

export default function Fachwissen() {
  return (
    <div className="min-h-screen bg-[#f7f9fb]">
      <SEO 
        title="Fachwissen & Insights" 
        description="Expertenwissen rund um Gebäudereinigung, ISO-Zertifizierungen, Reinigungsintervalle und effiziente Industriereinigung."
        keywords="Gebäudereinigung für Unternehmen, Ausschreibung, ISO, Reinigungsintervalle"
      />
      <section className="bg-[#001c3b] text-white pt-32 pb-20 lg:pt-48 lg:pb-32 relative overflow-hidden">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/baureinigung-endreinigung.jpg" 
            alt="Fachwissen und Expertise" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white mb-6 tracking-tight">Fachwissen & Insights</h1>
            <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
              Wir teilen unsere Expertise zu modernen Reinigungsverfahren, 
              Qualitätsstandards und Branchentrends. Fundiertes Wissen für Facility Manager und Entscheider.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-10">
            {articles.map((article, i) => (
              <Link 
                to={article.path}
                key={article.title}
                className="group cursor-pointer block h-full"
              >
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1, duration: 0.5 }}
                  className="bg-white border border-gray-100 rounded-[2rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 flex flex-col h-full relative"
                >
                  <div className="h-64 overflow-hidden relative">
                    <div className="absolute inset-0 bg-[#004888]/20 group-hover:bg-transparent transition-colors duration-500 z-10"></div>
                    <img 
                      src={article.image} 
                      alt={article.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                    />
                    <div className="absolute top-4 left-4 z-20 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full flex items-center gap-2">
                      <Tag className="w-3 h-3 text-[#004888]" />
                      <span className="text-[10px] font-bold uppercase tracking-widest text-[#004888]">{article.category}</span>
                    </div>
                  </div>
                  
                  <div className="p-8 sm:p-10 flex flex-col flex-grow">
                    <div className="flex justify-between items-center mb-6 text-gray-500 text-xs font-medium">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        <span>{article.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <BookOpen className="w-4 h-4" />
                        <span>{article.readTime}</span>
                      </div>
                    </div>
                    
                    <h3 className="text-2xl font-bold mb-4 text-gray-900 group-hover:text-[#004888] transition-colors leading-tight">
                      {article.title}
                    </h3>
                    
                    <p className="text-sm text-gray-600 leading-relaxed mb-8 flex-grow">
                      {article.excerpt}
                    </p>
                    
                    <div className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-[#004888] mt-auto">
                      Weiterlesen 
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-2 transition-transform" />
                    </div>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
