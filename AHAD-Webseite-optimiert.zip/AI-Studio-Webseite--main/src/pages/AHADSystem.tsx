import { motion } from 'motion/react';
import { Shield, Search, LayoutDashboard, Settings2, ClipboardCheck, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

export default function AHADSystem() {
  const steps = [
    {
      id: 'A',
      title: 'Analyse',
      subtitle: 'Objektlogik sauber erfassen.',
      description: 'Wir erfassen Flächen, Nutzung, Risiken und Reinigungsbedarf als belastbare Grundlage für Planung und Ausführung.',
      icon: <Search className="w-8 h-8" />,
      details: ['Präzise Objektlogik-Aufnahme', 'Nutzungs- & Frequenzanalyse', 'Kosten-Optimierungspotenziale']
    },
    {
      id: 'H',
      title: 'Handling',
      subtitle: 'Feste Teams, klare Zuständigkeiten.',
      description: 'Eingespielte Teams, definierte Abläufe und eine feste Objektleitung sichern die operative Ausführung ohne ständiges Nachsteuern.',
      icon: <Settings2 className="w-8 h-8" />,
      details: ['Feste Objektleitung', 'Prozessintegrierte Reinigung', 'Keine Personal-Fluktuation']
    },
    {
      id: 'A',
      title: 'Audit',
      subtitle: 'Qualität regelmäßig prüfen.',
      description: 'Regelmäßige Kontrollen machen Leistung messbar und Abweichungen sichtbar, bevor daraus Reklamationen oder Auditprobleme entstehen.',
      icon: <ClipboardCheck className="w-8 h-8" />,
      details: ['Digitale Qualitäts-Audits', 'Soll-Ist-Abgleich in Echtzeit', 'Proaktives Fehlermanagement']
    },
    {
      id: 'D',
      title: 'Dokumentation',
      subtitle: 'Nachweise klar dokumentieren.',
      description: 'Checklisten, Leistungen und Kontrollen werden nachvollziehbar dokumentiert. Das schafft Transparenz, Nachweissicherheit und bessere Auditfähigkeit.',
      icon: <Shield className="w-8 h-8" />,
      details: ['Rechtssichere Nachweise', 'Transparente Leistungsberichte', 'Audit-ready Dokumente']
    }
  ];

  return (
    <div>
      <SEO 
        title="Das AHAD System - Qualitätsmanagement" 
        description="Erfahren Sie mehr über das AHAD-Modell: Analyse, Handling, Audit und Dokumentation für höchste Standards in der Gebäudereinigung."
        keywords="Qualitätsmanagement Gebäudereinigung, Audit, Dokumentation, AHAD System"
      />
      {/* Hero Section */}
      <section className="bg-[#004888] text-white pt-32 pb-20 lg:pt-48 lg:pb-32 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 tracking-tight">Das <span className="font-logo text-[#8bf8ba]">AHAD</span> System</h1>
            <p className="text-lg md:text-xl text-blue-100 leading-relaxed">
              Struktur ist kein Zufall, sondern das Ergebnis eines methodischen Modells. 
              Unser <span className="font-logo">AHAD</span>-Modell sichert höchste Qualität durch systematische Analyse, effizientes Handling, strenge Audits und lückenlose Dokumentation.
            </p>
          </motion.div>
        </div>
      </section>

      {/* System Overview */}
      <section className="py-20 lg:py-32 bg-white relative">
        <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-50 -translate-y-1/2 hidden lg:block z-0" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
            {steps.map((step, index) => (
              <motion.div
                key={step.id + index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="p-8 sm:p-10 bg-white border border-gray-100 rounded-[2rem] shadow-sm hover:shadow-2xl transition-all duration-500 group relative overflow-hidden flex flex-col h-full"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-bl-full -mr-16 -mt-16 transition-transform duration-500 group-hover:scale-150 opacity-50"></div>
                
                <div className="absolute -top-4 -left-4 w-12 h-12 bg-[#004888] rounded-full flex items-center justify-center text-white font-black text-lg border-4 border-white shadow-lg z-20">
                  {index + 1}
                </div>

                <div className="w-20 h-20 bg-blue-50 text-[#004888] rounded-2xl flex items-center justify-center mb-8 group-hover:bg-[#004888] group-hover:text-white transition-all duration-500 shadow-inner relative z-10">
                  {step.icon}
                </div>
                
                <div className="text-7xl font-black text-gray-50 mb-4 absolute top-8 right-8 z-0 group-hover:text-blue-50/50 transition-colors duration-500">
                  {step.id}
                </div>
                
                <h3 className="text-2xl font-black mb-2 text-gray-900 group-hover:text-[#004888] transition-colors relative z-10 tracking-tight break-words hyphens-auto">
                  {step.title}
                </h3>
                <p className="text-[#2ca06a] font-bold text-sm mb-4 relative z-10 break-words hyphens-auto">
                  {step.subtitle}
                </p>
                
                <p className="text-gray-600 mb-8 flex-grow leading-relaxed relative z-10 font-medium break-words hyphens-auto">
                  {step.description}
                </p>
                
                <ul className="space-y-3 relative z-10 mt-auto bg-gray-50 p-4 rounded-xl border border-gray-100 group-hover:bg-white transition-colors">
                  {step.details.map((detail, i) => (
                    <li key={i} className="flex items-start text-sm text-gray-700 font-bold">
                      <CheckCircle2 className="w-5 h-5 text-[#2ca06a] mr-2 flex-shrink-0" />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="pt-20 pb-32 lg:pt-32 lg:pb-48 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-10 text-gray-900 tracking-tight">Messbarer Nutzen für Ihr Unternehmen</h2>
              <div className="space-y-8">
                {[
                  { title: 'Für den Einkauf', desc: 'Transparente Leistungsverzeichnisse, nachvollziehbare Kalkulationen und messbare KPIs für eine einfache und objektive Lieferantenbewertung.' },
                  { title: 'Für die Objektleitung', desc: 'Massive Entlastung durch klare, digitalisierte Prozesse, feste Ansprechpartner und proaktive Kommunikation bei Abweichungen.' },
                  { title: 'Für den Betrieb', desc: 'Störungsfreie Integration in Ihre Kernabläufe, höchste Arbeitssicherheit und ein stets repräsentatives, hygienisches Umfeld für Mitarbeiter und Kunden.' }
                ].map((item, i) => (
                  <div key={i} className="flex gap-6">
                    <div className="flex-shrink-0 w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-md border border-gray-100">
                      <ArrowRight className="w-6 h-6 text-[#004888]" />
                    </div>
                    <div>
                      <h4 className="text-xl font-bold mb-2 text-gray-900">{item.title}</h4>
                      <p className="text-gray-600 leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="bg-[#004888] p-10 sm:p-12 rounded-[2.5rem] text-white relative overflow-hidden shadow-2xl"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-32 -mt-32"></div>
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full -ml-24 -mb-24"></div>
              
              <h3 className="text-3xl font-bold mb-6 relative z-10 tracking-tight">Bereit für echte Systematik?</h3>
              <p className="text-lg text-blue-100 mb-10 relative z-10 leading-relaxed">
                Lassen Sie uns gemeinsam analysieren, wie das <span className="font-logo">AHAD</span> System Ihre Gebäudedienstleistungen auf ein neues, messbares Level hebt.
              </p>
              <Link
                to="/kontakt"
                className="inline-flex items-center px-8 py-4 bg-[#2ca06a] text-white font-bold rounded-xl hover:bg-[#238054] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px] relative z-10 focus:outline-none focus:ring-4 focus:ring-[#2ca06a]/50"
              >
                Erstgespräch vereinbaren
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}
