import { motion } from 'motion/react';
import { Shield, Target, Users, Award, ChevronRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import SEO from '@/components/SEO';

const values = [
  { title: 'Präzision', description: 'Wir arbeiten nach Millimeter-Genauigkeit und festen Protokollen.', icon: Target },
  { title: 'Sicherheit', description: 'Höchste Standards bei Arbeitsschutz und Objektsicherheit.', icon: Shield },
  { title: 'Teamgeist', description: 'Unsere Mitarbeiter sind unser wertvollstes Kapital.', icon: Users },
  { title: 'Qualität', description: 'ISO-zertifizierte Prozesse für messbare Ergebnisse.', icon: Award }
];

const milestones = [
  { year: '2010', title: 'Gründung', description: 'Start als regionaler Dienstleister in Villingen-Schwenningen.' },
  { year: '2015', title: 'Expansion', description: 'Eröffnung der Standorte Stuttgart und Konstanz.' },
  { year: '2018', title: 'Zertifizierung', description: 'Erfolgreiche Zertifizierung nach DIN EN ISO 9001 & 14001.' },
  { year: '2023', title: 'Innovation', description: 'Einführung des digitalen AHAD-Qualitätsmanagementsystems.' }
];

export default function Unternehmen() {
  return (
    <div className="min-h-screen bg-[#f7f9fb]">
      <SEO 
        title="Unternehmen - AHAD Cleaning" 
        description="AHAD Cleaning: Ihr Partner für professionelle Gebäudereinigung in Süddeutschland. Erfahren Sie mehr über unsere Vision, Werte und Expertise."
        keywords="AHAD Cleaning Company, Gebäudereinigung Unternehmen Süddeutschland, Vision, Werte"
      />
      <section className="pt-32 pb-20 bg-[#001c3b] text-white relative overflow-hidden lg:pt-48 lg:pb-32">
        <div className="absolute inset-0 opacity-25">
          <img 
            src="/images/buero-hero.jpg" 
            alt="AHAD Cleaning Unternehmenszentrale" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black text-white mb-6 tracking-tight">Das Unternehmen</h1>
            <p className="text-lg md:text-xl text-gray-300 leading-relaxed font-medium">
              <span className="font-logo">AHAD</span> Cleaning steht für eine neue Generation der Gebäudedienstleistung. 
              Technik-getrieben, strukturiert und kompromisslos in der Qualität. Lernen Sie das Team hinter der Sauberkeit kennen.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-20 lg:py-32 bg-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gray-50 -skew-x-12 transform origin-top-right -z-10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-8 text-gray-900 tracking-tight">Unsere Vision</h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Gegründet mit dem Ziel, die Standards in der Gebäudereinigung neu zu definieren, 
                haben wir uns zu einem führenden Partner für Industrie und Medizintechnik in Süddeutschland entwickelt.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed mb-8">
                Wir glauben, dass Sauberkeit kein Zufall ist, sondern das Ergebnis von exzellenter Planung, 
                hochqualifizierten Mitarbeitern und modernster Technik. Wir reinigen nicht nur Flächen, wir pflegen Werte.
              </p>
              <ul className="space-y-4">
                {[
                  'Zertifizierte Qualität nach ISO 9001 & 14001',
                  'Regionale Verankerung in Süddeutschland',
                  'Digitales Qualitätsmanagement',
                  'Fester Ansprechpartner für jedes Objekt'
                ].map((item, index) => (
                  <li key={index} className="flex items-center text-gray-700">
                    <CheckCircle2 className="w-5 h-5 text-[#004888] mr-3 flex-shrink-0" />
                    <span className="font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="absolute inset-0 bg-[#004888] rounded-[2rem] transform translate-x-4 translate-y-4 opacity-10"></div>
              <img 
                src="/images/about.png" 
                alt="AHAD Cleaning Team" 
                className="rounded-[2rem] shadow-2xl relative z-10 object-cover w-full h-[500px]"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "/images/about.png";
                }}
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 lg:py-32 bg-[#f2f4f6] relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 tracking-tight text-gray-900">Unsere Werte</h2>
            <p className="text-xl text-gray-600">
              Diese vier Säulen bilden das Fundament unserer täglichen Arbeit und unseres Erfolgs.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((v, index) => (
              <motion.div
                key={v.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="bg-white p-8 rounded-3xl border border-gray-100 hover:shadow-xl transition-all duration-300 group"
              >
                <div className="w-14 h-14 bg-blue-50 text-[#004888] rounded-2xl flex items-center justify-center mb-6 group-hover:bg-[#004888] group-hover:text-white transition-colors duration-300">
                  <v.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold mb-4 text-gray-900">{v.title}</h3>
                <p className="text-gray-600 leading-relaxed text-sm">
                  {v.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Statement */}
      <section className="py-20 lg:py-32 bg-[#004888] text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(#fff 1px, transparent 1px)', backgroundSize: '60px 60px' }}></div>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto"
          >
            <h2 className="text-sm font-bold tracking-[0.2em] text-blue-200 uppercase mb-6">Unsere Mission</h2>
            <blockquote className="text-3xl md:text-4xl lg:text-5xl font-bold mb-12 leading-tight tracking-tight italic">
              "Wir schaffen die saubersten und sichersten Arbeitsumgebungen durch technologische Innovation und menschliche Exzellenz."
            </blockquote>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 text-left">
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-blue-200">Operative Exzellenz</h3>
                <p className="text-blue-50 leading-relaxed">
                  Unsere Mission ist kein bloßes Versprechen, sondern der tägliche Antrieb für unsere operativen Teams. Sie stellt sicher, dass jeder Mitarbeiter die Bedeutung seiner Arbeit für die Sicherheit und Produktivität unserer Kunden versteht.
                </p>
              </div>
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-blue-200">Kundenversprechen</h3>
                <p className="text-blue-50 leading-relaxed">
                  Wir verpflichten uns zu absoluter Zuverlässigkeit und Transparenz. Durch die Kombination von modernster Reinigungstechnik mit hochqualifiziertem Personal garantieren wir Ergebnisse, die über die Standardreinigung hinausgehen.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* History/Milestones */}
      <section className="py-20 lg:py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900 tracking-tight">Unsere Entwicklung</h2>
            <p className="text-xl text-gray-600">
              Ein kontinuierlicher Weg von Wachstum und Qualitätssteigerung.
            </p>
          </div>
          
          <div className="relative max-w-4xl mx-auto">
            {/* Timeline Line */}
            <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 top-0 bottom-0 w-1 bg-blue-100"></div>
            
            <div className="space-y-12">
              {milestones.map((milestone, index) => (
                <motion.div 
                  key={milestone.year}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                  className={`relative flex flex-col md:flex-row items-center ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}
                >
                  {/* Timeline Dot */}
                  <div className="absolute left-0 md:left-1/2 transform -translate-x-1/2 w-6 h-6 bg-[#004888] rounded-full border-4 border-white shadow-md z-10"></div>
                  
                  <div className={`w-full md:w-1/2 pl-10 md:pl-0 ${index % 2 === 0 ? 'md:pl-12' : 'md:pr-12 text-left md:text-right'}`}>
                    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                      <span className="text-[#004888] font-black text-xl mb-2 block">{milestone.year}</span>
                      <h3 className="text-lg font-bold text-gray-900 mb-2">{milestone.title}</h3>
                      <p className="text-gray-600 text-sm">{milestone.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 lg:py-32 bg-[#004888] text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 tracking-tight">Zahlen & Fakten</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12">
            {[
              { label: 'Zufriedene Kunden', value: '250+' },
              { label: 'Gereinigte Fläche m²', value: '1.2M' },
              { label: 'Mitarbeiter', value: '80+' },
              { label: 'Jahre Erfahrung', value: '15+' }
            ].map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                className="text-center p-6 rounded-3xl bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/20 transition-colors group"
              >
                <div className="text-4xl md:text-5xl font-black text-white mb-3 group-hover:scale-110 transition-transform">{stat.value}</div>
                <div className="text-blue-100 font-medium text-sm uppercase tracking-wider">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="pt-20 pb-32 lg:pt-32 lg:pb-48 bg-white text-center relative overflow-hidden">
        <div className="max-w-3xl mx-auto px-4 relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 tracking-tight text-gray-900">Werden Sie Teil unserer Erfolgsgeschichte</h2>
          <p className="text-xl text-gray-600 mb-10 leading-relaxed">
            Ob als Kunde oder als Mitarbeiter – wir freuen uns darauf, Sie kennenzulernen.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/kontakt"
              className="inline-flex items-center justify-center px-8 py-4 bg-[#004888] text-white font-bold rounded-xl hover:bg-blue-900 transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px]"
            >
              Kontakt aufnehmen
              <ChevronRight className="ml-2 w-5 h-5" />
            </Link>
            <Link
              to="/karriere"
              className="inline-flex items-center justify-center px-8 py-4 bg-white border-2 border-[#004888] text-[#004888] font-bold rounded-xl hover:bg-blue-50 transition-all"
            >
              Karriere bei <span className="font-logo">AHAD</span>
              <ChevronRight className="ml-2 w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
