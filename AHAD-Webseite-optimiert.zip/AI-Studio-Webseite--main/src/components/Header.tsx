import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';
import { ChevronDown, Menu, X, Phone } from 'lucide-react';

const navLinks = [
  { 
    name: 'Leistungen', 
    href: '/leistungen',
    sublinks: [
      { name: 'Unterhaltsreinigung', href: '/leistungen/unterhaltsreinigung' },
      { name: 'Industriereinigung', href: '/leistungen/industrie-produktionsreinigung' },
      { name: 'Glas- & Fassadenreinigung', href: '/leistungen/glas-fassadenreinigung' },
      { name: 'Baureinigung', href: '/leistungen/baureinigung' },
      { name: 'Medizintechnik', href: '/leistungen/medizintechnik-reinigung' },
      { name: 'Sonderreinigung', href: '/leistungen/sonderreinigung-stillstandsservice' },
      { name: 'Winterdienst', href: '/leistungen/winterdienst-hausmeisterservice' },
    ]
  },
  { 
    name: 'Branchen', 
    href: '/branchen',
    sublinks: [
      { name: 'Industrie & Produktion', href: '/branchen/industrie-produktion' },
      { name: 'Medizintechnik', href: '/branchen/medizintechnik' },
      { name: 'Büro & Verwaltung', href: '/branchen/buero-verwaltung' },
      { name: 'Gewerbeobjekte', href: '/branchen/gewerbeobjekte' },
      { name: 'Hotellerie', href: '/branchen/hotellerie-objektbetrieb' },
    ]
  },
  { name: 'AHAD System', href: '/ahad-system' },
  { 
    name: 'Unternehmen', 
    href: '/unternehmen',
    sublinks: [
      { name: 'Über uns', href: '/unternehmen' },
      { name: 'Standorte', href: '/standorte' },
      { name: 'Referenzen', href: '/referenzen' },
      { name: 'Kontakt', href: '/kontakt' },
    ]
  },
  { name: 'Karriere', href: '/karriere' },
  { name: 'Fachwissen', href: '/fachwissen' },
];

export default function Header() {
  const location = useLocation();
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [mobileActiveDropdown, setMobileActiveDropdown] = useState<string | null>(null);

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
    setMobileActiveDropdown(null);
  };

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen]);

  // Close mobile menu on desktop resize
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024 && isMobileMenuOpen) {
        closeMobileMenu();
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [isMobileMenuOpen]);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-100">
      <nav className="flex justify-between items-center px-4 md:px-8 py-4 w-full max-w-7xl mx-auto">
        <Link to="/" className="flex items-center gap-3 group logo-hover-effect">
          <div className="flex-shrink-0">
            <svg className="logo-icon-svg" height="32" viewBox="0 0 100 100" width="32">
              <defs>
                <linearGradient id="logo-grad" x1="15%" x2="85%" y1="15%" y2="85%">
                  <stop offset="0%" stopColor="#2ca06a" />
                  <stop offset="100%" stopColor="#1e60a9" />
                </linearGradient>
                <mask id="inner-mask">
                  <rect fill="white" height="100" width="100" x="0" y="0" />
                  <rect fill="black" height="36" rx="6" transform="rotate(45 50 50)" width="36" x="32" y="32" />
                </mask>
              </defs>
              <rect fill="url(#logo-grad)" height="72" mask="url(#inner-mask)" rx="16" transform="rotate(45 50 50)" width="72" x="14" y="14" />
            </svg>
          </div>
          <div className="flex flex-col items-start leading-none font-logo">
            <span className="text-xl font-[900] tracking-tighter text-[#1e60a9] uppercase">AHAD</span>
            <span className="text-[7px] font-[500] text-[#2ca06a] uppercase -mt-1">CLEANING</span>
          </div>
        </Link>

        <div className="hidden lg:flex items-center gap-6">
          {navLinks.map((link) => (
            <div 
              key={link.name}
              className="relative"
              onMouseEnter={() => setActiveDropdown(link.name)}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <Link
                to={link.href}
                className={cn(
                  "flex items-center gap-1 text-sm font-headline font-semibold tracking-tight transition-colors py-2",
                  location.pathname.startsWith(link.href) && link.href !== '/'
                    ? "text-[#1e60a9]" 
                    : "text-gray-600 hover:text-[#1e60a9]"
                )}
              >
                {link.name}
                {link.sublinks && <ChevronDown className={cn("w-3 h-3 transition-transform", activeDropdown === link.name && "rotate-180")} />}
              </Link>

              <AnimatePresence>
                {link.sublinks && activeDropdown === link.name && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full left-0 w-64 bg-white shadow-2xl rounded-2xl border border-gray-100 py-4 mt-1 z-50"
                  >
                    {link.sublinks.map((sub) => (
                      <Link
                        key={sub.name}
                        to={sub.href}
                        className="block px-6 py-2.5 text-sm text-gray-600 hover:bg-blue-50 hover:text-[#004888] transition-colors"
                        onClick={() => setActiveDropdown(null)}
                      >
                        {sub.name}
                      </Link>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <a 
            href="tel:+4977219447915" 
            className="hidden lg:flex items-center gap-2 text-[#004888] font-bold hover:text-[#1e60a9] transition-colors"
          >
            <Phone size={18} />
            <span>+49 7721 944 79 15</span>
          </a>
          <a 
            href="tel:+4977219447915" 
            className="lg:hidden p-2 text-[#004888] hover:bg-blue-50 rounded-lg transition-colors"
            aria-label="Anrufen"
          >
            <Phone size={20} />
          </a>
          
          <Link 
            to="/angebot" 
            className="hidden sm:block bg-[#2ca06a] text-white px-5 py-2.5 font-bold text-xs uppercase tracking-wider hover:bg-[#238054] active:scale-95 transition-all rounded-lg focus:outline-none focus:ring-4 focus:ring-[#2ca06a]/50"
          >
            Angebot
          </Link>

          {/* Mobile Menu Button */}
          <button 
            className="lg:hidden p-2 text-gray-600 hover:text-[#1e60a9] hover:bg-gray-100 rounded-lg transition-all"
            onClick={toggleMobileMenu}
            aria-label="Toggle Menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[60] lg:hidden"
              onClick={closeMobileMenu}
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-0 h-dvh w-[85%] max-w-sm bg-white z-[70] lg:hidden shadow-2xl flex flex-col"
            >
              {/* Mobile Menu Header */}
              <div className="flex items-center justify-between p-6 border-b border-gray-100 flex-shrink-0">
                <Link to="/" onClick={closeMobileMenu} className="flex items-center gap-3 group logo-hover-effect">
                  <div className="flex-shrink-0">
                    <svg className="logo-icon-svg" height="32" viewBox="0 0 100 100" width="32">
                      <defs>
                        <linearGradient id="mobile-logo-grad" x1="15%" x2="85%" y1="15%" y2="85%">
                          <stop offset="0%" stopColor="#2ca06a" />
                          <stop offset="100%" stopColor="#1e60a9" />
                        </linearGradient>
                        <mask id="mobile-inner-mask">
                          <rect fill="white" height="100" width="100" x="0" y="0" />
                          <rect fill="black" height="36" rx="6" transform="rotate(45 50 50)" width="36" x="32" y="32" />
                        </mask>
                      </defs>
                      <rect fill="url(#mobile-logo-grad)" height="72" mask="url(#mobile-inner-mask)" rx="16" transform="rotate(45 50 50)" width="72" x="14" y="14" />
                    </svg>
                  </div>
                  <div className="flex flex-col items-start leading-none font-logo">
                    <span className="text-xl font-[900] tracking-tighter text-[#1e60a9] uppercase">AHAD</span>
                    <span className="text-[7px] font-[500] text-[#2ca06a] uppercase -mt-1">CLEANING</span>
                  </div>
                </Link>
                <button 
                  onClick={closeMobileMenu}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-all"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="flex-grow overflow-y-auto p-6">
                <div className="flex flex-col gap-1">
                  {navLinks.map((link) => (
                    <div key={link.name} className="flex flex-col">
                      <div className="flex items-center justify-between">
                        {link.sublinks ? (
                          <button
                            onClick={() => setMobileActiveDropdown(mobileActiveDropdown === link.name ? null : link.name)}
                            className={cn(
                              "text-lg font-headline font-semibold tracking-tight py-4 flex-grow text-left flex justify-between items-center",
                              location.pathname.startsWith(link.href) && link.href !== '/'
                                ? "text-[#1e60a9]" 
                                : "text-gray-800"
                            )}
                          >
                            {link.name}
                            <ChevronDown className={cn("w-5 h-5 transition-transform duration-300 text-gray-400", mobileActiveDropdown === link.name && "rotate-180")} />
                          </button>
                        ) : (
                          <Link
                            to={link.href}
                            className={cn(
                              "text-lg font-headline font-semibold tracking-tight py-4 flex-grow",
                              location.pathname.startsWith(link.href) && link.href !== '/'
                                ? "text-[#1e60a9]" 
                                : "text-gray-800"
                            )}
                            onClick={closeMobileMenu}
                          >
                            {link.name}
                          </Link>
                        )}
                      </div>
                      
                      <AnimatePresence>
                        {link.sublinks && mobileActiveDropdown === link.name && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden bg-gray-50 rounded-2xl"
                          >
                            <div className="flex flex-col py-2">
                              <Link
                                to={link.href}
                                className="px-6 py-3.5 text-sm font-bold text-[#1e60a9] hover:text-[#004888] transition-colors border-b border-gray-100 mb-1"
                                onClick={closeMobileMenu}
                              >
                                {link.name} Übersicht
                              </Link>
                              {link.sublinks.map((sub) => (
                                <Link
                                  key={sub.name}
                                  to={sub.href}
                                  className="px-6 py-3.5 text-sm font-medium text-gray-600 hover:text-[#1e60a9] transition-colors"
                                  onClick={closeMobileMenu}
                                >
                                  {sub.name}
                                </Link>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-6 border-t border-gray-100 bg-gray-50/50 flex-shrink-0">
                <Link 
                  to="/angebot" 
                  className="block w-full bg-[#2ca06a] text-white text-center px-6 py-4 font-bold text-sm uppercase tracking-wider hover:bg-[#238054] shadow-sm hover:shadow-md hover:-translate-y-[1px] transition-all rounded-xl focus:outline-none focus:ring-4 focus:ring-[#2ca06a]/50"
                  onClick={closeMobileMenu}
                >
                  Kostenloses Angebot
                </Link>
                <div className="mt-4 flex justify-center gap-6">
                  <a href="tel:+4977219447915" className="text-gray-400 hover:text-[#004888] transition-colors">
                    <Phone size={20} />
                  </a>
                  {/* Add other social icons if needed */}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
