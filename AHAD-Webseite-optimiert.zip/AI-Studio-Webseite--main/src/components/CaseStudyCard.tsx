import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

type CaseStudyCardProps = {
  href: string;
  title: string;
  meta: string;
  kpiValue: string;
  kpiContext: string;
  benefit: string;
  cta?: string;
};

export function CaseStudyCard({
  href,
  title,
  meta,
  kpiValue,
  kpiContext,
  benefit,
  cta = "Case Study ansehen",
}: CaseStudyCardProps) {
  return (
    <Link to={href} className="block group h-full">
      <article className="h-full rounded-2xl border border-slate-200 bg-[#f7f9fb] p-8 shadow-sm transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-md flex flex-col">
        <div className="mb-6">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.14em] text-[#004888]/80">
            Referenzbeispiel
          </p>

          <h3 className="mb-2 text-lg font-black leading-snug text-[#001c3b] break-words hyphens-auto">
            {title}
          </h3>

          <p className="text-sm font-semibold leading-relaxed text-[#004888] break-words hyphens-auto">
            {meta}
          </p>
        </div>

        <div className="mb-6 rounded-xl border border-slate-200 bg-white p-5">
          <div className="mb-2 text-4xl font-black tracking-tight text-[#2ca06a]">
            {kpiValue}
          </div>

          <p className="text-sm font-bold leading-relaxed text-[#001c3b]">
            {kpiContext}
          </p>
        </div>

        <p className="mb-6 text-sm font-medium leading-relaxed text-[#424751] flex-grow">
          {benefit}
        </p>

        <div className="mt-auto flex items-center text-sm font-bold text-[#004888] transition-colors group-hover:text-[#1e60a9]">
          <span>{cta}</span>
          <ArrowRight className="ml-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
        </div>
      </article>
    </Link>
  );
}
