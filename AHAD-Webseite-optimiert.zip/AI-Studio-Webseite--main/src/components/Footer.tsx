import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Instagram, Linkedin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white pt-20 pb-12 lg:pt-32 lg:pb-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Column */}
          <div className="space-y-8">
            <Link to="/" className="flex items-center gap-3 group logo-hover-effect">
              <div className="flex-shrink-0">
                <svg className="logo-icon-svg" height="32" viewBox="0 0 100 100" width="32">
                  <defs>
                    <linearGradient id="logo-grad-footer" x1="15%" x2="85%" y1="15%" y2="85%">
                      <stop offset="0%" stopColor="#2ca06a" />
                      <stop offset="100%" stopColor="#1e60a9" />
                    </linearGradient>
                    <mask id="inner-mask-footer">
                      <rect fill="white" height="100" width="100" x="0" y="0" />
                      <rect fill="black" height="36" rx="6" transform="rotate(45 50 50)" width="36" x="32" y="32" />
                    </mask>
                  </defs>
                  <rect fill="url(#logo-grad-footer)" height="72" mask="url(#inner-mask-footer)" rx="16" transform="rotate(45 50 50)" width="72" x="14" y="14" />
                </svg>
              </div>
              <div className="flex flex-col items-start leading-none font-logo">
                <span className="text-xl font-[900] tracking-tighter text-white uppercase">AHAD</span>
                <span className="text-[7px] font-[500] text-[#2ca06a] uppercase -mt-1">CLEANING</span>
              </div>
            </Link>
            <p className="text-gray-400 leading-relaxed">
              Ihr zertifizierter Partner für strukturierte Gebäudedienstleistungen in Süddeutschland. 
              Präzision, Sauberkeit und Sicherheit auf höchstem Niveau.
            </p>
            <div className="flex gap-4">
              {[Instagram, Linkedin].map((Icon, i) => (
                <a key={i} href={i === 0 ? "https://instagram.com/ahadcleaning" : "https://linkedin.com/company/ahadcleaning"} target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center hover:bg-[#004888] transition-colors">
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-8">Leistungen</h4>
            <ul className="space-y-4">
              <li><Link to="/leistungen/unterhaltsreinigung" className="text-gray-400 hover:text-white transition-colors">Unterhaltsreinigung</Link></li>
              <li><Link to="/leistungen/industrie-produktionsreinigung" className="text-gray-400 hover:text-white transition-colors">Industriereinigung</Link></li>
              <li><Link to="/leistungen/glas-fassadenreinigung" className="text-gray-400 hover:text-white transition-colors">Glas- & Fassadenreinigung</Link></li>
              <li><Link to="/leistungen/baureinigung" className="text-gray-400 hover:text-white transition-colors">Baureinigung</Link></li>
              <li><Link to="/leistungen/medizintechnik-reinigung" className="text-gray-400 hover:text-white transition-colors">Medizintechnik</Link></li>
              <li><Link to="/leistungen/sonderreinigung-stillstandsservice" className="text-gray-400 hover:text-white transition-colors">Sonderreinigung</Link></li>
              <li><Link to="/leistungen/winterdienst-hausmeisterservice" className="text-gray-400 hover:text-white transition-colors">Winterdienst</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-lg font-bold mb-8">Unternehmen</h4>
            <ul className="space-y-4">
              <li><Link to="/angebot" className="text-[#8bf8ba] font-bold hover:text-white transition-colors">Kostenloses Angebot</Link></li>
              <li><Link to="/unternehmen" className="text-gray-400 hover:text-white transition-colors">Über uns</Link></li>
              <li><Link to="/ahad-system" className="text-gray-400 hover:text-white transition-colors">Das AHAD System</Link></li>
              <li><Link to="/referenzen" className="text-gray-400 hover:text-white transition-colors">Referenzen</Link></li>
              <li><Link to="/karriere" className="text-gray-400 hover:text-white transition-colors">Karriere</Link></li>
              <li><Link to="/standorte" className="text-gray-400 hover:text-white transition-colors">Standorte & Regionen</Link></li>
            </ul>
          </div>

          {/* Fachwissen */}
          <div>
            <h4 className="text-lg font-bold mb-8">Fachwissen</h4>
            <ul className="space-y-4">
              <li><Link to="/fachwissen/unterhaltsreinigung-unternehmen-reinigungsintervalle" className="text-gray-400 hover:text-white transition-colors">Reinigungsintervalle</Link></li>
              <li><Link to="/fachwissen/iso-9001-iso-14001-gebaeudereinigung-unternehmen" className="text-gray-400 hover:text-white transition-colors">ISO-Zertifizierungen</Link></li>
              <li><Link to="/fachwissen/reinigungsfirma-wechseln-checkliste-tipps" className="text-gray-400 hover:text-white transition-colors">Anbieterwechsel-Checkliste</Link></li>
              <li><Link to="/fachwissen" className="text-gray-400 hover:text-white transition-colors">Alle Insights</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-bold mb-8">Kontakt</h4>
            <ul className="space-y-6">
              <li className="flex gap-4">
                <MapPin className="w-6 h-6 text-[#004888] flex-shrink-0" />
                <a 
                  href="https://goo.gl/maps/your-actual-maps-link" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Max-Planck-Straße 11<br />78052 Villingen-Schwenningen
                </a>
              </li>
              <li className="flex gap-4">
                <Phone className="w-6 h-6 text-[#004888] flex-shrink-0" />
                <a href="tel:+4977219447915" className="text-gray-400 hover:text-white transition-colors">
                  +49 7721 944 79 15
                </a>
              </li>
              <li className="flex gap-4">
                <Mail className="w-6 h-6 text-[#004888] flex-shrink-0" />
                <a href="mailto:info@ahad-cleaning.de" className="text-gray-400 hover:text-white transition-colors">
                  info@ahad-cleaning.de
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-500">
          <p>© {new Date().getFullYear()} AHAD Cleaning GmbH. Alle Rechte vorbehalten.</p>
          <div className="flex gap-8">
            <Link to="/impressum" className="hover:text-white transition-colors">Impressum</Link>
            <Link to="/datenschutz" className="hover:text-white transition-colors">Datenschutz</Link>
            <Link to="/admin" className="hover:text-white transition-colors opacity-0 hover:opacity-100 transition-opacity">Admin</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
