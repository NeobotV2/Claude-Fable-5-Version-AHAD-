import { MapPin, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

const areas = [
  { name: 'Stuttgart', path: '/standorte/stuttgart', region: 'Landeshauptstadt & Umland' },
  { name: 'Villingen-Schwenningen', path: '/standorte/villingen-schwenningen', region: 'Schwarzwald-Baar-Kreis' },
  { name: 'Konstanz', path: '/standorte/konstanz', region: 'Bodenseeregion' },
  { name: 'Süddeutschland', path: '/kontakt', region: 'Überregionaler Service' }
];

export default function ServiceAreas() {
  return (
    <section className="py-20 bg-[#f7f9fb] border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-black text-[#001c3b] mb-4 tracking-tight">Einsatzgebiete für unsere Leistungen</h2>
          <p className="text-lg text-[#424751] max-w-2xl mx-auto">
            Wir sind in ganz Süddeutschland für Sie im Einsatz. Profitieren Sie von unserer regionalen Präsenz und schnellen Reaktionszeiten.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {areas.map((area, i) => (
            <motion.div
              key={area.name}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Link 
                to={area.path}
                className="group block bg-white p-6 rounded-2xl border border-gray-100 hover:border-[#004888] hover:shadow-xl transition-all duration-300"
              >
                <div className="w-12 h-12 bg-blue-50 text-[#004888] rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#004888] group-hover:text-white transition-colors">
                  <MapPin className="w-6 h-6" />
                </div>
                <h3 className="font-black text-[#001c3b] mb-1">{area.name}</h3>
                <p className="text-sm text-gray-500 mb-4">{area.region}</p>
                <div className="flex items-center text-[#004888] font-bold text-sm">
                  Details ansehen
                  <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
