import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Send, Loader2, CheckCircle2 } from 'lucide-react';
import { db, collection, addDoc, serverTimestamp } from '@/firebase';

const SERVICES = [
  'Unterhaltsreinigung',
  'Industriereinigung',
  'Glas- & Fassadenreinigung',
  'Baureinigung',
  'Sonderreinigung',
  'Winterdienst',
  'Sonstiges'
];

export default function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [honeypot, setHoneypot] = useState('');
  const [formData, setFormData] = useState({
    contactPerson: '',
    company: '',
    email: '',
    phone: '',
    serviceType: SERVICES[0],
    message: '',
    privacyAccepted: false
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.privacyAccepted) return;
    // Honeypot: unsichtbares Feld — wenn ausgefuellt, war es ein Bot.
    if (honeypot) {
      setIsSuccess(true);
      return;
    }

    setIsSubmitting(true);
    setSubmitError(null);
    const path = 'leads';
    try {
      await addDoc(collection(db, path), {
        ...formData,
        status: 'new',
        createdAt: serverTimestamp()
      });

      setIsSuccess(true);
    } catch (error) {
      console.error('Error submitting contact form:', error);
      setSubmitError('Die Nachricht konnte nicht gesendet werden. Bitte versuchen Sie es erneut oder rufen Sie uns an: +49 7721 9447915.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white p-12 rounded-3xl shadow-xl text-center border border-green-100"
      >
        <div className="w-20 h-20 bg-green-50 text-[#005332] rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 size={40} />
        </div>
        <h3 className="text-2xl font-black text-[#001c3b] mb-4">Nachricht gesendet!</h3>
        <p className="text-[#424751] mb-8">
          Vielen Dank für Ihre Nachricht. Wir haben Ihre Anfrage erhalten und werden uns in Kürze bei Ihnen melden.
        </p>
        <button 
          onClick={() => setIsSuccess(false)}
          className="text-[#005332] font-bold hover:underline"
        >
          Weitere Nachricht senden
        </button>
      </motion.div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 relative">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-sm font-bold text-[#001c3b] uppercase tracking-wider">Name *</label>
          <input
            required
            type="text"
            value={formData.contactPerson}
            onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
            className="w-full p-4 bg-gray-50 rounded-xl border-2 border-transparent focus:border-[#004888] outline-none transition-all"
            placeholder="Ihr Name"
            maxLength={100}
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-bold text-[#001c3b] uppercase tracking-wider">Firma</label>
          <input
            type="text"
            value={formData.company}
            onChange={(e) => setFormData({ ...formData, company: e.target.value })}
            className="w-full p-4 bg-gray-50 rounded-xl border-2 border-transparent focus:border-[#004888] outline-none transition-all"
            placeholder="Ihre Firma (optional)"
            maxLength={120}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="text-sm font-bold text-[#001c3b] uppercase tracking-wider">E-Mail *</label>
          <input
            required
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="w-full p-4 bg-gray-50 rounded-xl border-2 border-transparent focus:border-[#004888] outline-none transition-all"
            placeholder="ihre@email.de"
            maxLength={150}
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-bold text-[#001c3b] uppercase tracking-wider">Telefon</label>
          <input
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            className="w-full p-4 bg-gray-50 rounded-xl border-2 border-transparent focus:border-[#004888] outline-none transition-all"
            placeholder="Ihre Telefonnummer"
            maxLength={40}
          />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-bold text-[#001c3b] uppercase tracking-wider">Leistung</label>
        <select
          value={formData.serviceType}
          onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
          className="w-full p-4 bg-gray-50 rounded-xl border-2 border-transparent focus:border-[#004888] outline-none transition-all appearance-none"
        >
          {SERVICES.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-bold text-[#001c3b] uppercase tracking-wider">Nachricht</label>
        <textarea
          rows={4}
          value={formData.message}
          onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          className="w-full p-4 bg-gray-50 rounded-xl border-2 border-transparent focus:border-[#004888] outline-none transition-all resize-none"
          placeholder="Wie können wir Ihnen helfen?"
          maxLength={2000}
        />
      </div>

      <div className="flex items-start gap-3">
        <input
          required
          type="checkbox"
          id="privacy"
          checked={formData.privacyAccepted}
          onChange={(e) => setFormData({ ...formData, privacyAccepted: e.target.checked })}
          className="mt-1 w-5 h-5 accent-[#004888]"
        />
        <label htmlFor="privacy" className="text-sm text-gray-500 leading-relaxed">
          Ich stimme zu, dass meine Angaben zur Kontaktaufnahme und für Rückfragen dauerhaft gespeichert werden. 
          Weitere Informationen finden Sie in unserer <a href="/datenschutz" className="text-[#004888] underline">Datenschutzerklärung</a>.
        </label>
      </div>

      {/* Honeypot — fuer Menschen unsichtbar, Bots fuellen es aus */}
      <div className="absolute -left-[9999px]" aria-hidden="true">
        <label htmlFor="website">Website</label>
        <input
          type="text"
          id="website"
          name="website"
          tabIndex={-1}
          autoComplete="off"
          value={honeypot}
          onChange={(e) => setHoneypot(e.target.value)}
        />
      </div>

      {submitError && (
        <div role="alert" className="bg-red-50 border border-red-200 text-red-800 rounded-xl p-4 text-sm">
          {submitError}
        </div>
      )}

      <button
        disabled={isSubmitting}
        type="submit"
        className="w-full bg-[#004888] text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-[#003a6e] transition-all shadow-sm hover:shadow-md hover:-translate-y-[1px] disabled:opacity-50"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="animate-spin" size={20} /> Wird gesendet...
          </>
        ) : (
          <>
            <Send size={20} /> Nachricht senden
          </>
        )}
      </button>
    </form>
  );
}
