import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig, loadEnv} from 'vite';

export default defineConfig(({mode}) => {
  const env = loadEnv(mode, '.', '');
  return {
    plugins: [react(), tailwindcss()],
    define: {
      // SICHERHEIT: Der Gemini-Key wird NUR im Dev-Modus in den Client injiziert
      // (für das interne Tool /generate-images). Im Produktions-Build landet er
      // niemals im JavaScript-Bundle, wo ihn jeder Besucher auslesen könnte.
      'process.env.GEMINI_API_KEY': JSON.stringify(
        mode === 'development' ? env.GEMINI_API_KEY : undefined
      ),
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
      },
    },
    build: {
      // Vendor-Splitting: große Bibliotheken in eigene, langfristig cachebare Chunks
      rollupOptions: {
        output: {
          manualChunks: {
            'vendor-react': ['react', 'react-dom', 'react-router-dom'],
            'vendor-firebase': ['firebase/app', 'firebase/auth', 'firebase/firestore'],
            'vendor-motion': ['motion'],
          },
        },
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
    },
  };
});
