import { GoogleGenAI } from '@google/genai';
import fs from 'fs';
import path from 'path';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const prompts = [
  {
    filename: 'unterhaltsreinigung.jpg',
    prompt: 'Photorealistic image of a professional female cleaner in a modern, bright office. She is wearing a dark blue polo shirt. On the chest of the polo shirt is a prominent logo consisting of a rotated square (diamond shape) in green and blue gradients. She is smiling and wiping a desk. High quality, 8k, professional photography.'
  },
  {
    filename: 'industriereinigung.jpg',
    prompt: 'Photorealistic image of a professional male industrial cleaner in a modern factory. He is wearing a dark blue polo shirt with a green and blue diamond-shaped logo on the back. He is operating a professional floor scrubber machine. High quality, 8k, professional photography.'
  },
  {
    filename: 'glasreinigung.jpg',
    prompt: 'Photorealistic image of a professional window cleaner cleaning a large glass facade of a modern office building. Wearing a dark blue polo shirt with a green and blue diamond-shaped logo on the back. Bright sunny day, clear reflections. High quality, 8k, professional photography.'
  },
  {
    filename: 'baureinigung.jpg',
    prompt: 'Photorealistic image of a professional cleaner at a bright, newly finished indoor construction site. Wearing a dark blue polo shirt with a green and blue diamond-shaped logo on the chest, and a yellow hard hat. Sweeping the floor. High quality, 8k, professional photography.'
  },
  {
    filename: 'medizintechnik.jpg',
    prompt: 'Photorealistic image of a professional cleaner in a sterile medical technology environment. Wearing a dark blue polo shirt with a green and blue diamond-shaped logo on the chest, along with a hairnet and gloves. Carefully cleaning a stainless steel surface. High quality, 8k, professional photography.'
  }
];

async function generateImages() {
  const outputDir = path.join(process.cwd(), 'public', 'images');
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  for (const item of prompts) {
    console.log(`Generating image for ${item.filename}...`);
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: item.prompt,
        config: {
          imageConfig: {
            aspectRatio: "16:9",
            imageSize: "1K"
          }
        }
      });

      let base64Data = '';
      if (response.candidates && response.candidates[0].content.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            base64Data = part.inlineData.data;
            break;
          }
        }
      }

      if (base64Data) {
        const filePath = path.join(outputDir, item.filename);
        fs.writeFileSync(filePath, Buffer.from(base64Data, 'base64'));
        console.log(`Saved ${item.filename}`);
      } else {
        console.error(`No image data found for ${item.filename}`);
      }
    } catch (error) {
      console.error(`Error generating ${item.filename}:`, error);
    }
  }
}

generateImages();
