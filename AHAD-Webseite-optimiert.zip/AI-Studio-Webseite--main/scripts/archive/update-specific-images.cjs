const fs = require('fs');
const path = require('path');
const https = require('https');

const publicImagesDir = path.join(__dirname, 'public', 'images');

const categories = {
  medizintechnik: {
    files: ['medizintechnik-hero.jpg', 'medizintechnik-labor.jpg', 'medizintechnik-reinraum.jpg', 'medizintechnik-labor2.jpg'],
    ids: [
      '1519494026892-80bbd2d6fd0d', // hospital/medical
      '1579684385127-1ef15d508118', // lab
      '1583324113626-70df0f4deaab', // lab2
      '1532938911079-1b06ac7ceec7', // cleanroom
      '1551076805-e16760c26246', // medical
      '1516549655169-df83a0774514', // medical
      '1576091160399-112ba8d25d1d'  // hospital
    ]
  },
  sonderreinigung: {
    files: ['sonderreinigung-hero.jpg', 'sonderreinigung-boden.jpg', 'sonderreinigung-maschinen.jpg'],
    ids: [
      '1581578731548-c64695cc6952', // floor cleaning
      '1584622650111-993a426fbf0a', // cleaning
      '1581091226825-a6a2a5aee158', // industry
      '1615811361523-6bd03d7748e7', // cleaning equipment
      '1527515637-ed504c86811d', // industrial
      '1504307651254-35680f356dfd'  // cleaning
    ]
  },
  winterdienst: {
    files: ['winterdienst-hero.jpg', 'winterdienst-gehweg.jpg', 'winterdienst-instandhaltung.jpg'],
    ids: [
      '1478265409131-1f65c88f965c', // snow
      '1516820208784-270b250306e3', // snow path
      '1542601098-8fc114e148e2', // ice/winter
      '1482156307324-419b4b008678', // winter
      '1517299321609-52687d1bc9e3', // winter
      '1483664852095-d6cc68707022'  // snow
    ]
  }
};

async function downloadImage(id, destPath) {
  const url = `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&q=80&w=1200`;
  return new Promise((resolve, reject) => {
    const request = https.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        https.get(res.headers.location, (redirectRes) => {
          if (redirectRes.statusCode === 200) {
            const file = fs.createWriteStream(destPath);
            redirectRes.pipe(file);
            file.on('finish', () => { file.close(); resolve(true); });
          } else {
            reject(new Error(`Redirect failed: ${redirectRes.statusCode}`));
          }
        }).on('error', reject);
      } else if (res.statusCode === 200) {
        const file = fs.createWriteStream(destPath);
        res.pipe(file);
        file.on('finish', () => { file.close(); resolve(true); });
      } else {
        reject(new Error(`HTTP ${res.statusCode}`));
      }
    }).on('error', reject);
    request.setTimeout(10000, () => {
      request.destroy();
      reject(new Error('Timeout'));
    });
  });
}

async function processCategory(catName, catData) {
  console.log(`\nProcessing category: ${catName}`);
  let idIndex = 0;
  
  for (const file of catData.files) {
    const destPath = path.join(publicImagesDir, file);
    let success = false;
    
    while (!success && idIndex < catData.ids.length) {
      const id = catData.ids[idIndex];
      console.log(`  Trying ID ${id} for ${file}...`);
      try {
        await downloadImage(id, destPath);
        console.log(`  -> Success! Saved to ${file}`);
        success = true;
      } catch (err) {
        console.log(`  -> Failed: ${err.message}`);
      }
      idIndex++; // Move to next ID for the next file or retry
    }
    
    if (!success) {
      console.error(`  -> ERROR: Ran out of IDs for ${file}`);
    }
  }
}

async function main() {
  for (const [catName, catData] of Object.entries(categories)) {
    await processCategory(catName, catData);
  }
  console.log('\nFinished updating specific images.');
}

main();
