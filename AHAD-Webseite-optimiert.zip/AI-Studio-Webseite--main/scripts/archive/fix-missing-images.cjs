const fs = require('fs');
const path = require('path');

const publicImagesDir = path.join(__dirname, 'public', 'images');

const fallbackMap = {
  "medizintechnik-hero.jpg": "medizintechnik-labor2.jpg",
  "winterdienst-hero.jpg": "winterdienst-instandhaltung.jpg",
  "winterdienst-gehweg.jpg": "winterdienst-instandhaltung.jpg",
  "baureinigung-baustelle.jpg": "baureinigung-hero.jpg",
  "glasreinigung-hero.jpg": "glasreinigung-fassade.jpg",
  "sonderreinigung-maschinen.jpg": "sonderreinigung-boden.jpg",
  "buero-konferenz.jpg": "buero-hero.jpg",
  "industrie-fertigung.jpg": "industrie-halle.jpg",
  "hotellerie-zimmer.jpg": "hotellerie-hero.jpg",
  "hotellerie-flur.jpg": "hotellerie-hero.jpg",
  "standort-stuttgart-content.jpg": "standort-stuttgart-hero.jpg",
  "standort-konstanz-hero.jpg": "standort-konstanz-content.jpg",
  "home-company1.jpg": "buero-hero.jpg",
  "home-company2.jpg": "karriere-hero.jpg"
};

for (const [missing, fallback] of Object.entries(fallbackMap)) {
  const missingPath = path.join(publicImagesDir, missing);
  const fallbackPath = path.join(publicImagesDir, fallback);
  
  if (!fs.existsSync(missingPath) && fs.existsSync(fallbackPath)) {
    fs.copyFileSync(fallbackPath, missingPath);
    console.log(`Copied ${fallback} to ${missing}`);
  }
}

console.log('All missing images have been replaced with working fallbacks.');
