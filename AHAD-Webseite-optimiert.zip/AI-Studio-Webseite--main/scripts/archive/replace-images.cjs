const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(function(file) {
    file = dir + '/' + file;
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) { 
      results = results.concat(walk(file));
    } else { 
      if (file.endsWith('.tsx') || file.endsWith('.ts')) {
        results.push(file);
      }
    }
  });
  return results;
}

const files = walk('./src');
let count = 0;

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  if (content.includes('unsplash.com')) {
    // Replace all unsplash URLs with picsum.photos URLs
    // We'll use a regex to match the URL and replace it with a random seed
    const regex = /https:\/\/images\.unsplash\.com\/photo-[a-zA-Z0-9-]+[^"'\s]*/g;
    
    content = content.replace(regex, (match) => {
      // Generate a random seed based on the match string to keep it consistent but different per image
      const seed = Math.random().toString(36).substring(7);
      // Determine size based on the original URL if possible, or default to 1920/1080
      let width = 1920;
      let height = 1080;
      if (match.includes('w=800')) {
        width = 800;
        height = 600;
      } else if (match.includes('w=600')) {
        width = 600;
        height = 400;
      } else if (match.includes('w=100')) {
        width = 100;
        height = 100;
      }
      return `https://picsum.photos/seed/${seed}/${width}/${height}`;
    });
    
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Updated ${file}`);
    count++;
  }
});

console.log(`Updated ${count} files.`);
