const fs = require('fs');
const path = require('path');
const https = require('https');

const imageMap = {
  "medizintechnik-hero": "hospital",
  "medizintechnik-labor": "laboratory",
  "medizintechnik-reinraum": "cleanroom",
  "winterdienst-hero": "snow",
  "winterdienst-gehweg": "snow",
  "winterdienst-instandhaltung": "winter",
  "unterhaltsreinigung-hero": "cleaning",
  "baureinigung-hero": "construction",
  "baureinigung-baustelle": "building",
  "baureinigung-endreinigung": "architecture",
  "industrie-hero": "warehouse",
  "glasreinigung-hero": "window",
  "glasreinigung-fassade": "facade",
  "glasreinigung-fenster": "window",
  "sonderreinigung-hero": "industrial",
  "sonderreinigung-boden": "floor",
  "sonderreinigung-maschinen": "machine",
  "buero-hero": "office",
  "buero-konferenz": "conference",
  "industrie-fertigung": "manufacturing",
  "industrie-halle": "warehouse",
  "hotellerie-hero": "hotel",
  "hotellerie-zimmer": "hotel",
  "hotellerie-flur": "hotel",
  "medizintechnik-labor2": "research",
  "gewerbe-hero": "commercial",
  "standort-vs-hero": "city",
  "standort-vs-content": "germany",
  "standort-stuttgart-hero": "stuttgart",
  "standort-stuttgart-content": "street",
  "standort-konstanz-hero": "konstanz",
  "standort-konstanz-content": "lake",
  "home-company1": "team",
  "home-company2": "business",
  "karriere-hero": "staff",
  "fachwissen-iso": "certificate"
};

const publicImagesDir = path.join(__dirname, 'public', 'images');
if (!fs.existsSync(publicImagesDir)) {
  fs.mkdirSync(publicImagesDir, { recursive: true });
}

function downloadImage(url, dest) {
  return new Promise((resolve, reject) => {
    const request = https.get(url, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302 || res.statusCode === 307 || res.statusCode === 308) {
        // Handle redirect
        const redirectUrl = res.headers.location.startsWith('http') ? res.headers.location : `https://loremflickr.com${res.headers.location}`;
        downloadImage(redirectUrl, dest).then(resolve).catch(reject);
      } else if (res.statusCode === 200) {
        const file = fs.createWriteStream(dest);
        res.pipe(file);
        file.on('finish', () => { file.close(); resolve(); });
      } else {
        reject(new Error(`Failed to download ${url}: ${res.statusCode}`));
      }
    }).on('error', reject);
    
    request.setTimeout(15000, () => {
      request.destroy();
      reject(new Error(`Timeout downloading ${url}`));
    });
  });
}

const delay = ms => new Promise(res => setTimeout(res, ms));

async function main() {
  const entries = Object.entries(imageMap);
  for (let i = 0; i < entries.length; i++) {
    const [name, keyword] = entries[i];
    const url = `https://loremflickr.com/1200/800/${keyword}/all`;
    const dest = path.join(publicImagesDir, `${name}.jpg`);
    console.log(`Downloading ${i+1}/${entries.length}: ${name}.jpg...`);
    try {
      await downloadImage(url, dest);
      await delay(500);
    } catch (err) {
      console.error(`Error downloading ${name}:`, err.message);
    }
  }
  console.log('Finished downloading contextual images.');
}

main();
