const fs = require('fs');
const path = require('path');
const https = require('https');

const publicImagesDir = path.join(__dirname, 'public', 'images');
const destPath = path.join(publicImagesDir, 'medizintechnik-hero.jpg');

// IDs of high-tech medical / hospital images (no text/signs)
const idsToTry = [
  '1516549655169-df83a0774514', // Operating room / medical equipment
  '1576091160550-21080f0a85f8', // Medical lights / OP
  '1584362917165-526a968579e8', // Microscope / Lab tech
  '1551076805-e16760c26246'  // Medical generic
];

async function downloadImage(id, destPath) {
  const url = `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&q=80&w=1200`;
  return new Promise((resolve, reject) => {
    const request = https.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        https.get(res.headers.location, (redirectRes) => {
          if (redirectRes.statusCode === 200) {
            const file = fs.createWriteStream(destPath);
            redirectRes.pipe(file);
            file.on('finish', () => { file.close(); resolve(true); });
          } else {
            reject(new Error(`Redirect failed: ${redirectRes.statusCode}`));
          }
        }).on('error', reject);
      } else if (res.statusCode === 200) {
        const file = fs.createWriteStream(destPath);
        res.pipe(file);
        file.on('finish', () => { file.close(); resolve(true); });
      } else {
        reject(new Error(`HTTP ${res.statusCode}`));
      }
    }).on('error', reject);
    request.setTimeout(10000, () => {
      request.destroy();
      reject(new Error('Timeout'));
    });
  });
}

async function main() {
  console.log('Replacing medizintechnik-hero.jpg...');
  let success = false;
  
  for (const id of idsToTry) {
    console.log(`Trying ID ${id}...`);
    try {
      await downloadImage(id, destPath);
      console.log(`-> Success! Image replaced.`);
      success = true;
      break; // Stop after first successful download
    } catch (err) {
      console.log(`-> Failed: ${err.message}`);
    }
  }
  
  if (!success) {
    console.error('Failed to download any of the replacement images.');
  }
}

main();
