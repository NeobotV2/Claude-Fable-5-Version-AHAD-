const fs = require('fs');
const path = require('path');

const srcDir = path.join(__dirname, 'src');

const promptMap = {
  "medical": "modern_hospital_corridor_clean_bright_photorealistic",
  "laboratory": "modern_medical_laboratory_sterile_clean_photorealistic",
  "cleanroom": "high_tech_cleanroom_manufacturing_sterile_photorealistic",
  "winter": "commercial_snow_clearing_winter_service_tractor_photorealistic",
  "snow": "cleared_snow_path_office_building_winter_photorealistic",
  "ice": "winter_maintenance_salt_spreading_commercial_photorealistic",
  "cleaning": "professional_commercial_cleaner_vacuuming_office_photorealistic",
  "construction": "post_construction_cleaning_commercial_building_photorealistic",
  "building": "modern_office_building_exterior_glass_facade_photorealistic",
  "architecture": "modern_corporate_architecture_clean_lines_photorealistic",
  "industry": "clean_industrial_warehouse_factory_floor_photorealistic",
  "windows": "professional_window_cleaner_skyscraper_facade_photorealistic",
  "facade": "cleaning_glass_facade_modern_office_building_photorealistic",
  "glass": "squeegee_cleaning_large_window_bright_photorealistic",
  "specialized": "specialized_deep_cleaning_industrial_equipment_photorealistic",
  "floor": "industrial_floor_scrubber_machine_cleaning_warehouse_photorealistic",
  "machine": "cleaning_heavy_manufacturing_machinery_photorealistic",
  "office": "modern_bright_clean_corporate_office_workspace_photorealistic",
  "conference": "spotless_empty_conference_room_glass_table_photorealistic",
  "manufacturing": "clean_manufacturing_plant_production_line_photorealistic",
  "warehouse": "empty_clean_industrial_warehouse_logistics_photorealistic",
  "hotel": "luxury_hotel_lobby_spotless_clean_photorealistic",
  "room": "perfectly_made_hotel_bed_clean_room_photorealistic",
  "hallway": "clean_bright_hotel_corridor_photorealistic",
  "research": "scientific_research_facility_clean_sterile_photorealistic",
  "commercial": "modern_commercial_building_exterior_clean_photorealistic",
  "villingen": "villingen_schwenningen_city_architecture_photorealistic",
  "schwenningen": "modern_office_building_black_forest_germany_photorealistic",
  "stuttgart": "stuttgart_city_skyline_modern_architecture_photorealistic",
  "city": "modern_business_district_city_street_clean_photorealistic",
  "konstanz": "konstanz_lake_constance_architecture_photorealistic",
  "lake": "commercial_building_near_lake_constance_photorealistic",
  "team": "professional_cleaning_staff_team_uniform_photorealistic",
  "business": "facility_management_professional_handshake_b2b_photorealistic",
  "career": "happy_cleaning_staff_team_diverse_photorealistic",
  "certificate": "iso_9001_certification_document_quality_management_photorealistic"
};

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(function(file) {
    file = dir + '/' + file;
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) { 
      results = results.concat(walk(file));
    } else { 
      if (file.endsWith('.tsx') || file.endsWith('.ts')) {
        results.push(file);
      }
    }
  });
  return results;
}

const files = walk(srcDir);

files.forEach(file => {
  const originalContent = fs.readFileSync(file, 'utf8');
  let content = originalContent;
  
  // Replace https://picsum.photos/seed/{seed}/{width}/{height}
  const regex = /https:\/\/picsum\.photos\/seed\/([a-zA-Z0-9-]+)\/(\d+)\/(\d+)/g;
  
  let matchCount = 0;
  content = content.replace(regex, (match, seed, width, height) => {
    matchCount++;
    const prompt = promptMap[seed] || seed;
    return `https://image.pollinations.ai/prompt/${prompt}?width=${width}&height=${height}&nologo=true`;
  });
  
  if (content !== originalContent) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Updated ${matchCount} images in ${file}`);
  }
});

console.log('All files updated to use Pollinations AI images.');
