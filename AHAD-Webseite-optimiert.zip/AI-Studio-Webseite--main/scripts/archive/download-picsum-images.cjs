const fs = require('fs');
const path = require('path');
const https = require('https');

const imageMap = {
  "medizintechnik-hero": "https://picsum.photos/seed/medical/1920/1080",
  "medizintechnik-labor": "https://picsum.photos/seed/laboratory/1200/800",
  "medizintechnik-reinraum": "https://picsum.photos/seed/cleanroom/1200/800",
  "winterdienst-hero": "https://picsum.photos/seed/winter/1920/1080",
  "winterdienst-gehweg": "https://picsum.photos/seed/snow/1200/800",
  "winterdienst-instandhaltung": "https://picsum.photos/seed/ice/1200/800",
  "unterhaltsreinigung-hero": "https://picsum.photos/seed/cleaning/1920/1080",
  "baureinigung-hero": "https://picsum.photos/seed/construction/1920/1080",
  "baureinigung-baustelle": "https://picsum.photos/seed/building/1200/800",
  "baureinigung-endreinigung": "https://picsum.photos/seed/architecture/1200/800",
  "industrie-hero": "https://picsum.photos/seed/industry/1920/1080",
  "glasreinigung-hero": "https://picsum.photos/seed/windows/1920/1080",
  "glasreinigung-fassade": "https://picsum.photos/seed/facade/1200/800",
  "glasreinigung-fenster": "https://picsum.photos/seed/glass/1200/800",
  "sonderreinigung-hero": "https://picsum.photos/seed/specialized/1920/1080",
  "sonderreinigung-boden": "https://picsum.photos/seed/floor/1200/800",
  "sonderreinigung-maschinen": "https://picsum.photos/seed/machine/1200/800",
  "buero-hero": "https://picsum.photos/seed/office/1920/1080",
  "buero-konferenz": "https://picsum.photos/seed/conference/1200/800",
  "industrie-fertigung": "https://picsum.photos/seed/manufacturing/1200/800",
  "industrie-halle": "https://picsum.photos/seed/warehouse/1200/800",
  "hotellerie-hero": "https://picsum.photos/seed/hotel/1920/1080",
  "hotellerie-zimmer": "https://picsum.photos/seed/room/1200/800",
  "hotellerie-flur": "https://picsum.photos/seed/hallway/1200/800",
  "medizintechnik-labor2": "https://picsum.photos/seed/research/1200/800",
  "gewerbe-hero": "https://picsum.photos/seed/commercial/1920/1080",
  "standort-vs-hero": "https://picsum.photos/seed/villingen/1920/1080",
  "standort-vs-content": "https://picsum.photos/seed/schwenningen/1200/800",
  "standort-stuttgart-hero": "https://picsum.photos/seed/stuttgart/1920/1080",
  "standort-stuttgart-content": "https://picsum.photos/seed/city/1200/800",
  "standort-konstanz-hero": "https://picsum.photos/seed/konstanz/1920/1080",
  "standort-konstanz-content": "https://picsum.photos/seed/lake/1200/800",
  "home-company1": "https://picsum.photos/seed/team/1200/800",
  "home-company2": "https://picsum.photos/seed/business/1200/800",
  "karriere-hero": "https://picsum.photos/seed/career/1920/1080",
  "fachwissen-iso": "https://picsum.photos/seed/certificate/1200/800"
};

const publicImagesDir = path.join(__dirname, 'public', 'images');
if (!fs.existsSync(publicImagesDir)) {
  fs.mkdirSync(publicImagesDir, { recursive: true });
}

function downloadImage(url, dest) {
  return new Promise((resolve, reject) => {
    const request = https.get(url, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302 || res.statusCode === 307 || res.statusCode === 308) {
        downloadImage(res.headers.location, dest).then(resolve).catch(reject);
      } else if (res.statusCode === 200) {
        const file = fs.createWriteStream(dest);
        res.pipe(file);
        file.on('finish', () => { file.close(); resolve(); });
      } else {
        reject(new Error(`Failed to download ${url}: ${res.statusCode}`));
      }
    }).on('error', reject);
    
    request.setTimeout(15000, () => {
      request.destroy();
      reject(new Error(`Timeout downloading ${url}`));
    });
  });
}

async function main() {
  const entries = Object.entries(imageMap);
  for (let i = 0; i < entries.length; i++) {
    const [name, url] = entries[i];
    const dest = path.join(publicImagesDir, `${name}.jpg`);
    console.log(`Downloading ${i+1}/${entries.length}: ${name}.jpg...`);
    try {
      await downloadImage(url, dest);
    } catch (err) {
      console.error(`Error downloading ${name}:`, err.message);
    }
  }
  console.log('Finished downloading images.');
}

main();
