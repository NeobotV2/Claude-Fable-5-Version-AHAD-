const fs = require('fs');
const path = require('path');
const https = require('https');

const imageMap = {
  "medizintechnik-hero": "modern_hospital_corridor_clean_bright_photorealistic",
  "medizintechnik-labor": "modern_medical_laboratory_sterile_clean_photorealistic",
  "medizintechnik-reinraum": "high_tech_cleanroom_manufacturing_sterile_photorealistic",
  "winterdienst-hero": "commercial_snow_clearing_winter_service_tractor_photorealistic",
  "winterdienst-gehweg": "cleared_snow_path_office_building_winter_photorealistic",
  "winterdienst-instandhaltung": "winter_maintenance_salt_spreading_commercial_photorealistic",
  "unterhaltsreinigung-hero": "professional_commercial_cleaner_vacuuming_office_photorealistic",
  "baureinigung-hero": "post_construction_cleaning_commercial_building_photorealistic",
  "baureinigung-baustelle": "modern_office_building_exterior_glass_facade_photorealistic",
  "baureinigung-endreinigung": "modern_corporate_architecture_clean_lines_photorealistic",
  "industrie-hero": "clean_industrial_warehouse_factory_floor_photorealistic",
  "glasreinigung-hero": "professional_window_cleaner_skyscraper_facade_photorealistic",
  "glasreinigung-fassade": "cleaning_glass_facade_modern_office_building_photorealistic",
  "glasreinigung-fenster": "squeegee_cleaning_large_window_bright_photorealistic",
  "sonderreinigung-hero": "specialized_deep_cleaning_industrial_equipment_photorealistic",
  "sonderreinigung-boden": "industrial_floor_scrubber_machine_cleaning_warehouse_photorealistic",
  "sonderreinigung-maschinen": "cleaning_heavy_manufacturing_machinery_photorealistic",
  "buero-hero": "modern_bright_clean_corporate_office_workspace_photorealistic",
  "buero-konferenz": "spotless_empty_conference_room_glass_table_photorealistic",
  "industrie-fertigung": "clean_manufacturing_plant_production_line_photorealistic",
  "industrie-halle": "empty_clean_industrial_warehouse_logistics_photorealistic",
  "hotellerie-hero": "luxury_hotel_lobby_spotless_clean_photorealistic",
  "hotellerie-zimmer": "perfectly_made_hotel_bed_clean_room_photorealistic",
  "hotellerie-flur": "clean_bright_hotel_corridor_photorealistic",
  "medizintechnik-labor2": "scientific_research_facility_clean_sterile_photorealistic",
  "gewerbe-hero": "modern_commercial_building_exterior_clean_photorealistic",
  "standort-vs-hero": "villingen_schwenningen_city_architecture_photorealistic",
  "standort-vs-content": "modern_office_building_black_forest_germany_photorealistic",
  "standort-stuttgart-hero": "stuttgart_city_skyline_modern_architecture_photorealistic",
  "standort-stuttgart-content": "modern_business_district_city_street_clean_photorealistic",
  "standort-konstanz-hero": "konstanz_lake_constance_architecture_photorealistic",
  "standort-konstanz-content": "commercial_building_near_lake_constance_photorealistic",
  "home-company1": "professional_cleaning_staff_team_uniform_photorealistic",
  "home-company2": "facility_management_professional_handshake_b2b_photorealistic",
  "karriere-hero": "happy_cleaning_staff_team_diverse_photorealistic",
  "fachwissen-iso": "iso_9001_certification_document_quality_management_photorealistic"
};

const publicImagesDir = path.join(__dirname, 'public', 'images');
if (!fs.existsSync(publicImagesDir)) {
  fs.mkdirSync(publicImagesDir, { recursive: true });
}

function downloadImage(url, dest) {
  return new Promise((resolve, reject) => {
    const request = https.get(url, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302 || res.statusCode === 307 || res.statusCode === 308) {
        downloadImage(res.headers.location, dest).then(resolve).catch(reject);
      } else if (res.statusCode === 200) {
        const file = fs.createWriteStream(dest);
        res.pipe(file);
        file.on('finish', () => { file.close(); resolve(); });
      } else {
        reject(new Error(`Failed to download ${url}: ${res.statusCode}`));
      }
    }).on('error', reject);
    
    request.setTimeout(30000, () => {
      request.destroy();
      reject(new Error(`Timeout downloading ${url}`));
    });
  });
}

async function main() {
  const entries = Object.entries(imageMap);
  for (let i = 0; i < entries.length; i++) {
    const [name, prompt] = entries[i];
    // Using pollinations to generate highly contextual images based on the exact prompt
    const url = `https://image.pollinations.ai/prompt/${prompt}?width=1200&height=800&nologo=true`;
    const dest = path.join(publicImagesDir, `${name}.jpg`);
    console.log(`Downloading ${i+1}/${entries.length}: ${name}.jpg...`);
    try {
      await downloadImage(url, dest);
    } catch (err) {
      console.error(`Error downloading ${name}:`, err.message);
    }
  }
  console.log('Finished downloading contextual images.');
}

main();
