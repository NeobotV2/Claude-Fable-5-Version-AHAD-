const fs = require('fs');
const path = require('path');

const srcDir = path.join(__dirname, 'src');

const promptToKeywords = {
  "modern_hospital_corridor_clean_bright_photorealistic": "hospital,corridor",
  "modern_medical_laboratory_sterile_clean_photorealistic": "laboratory,medical",
  "high_tech_cleanroom_manufacturing_sterile_photorealistic": "cleanroom,tech",
  "commercial_snow_clearing_winter_service_tractor_photorealistic": "snow,tractor",
  "cleared_snow_path_office_building_winter_photorealistic": "snow,path",
  "winter_maintenance_salt_spreading_commercial_photorealistic": "winter,ice",
  "professional_commercial_cleaner_vacuuming_office_photorealistic": "cleaning,office",
  "post_construction_cleaning_commercial_building_photorealistic": "construction,cleaning",
  "modern_office_building_exterior_glass_facade_photorealistic": "building,exterior",
  "modern_corporate_architecture_clean_lines_photorealistic": "architecture,modern",
  "clean_industrial_warehouse_factory_floor_photorealistic": "warehouse,factory",
  "professional_window_cleaner_skyscraper_facade_photorealistic": "window,cleaning",
  "cleaning_glass_facade_modern_office_building_photorealistic": "facade,glass",
  "squeegee_cleaning_large_window_bright_photorealistic": "window,washing",
  "specialized_deep_cleaning_industrial_equipment_photorealistic": "industrial,cleaning",
  "industrial_floor_scrubber_machine_cleaning_warehouse_photorealistic": "floor,cleaning",
  "cleaning_heavy_manufacturing_machinery_photorealistic": "machine,cleaning",
  "modern_bright_clean_corporate_office_workspace_photorealistic": "office,workspace",
  "spotless_empty_conference_room_glass_table_photorealistic": "conference,room",
  "clean_manufacturing_plant_production_line_photorealistic": "manufacturing,plant",
  "empty_clean_industrial_warehouse_logistics_photorealistic": "warehouse,logistics",
  "luxury_hotel_lobby_spotless_clean_photorealistic": "hotel,lobby",
  "perfectly_made_hotel_bed_clean_room_photorealistic": "hotel,room",
  "clean_bright_hotel_corridor_photorealistic": "hotel,corridor",
  "scientific_research_facility_clean_sterile_photorealistic": "research,laboratory",
  "modern_commercial_building_exterior_clean_photorealistic": "commercial,building",
  "villingen_schwenningen_city_architecture_photorealistic": "city,architecture",
  "modern_office_building_black_forest_germany_photorealistic": "germany,building",
  "stuttgart_city_skyline_modern_architecture_photorealistic": "stuttgart,city",
  "modern_business_district_city_street_clean_photorealistic": "street,business",
  "konstanz_lake_constance_architecture_photorealistic": "konstanz,lake",
  "commercial_building_near_lake_constance_photorealistic": "lake,building",
  "professional_cleaning_staff_team_uniform_photorealistic": "team,cleaning",
  "facility_management_professional_handshake_b2b_photorealistic": "business,handshake",
  "happy_cleaning_staff_team_diverse_photorealistic": "staff,cleaning",
  "iso_9001_certification_document_quality_management_photorealistic": "certificate,quality"
};

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(function(file) {
    file = dir + '/' + file;
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) { 
      results = results.concat(walk(file));
    } else { 
      if (file.endsWith('.tsx') || file.endsWith('.ts')) {
        results.push(file);
      }
    }
  });
  return results;
}

const files = walk(srcDir);

files.forEach(file => {
  const originalContent = fs.readFileSync(file, 'utf8');
  let content = originalContent;
  
  // Replace https://image.pollinations.ai/prompt/{prompt}?width={width}&height={height}&nologo=true
  const regex = /https:\/\/image\.pollinations\.ai\/prompt\/([a-zA-Z0-9_]+)\?width=(\d+)&height=(\d+)&nologo=true/g;
  
  let matchCount = 0;
  content = content.replace(regex, (match, prompt, width, height) => {
    matchCount++;
    const keywords = promptToKeywords[prompt] || "business";
    // Using loremflickr which is very reliable for placeholders
    return `https://loremflickr.com/${width}/${height}/${keywords}/all`;
  });
  
  if (content !== originalContent) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Updated ${matchCount} images in ${file}`);
  }
});

console.log('All files updated to use LoremFlickr images.');
