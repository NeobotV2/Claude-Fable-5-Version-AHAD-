const fs = require('fs');
const path = require('path');

const srcDir = path.join(__dirname, 'src');

const keywordsToUnsplash = {
  "hospital,corridor": "1584036561584-b03b19a8747c",
  "laboratory,medical": "1579684385127-1ef15d508118",
  "cleanroom,tech": "1530497610245-94d3c16cda28",
  "snow,tractor": "1517299321609-52687d1bc9e3",
  "snow,path": "1483664852095-d6cc68707022",
  "winter,ice": "1542601098-8fc114e148e2",
  "cleaning,office": "1524758631624-e2822e304c36",
  "construction,cleaning": "1503387762-592deb58ef4e",
  "building,exterior": "1541888086425-d81bb19240f5",
  "architecture,modern": "1504307651254-35680f356dfd",
  "warehouse,factory": "1581091226825-a6a2a5aee158",
  "window,cleaning": "1584467735812-07d560bb2816",
  "facade,glass": "1600585154340-be6161a56a0c",
  "window,washing": "1513694203232-719a280e022f",
  "industrial,cleaning": "1585421514738-01798e348b17",
  "floor,cleaning": "1581578731548-c64695cc6952",
  "machine,cleaning": "1504917595217-d4fb505e5e22",
  "office,workspace": "1497366216548-37526070297c",
  "conference,room": "1497215171965-f40579018080",
  "manufacturing,plant": "1565439390204-cb0e46e8e040",
  "warehouse,logistics": "1533090161767-e6ffed986c88",
  "hotel,lobby": "1566073771259-6a8506099945",
  "hotel,room": "1582719478250-c89d14c77a20",
  "hotel,corridor": "1542314831-c53cd3816002",
  "research,laboratory": "1583324113626-70df0f4deaab",
  "commercial,building": "1486406146926-c627a92ad1ab",
  "city,architecture": "1480714378408-67cf0d13bc1b",
  "germany,building": "1449844908441-8829872d2607",
  "stuttgart,city": "1534313314376-a72289b6181e",
  "street,business": "1528360983277-1a1a7be58c34",
  "konstanz,lake": "1530841387398-050ce8f23625",
  "lake,building": "1506953823976-52e1fdc0149a",
  "team,cleaning": "1560179707-2f473057ca3c",
  "business,handshake": "1556761175-5973dc0f32d7",
  "staff,cleaning": "1522071820081-009f0129c71c",
  "certificate,quality": "1454165804606-c3d57bc86b40",
  "business": "1497366216548-37526070297c" // fallback
};

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(function(file) {
    file = dir + '/' + file;
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) { 
      results = results.concat(walk(file));
    } else { 
      if (file.endsWith('.tsx') || file.endsWith('.ts')) {
        results.push(file);
      }
    }
  });
  return results;
}

const files = walk(srcDir);

files.forEach(file => {
  const originalContent = fs.readFileSync(file, 'utf8');
  let content = originalContent;
  
  // Replace https://loremflickr.com/{width}/{height}/{keywords}/all
  const regex = /https:\/\/loremflickr\.com\/(\d+)\/(\d+)\/([^/]+)\/all/g;
  
  let matchCount = 0;
  content = content.replace(regex, (match, width, height, keywords) => {
    matchCount++;
    const unsplashId = keywordsToUnsplash[keywords] || "1497366216548-37526070297c";
    return `https://images.unsplash.com/photo-${unsplashId}?auto=format&fit=crop&q=80&w=1200`;
  });
  
  if (content !== originalContent) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Updated ${matchCount} images in ${file}`);
  }
});

console.log('All files reverted to Unsplash images.');
