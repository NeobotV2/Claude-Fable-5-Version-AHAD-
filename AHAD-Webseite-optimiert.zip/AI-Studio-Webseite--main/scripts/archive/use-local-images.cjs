const fs = require('fs');
const path = require('path');

const srcDir = path.join(__dirname, 'src');

const imageMap = {
  // Leistungen
  "1584036561584-b03b19a8747c": "medizintechnik-hero",
  "1579684385127-1ef15d508118": "medizintechnik-labor",
  "1530497610245-94d3c16cda28": "medizintechnik-reinraum",
  "1517299321609-52687d1bc9e3": "winterdienst-hero",
  "1483664852095-d6cc68707022": "winterdienst-gehweg",
  "1542601098-8fc114e148e2": "winterdienst-instandhaltung",
  "1524758631624-e2822e304c36": "unterhaltsreinigung-hero",
  "1503387762-592deb58ef4e": "baureinigung-hero",
  "1541888086425-d81bb19240f5": "baureinigung-baustelle",
  "1504307651254-35680f356dfd": "baureinigung-endreinigung",
  "1581091226825-a6a2a5aee158": "industrie-hero",
  "1584467735812-07d560bb2816": "glasreinigung-hero",
  "1600585154340-be6161a56a0c": "glasreinigung-fassade",
  "1513694203232-719a280e022f": "glasreinigung-fenster",
  "1585421514738-01798e348b17": "sonderreinigung-hero",
  "1581578731548-c64695cc6952": "sonderreinigung-boden",
  "1504917595217-d4fb505e5e22": "sonderreinigung-maschinen",
  
  // Branchen
  "1497366216548-37526070297c": "buero-hero",
  "1497215171965-f40579018080": "buero-konferenz",
  "1565439390204-cb0e46e8e040": "industrie-fertigung",
  "1533090161767-e6ffed986c88": "industrie-halle",
  "1566073771259-6a8506099945": "hotellerie-hero",
  "1582719478250-c89d14c77a20": "hotellerie-zimmer",
  "1542314831-c53cd3816002": "hotellerie-flur",
  "1583324113626-70df0f4deaab": "medizintechnik-labor2",
  "1486406146926-c627a92ad1ab": "gewerbe-hero",
  
  // Standorte
  "1480714378408-67cf0d13bc1b": "standort-vs-hero",
  "1449844908441-8829872d2607": "standort-vs-content",
  "1534313314376-a72289b6181e": "standort-stuttgart-hero",
  "1528360983277-1a1a7be58c34": "standort-stuttgart-content",
  "1530841387398-050ce8f23625": "standort-konstanz-hero",
  "1506953823976-52e1fdc0149a": "standort-konstanz-content",
  
  // Allgemein
  "1560179707-2f473057ca3c": "home-company1",
  "1556761175-5973dc0f32d7": "home-company2",
  "1522071820081-009f0129c71c": "karriere-hero",
  "1454165804606-c3d57bc86b40": "fachwissen-iso"
};

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(function(file) {
    file = dir + '/' + file;
    const stat = fs.statSync(file);
    if (stat && stat.isDirectory()) { 
      results = results.concat(walk(file));
    } else { 
      if (file.endsWith('.tsx') || file.endsWith('.ts')) {
        results.push(file);
      }
    }
  });
  return results;
}

const files = walk(srcDir);

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  const regex = /https:\/\/images\.unsplash\.com\/photo-([a-zA-Z0-9-]+)[^"'\s]*/g;
  
  let matchCount = 0;
  content = content.replace(regex, (match, id) => {
    matchCount++;
    const name = imageMap[id] || id;
    return `/images/${name}.jpg`;
  });
  
  if (matchCount > 0) {
    fs.writeFileSync(file, content, 'utf8');
    console.log(`Updated ${matchCount} images in ${file}`);
  }
});

console.log('All files updated to use local /images/ paths.');
