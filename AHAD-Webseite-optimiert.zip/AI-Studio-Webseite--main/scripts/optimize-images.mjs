/**
 * Bild-Optimierung: konvertiert alle JPG/PNG in public/images zu WebP.
 *
 * Warum? Die Originalbilder sind zusammen ~15 MB groß — das bremst jeden
 * Seitenaufruf massiv. WebP bei Qualität 80 spart typischerweise 60–80 %
 * bei praktisch identischer Optik.
 *
 * Verwendung (einmalig):
 *   npm install --save-dev sharp
 *   node scripts/optimize-images.mjs
 *
 * Danach in src/ alle Bildpfade von .jpg/.png auf .webp umstellen:
 *   node scripts/optimize-images.mjs --update-refs
 */
import { readdir, stat, unlink, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

const IMG_DIR = 'public/images';
const SRC_DIR = 'src';
const MAX_WIDTH = 1920;
const QUALITY = 80;

async function* walk(dir) {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) yield* walk(full);
    else yield full;
  }
}

async function convertImages() {
  const sharp = (await import('sharp')).default;
  let before = 0, after = 0, count = 0;

  for await (const file of walk(IMG_DIR)) {
    if (!/\.(jpe?g|png)$/i.test(file)) continue;
    const { size } = await stat(file);
    before += size;

    const out = file.replace(/\.(jpe?g|png)$/i, '.webp');
    const img = sharp(file);
    const meta = await img.metadata();
    if (meta.width > MAX_WIDTH) img.resize({ width: MAX_WIDTH });
    await img.webp({ quality: QUALITY }).toFile(out);

    after += (await stat(out)).size;
    await unlink(file);
    count++;
    console.log(`✓ ${path.basename(file)} → ${path.basename(out)}`);
  }

  console.log(`\n${count} Bilder konvertiert.`);
  console.log(`Vorher:  ${(before / 1e6).toFixed(1)} MB`);
  console.log(`Nachher: ${(after / 1e6).toFixed(1)} MB  (−${Math.round((1 - after / before) * 100)} %)`);
  console.log(`\nJetzt Referenzen aktualisieren:\n  node scripts/optimize-images.mjs --update-refs`);
}

async function updateRefs() {
  let changed = 0;
  for await (const file of walk(SRC_DIR)) {
    if (!/\.(tsx?|css)$/.test(file)) continue;
    const content = await readFile(file, 'utf8');
    const updated = content.replace(/(\/images\/[\w-]+)\.(jpe?g|png)/gi, '$1.webp');
    if (updated !== content) {
      await writeFile(file, updated);
      changed++;
      console.log(`✓ ${file}`);
    }
  }
  console.log(`\n${changed} Dateien aktualisiert. Fertig!`);
}

if (process.argv.includes('--update-refs')) {
  await updateRefs();
} else {
  await convertImages();
}
