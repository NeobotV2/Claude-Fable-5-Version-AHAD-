# Optimierungen — Übersicht aller Änderungen

## ⚠️ Wichtig zuerst: Beschädigte Bilder im ZIP

Alle 44 Bilder in `public/images/` waren im hochgeladenen ZIP **irreparabel beschädigt**
(die Binärdaten wurden irgendwann als Text behandelt — vermutlich beim Export aus
AI Studio oder beim Commit). Sie wurden daher aus diesem Paket entfernt.

**So gehst du vor:**
1. Kopiere deine Original-Bilder zurück nach `public/images/` (aus deinem lokalen
   Projekt — prüfe auch, ob die Bilder im GitHub-Repo selbst intakt sind!)
2. Führe einmalig aus: `npm install --save-dev sharp` und dann `npm run optimize-images`
3. Danach: `node scripts/optimize-images.mjs --update-refs`
→ Das reduziert die 15 MB Bilder auf ca. 3–4 MB (WebP, max. 1920px breit).

## 🚀 Performance

- **Code-Splitting** (`src/App.tsx`): Alle ~35 Seiten werden jetzt lazy geladen.
  Vorher lud jeder Besucher den Code sämtlicher Seiten beim ersten Aufruf —
  jetzt nur noch die Startseite, der Rest bei Bedarf.
- **Vendor-Chunks** (`vite.config.ts`): React, Firebase und Motion liegen in
  eigenen, langfristig cachebaren Dateien.
- **Fonts** (`index.html` + `src/index.css`): Laden jetzt mit `preconnect` über
  `<link>` statt render-blockierendem CSS-`@import`.
- **Firestore-Testabfrage entfernt** (`App.tsx`): lief unnötig bei jedem Seitenaufruf.
- **Bild-Optimierungs-Skript** (`scripts/optimize-images.mjs`): siehe oben.

## 🔒 Sicherheit

- **Kritisch — API-Key-Leak behoben** (`vite.config.ts`): `GEMINI_API_KEY` wurde
  bisher in das öffentliche JavaScript-Bundle eingebettet — jeder Besucher hätte
  ihn auslesen und auf deine Kosten nutzen können. Jetzt nur noch im Dev-Modus.
  → **Bitte den bisherigen Key in der Google-Console rotieren (neu erzeugen)!**
- **`/generate-images` aus Produktion entfernt** (`App.tsx`): internes Tool,
  nur noch im Dev-Modus erreichbar.
- **E-Mail-API gehärtet** (`api/index.ts`): HTML-Escaping aller Eingaben (verhindert
  Injection in Benachrichtigungs-Mails), Pflichtfeld-Validierung, Längenlimits,
  Rate-Limit (5 Anfragen / 10 Min / IP), Honeypot-Prüfung, Body-Limit 50 kB.
- **Spam-Schutz im Kontaktformular** (`ContactForm.tsx`): unsichtbares
  Honeypot-Feld fängt Bots ab.
- **Admin-Bereich** auf `noindex` gesetzt + in `robots.txt` ausgeschlossen.

## 🔍 SEO

- **`index.html` komplett überarbeitet**: `lang="de"` (war `en`!), echter Titel
  und Description statt "My Google AI Studio App", `theme-color`, Favicon
  (AHAD-Logo als SVG), Open-Graph-Grundwerte, `<noscript>`-Fallback mit Telefonnummer.
- **`robots.txt` und `sitemap.xml` erstellt** (alle 33 öffentlichen Seiten).
- **LocalBusiness-Schema** (`Home.tsx`): erweitert um Geo-Koordinaten,
  Öffnungszeiten, Servicegebiete (VS, Stuttgart, Konstanz, Schwarzwald-Baar-Kreis)
  und Preisspanne — wichtig für lokale Google-Suche & Maps.
- **`SEO.tsx`**: `og:site_name` und `og:locale=de_DE` ergänzt.
- **404-Seite** (`src/pages/NotFound.tsx`, neu): Unbekannte URLs zeigten vorher
  eine leere Seite. Jetzt eine Markenseite mit Schnellnavigation, `noindex`.

## ♿ Barrierefreiheit & UX

- **Skip-Link** (`Layout.tsx`): Tastaturnutzer springen direkt zum Inhalt.
- **`prefers-reduced-motion`** (`index.css`): Animationen werden für Nutzer mit
  Bewegungsempfindlichkeit deaktiviert.
- **Kontaktformular**: sichtbare Fehlermeldung mit Telefon-Alternative statt
  stillem Absturz; `maxLength` auf allen Feldern.
- **Ladeindikator** beim Seitenwechsel (durch Lazy Loading nötig, `role="status"`).

## 🎨 Design-Feinschliff

- **Trust-Badge im Hero** (`Home.tsx`): Die Dummy-Avatare (Firmenfotos als
  Fake-Profilbilder) wirkten unglaubwürdig — ersetzt durch eine konkrete,
  ehrliche Aussage mit Referenznamen. ⚠️ Bitte verifiziere die Zahl
  "über 80 betreute Objekte" — sie stammt aus dem alten "+80"-Badge.
- **Button-Hover vereinheitlicht**: `hover:bg-blue-700` (Fremdfarbe) → dunkleres
  Markenblau `#003a6e`.
- **Typografie**: `text-wrap: balance` für Überschriften, `pretty` für Absätze,
  Markenfarbe für Textauswahl, Font-Smoothing.

## 🧹 Aufräumen

- 15 Einmal-Skripte (`download-*.cjs`, `use-*.cjs`, `revert-*.cjs`, …) aus dem
  Root nach `scripts/archive/` verschoben.
- `README.md` neu geschrieben (war AI-Studio-Boilerplate).
- `npm run optimize-images` als Skript ergänzt.

## ✅ Deine nächsten Schritte

1. `GEMINI_API_KEY` rotieren (siehe Sicherheit)
2. Bilder zurückkopieren + `npm run optimize-images` (siehe oben)
3. `npm install && npm run lint && npm run build` lokal ausführen
   (in dieser Umgebung war kein Netzwerkzugriff möglich, daher ungetestet)
4. `og-image.jpg` (1200×630 px) und `logo.png` in `public/` ablegen
5. Resend: eigene verifizierte Domain statt `onboarding@resend.dev` eintragen
